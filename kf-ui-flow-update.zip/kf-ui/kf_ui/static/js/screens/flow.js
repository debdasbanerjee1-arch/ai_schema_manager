import { html } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { patch } from "../lib/router.js";
import { Empty, ErrorBox, Handoff, Loading, NodeLink, Notes, OpsTags, Picker } from "../lib/ui.js";

const KIND = { dms: "DMS replication", state_machine: "State machine", job: "Job (no state machine found)",
  no_job: "Derived without a job (for example a view)" };

// Where this step's input comes from: the earlier steps it waits for, and how.
const After = ({ s, prev }) => {
  if (!s.after.length) return s.n > 1 ? html`<div class="handoff"><span class="small muted">Separate input: does not wait for an earlier step</span></div>` : null;
  return html`<div class="handoff" style="flex-direction:column;align-items:flex-start;gap:4px">${s.after.map((a) => html`
    <div class="row small"><span class="arrow" aria-hidden="true">↓</span>
      <span class="muted">${a.step === prev ? "after the step above" : `after step ${a.step} (${a.name})`}</span>
      ${a.handoff ? html`<${Handoff} h=${a.handoff} /><span class="muted">${a.handoff.why}</span>` : null}
      <span class="muted">· reads <span class="mono">${a.table.name}</span></span></div>`)}</div>`;
};

export function Flow({ params }) {
  const key = params.get("key");
  const { data, error } = useApi("/api/flow", { key }, key);
  const picker = html`<div class="card noprint"><${Picker} label="Which table? Steps are in dependency order: each waits for the steps that write what it reads." types=${["table", "extract"]}
    value=${data ? data.table.name : ""} onPick=${(r) => patch({ key: r.key })} /></div>`;
  const legend = html`<div class="row small muted noprint">
    <span class="badge green">Enforced</span> the next step is started by the previous one
    <span class="badge blue">Event</span> started when the data or a completion event arrives
    <span class="badge amber">Schedule only</span> runs on its own clock; nothing makes it wait
    <span class="badge">Not harvested</span> trigger not in this snapshot</div>`;
  if (!key) return html`<h1>End-to-end flow</h1>${picker}<${Empty}>Pick a table to see every orchestrator its data passes through, and how each hands over to the next.</${Empty}>`;
  if (error) return html`<h1>End-to-end flow</h1>${picker}<${ErrorBox} error=${error} />`;
  if (!data) return html`<h1>End-to-end flow</h1>${picker}<${Loading} />`;
  return html`
    <h1>End-to-end flow</h1>${picker}${legend}
    ${!data.triggers_harvested ? html`<${Notes} notes=${["Triggers are not harvested yet, so hand-offs between state machines show as Not harvested."]} />` : null}
    ${data.segments.length ? html`<div class="flow">${data.segments.map((s, i) => html`
      ${i > 0 ? html`<${After} s=${s} prev=${data.segments[i - 1].n} />` : null}
      <section class="card seg-card" aria-label=${"Step " + s.n}>
        <div class="seg-head"><span class="muted small">${s.n}. ${KIND[s.kind] || s.kind}</span>
          ${s.orchestrator ? html`<${NodeLink} node=${s.orchestrator} showType=${false} />` : null}
          <${OpsTags} tags=${s.ops_tags} /></div>
        <div class="seg-body">
          ${s.jobs.map((j) => html`<div class="small">runs <${NodeLink} node=${j} showType=${false} /></div>`)}
          ${s.steps.map((st) => html`<div class="small">
            <span class="mono">${st.from.name}</span> → <a class="mono" href=${"#/detail?key=" + encodeURIComponent(st.to.key)}>${st.to.name}</a>
            ${st.config_key && st.config_key !== st.to.name ? html` <span class="muted">(branch ${st.config_key})</span>` : null}
            ${st.to.key === data.table.key ? html` <span class="badge accent">this table</span>` : null}</div>`)}
        </div>
      </section>`)}</div>` : html`<${Empty}>No lineage into or out of ${data.table.name} in the graph.</${Empty}>`}
    ${data.consumers.length ? html`<section class="card stack"><h2>Consumers at the end</h2>
      <div class="row">${data.consumers.map((c) => html`<span class="chip"><${NodeLink} node=${c} /></span>`)}</div></section>` : null}`;
}
