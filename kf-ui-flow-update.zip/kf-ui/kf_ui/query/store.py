"""Load the graph named in <data_root>/graph/CURRENT, read-only, into memory.

Only table-level and orchestration data is indexed as nodes; columns are kept
in a lighter map. Nothing here writes anywhere.
"""

from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import duckdb

JOB_TYPES = {"glue_job", "lambda_function", "dms_task"}
ORCH_TYPES = {"pipeline"}
DATA_TYPES = {"table", "extract"}
CONSUMER_TYPES = {"dashboard", "chart", "data_model", "api_endpoint", "extract", "channel"}
COLUMN_KEEP = ("pk_ordinal", "is_partition_key", "is_key_discriminator", "generated", "dms_added")

# Where a "last loaded" time may sit, in order of preference. Adjust here if the
# resolver uses other names.
LOAD_TIME_PATHS = ("last_loaded.at", "dms_last_update_time", "last_update_time",
                   "bookmark_timestamp", "last_job_start_time")


@dataclass(frozen=True)
class Edge:
    id: int
    src: str
    dst: str
    type: str
    tc: str | None
    expr: str | None
    origin: str
    tier: str
    job: str | None
    attrs: dict

    @property
    def relation(self):
        return self.attrs.get("relation")

    @property
    def level(self):
        return self.attrs.get("level")

    def brief(self):
        return {"src": self.src, "dst": self.dst, "type": self.type, "origin": self.origin, "tier": self.tier,
                "transform_class": self.tc, "expression": self.expr, "job": self.job,
                "relation": self.relation, "config_table": self.attrs.get("config_table"),
                "config_key": self.attrs.get("config_key"),
                "via_state_machine": self.attrs.get("via_state_machine")}


@dataclass
class Graph:
    path: Path
    snapshot_id: str
    built_at: str
    nodes: dict = field(default_factory=dict)      # key -> dict (non-column nodes)
    columns: dict = field(default_factory=dict)    # key -> dict(name, table, data_type, attrs)
    out: dict = field(default_factory=lambda: defaultdict(list))
    inn: dict = field(default_factory=lambda: defaultdict(list))
    table_columns: dict = field(default_factory=lambda: defaultdict(list))
    inn_by_job: dict = field(default_factory=lambda: defaultdict(list))  # table-level derives_from by job
    gaps: list = field(default_factory=list)
    gaps_by_object: dict = field(default_factory=lambda: defaultdict(list))
    flags: dict = field(default_factory=dict)

    # ---------- basic access ----------
    def get(self, key):
        """A node or column as a dict with key, name, type, layer, system."""
        n = self.nodes.get(key)
        if n:
            return n
        c = self.columns.get(key)
        if c:
            t = self.nodes.get(c["table"], {})
            return {"key": key, "name": c["name"], "type": "column", "layer": t.get("layer", "none"),
                    "system": t.get("system"), "table": c["table"], "table_name": t.get("name"),
                    "data_type": c["data_type"], "attrs": c["attrs"]}
        return None

    def name(self, key):
        n = self.get(key)
        if not n:
            return key
        if n["type"] == "column":
            return f"{n['table_name']}.{n['name']}"
        a = n.get("attrs", {})
        if n["type"] == "table" and n.get("layer") == "source" and a.get("database"):
            return ".".join(x for x in (a.get("database"), a.get("schema"), n["name"]) if x)
        return n["name"]

    def ref(self, key):
        n = self.get(key) or {"name": key, "type": "unknown", "layer": "none", "system": None}
        r = {"key": key, "name": self.name(key), "type": n["type"], "layer": n.get("layer", "none"),
             "system": n.get("system")}
        return r

    def edges_out(self, key, etype=None, relation=None):
        return [e for e in self.out.get(key, ()) if (etype is None or e.type == etype)
                and (relation is None or e.relation == relation)]

    def edges_in(self, key, etype=None, relation=None):
        return [e for e in self.inn.get(key, ()) if (etype is None or e.type == etype)
                and (relation is None or e.relation == relation)]

    # ---------- lineage helpers ----------
    def is_column(self, key):
        return key in self.columns

    def table_lineage_out(self, key):
        return [e for e in self.edges_out(key, "derives_from") if not self.is_column(e.dst)]

    def table_lineage_in(self, key):
        return [e for e in self.edges_in(key, "derives_from") if not self.is_column(e.src)]

    def column_lineage_out(self, key):
        return [e for e in self.edges_out(key, "derives_from") if self.is_column(e.dst)]

    def column_lineage_in(self, key):
        return [e for e in self.edges_in(key, "derives_from") if self.is_column(e.src)]

    # ---------- orchestration helpers ----------
    def parent_task(self, key):
        for e in self.edges_in(key, "contains"):
            return e.src
        return None

    def pipeline_of(self, task_key):
        seen = set()
        k = task_key
        while k and k not in seen:
            seen.add(k)
            n = self.nodes.get(k)
            if n and n["type"] in ORCH_TYPES:
                return k
            k = self.parent_task(k)
        return None

    def sfn_key(self, name_or_key):
        if not name_or_key:
            return None
        if name_or_key in self.nodes:
            return name_or_key
        k = f"aws.sfn.{name_or_key}"
        return k if k in self.nodes else None

    def orchestrators_of(self, job_key, config_key=None):
        """State machines that run a job.

        With a config_key (one branch), the state machines named on that branch's edges
        (via_state_machine) come first: a shared job such as raw2dis is run by many state
        machines, and the branch says which one runs it for this table. Then any state
        machine whose states invoke the job."""
        found = []
        if config_key:
            for e in self.out.get(job_key, ()):
                if e.attrs.get("config_key") == config_key:
                    p = self.sfn_key(e.attrs.get("via_state_machine"))
                    if p and p not in found:
                        found.append(p)
        for e in self.edges_in(job_key, "depends_on", "invokes"):
            p = self.pipeline_of(e.src)
            if p and p not in found:
                found.append(p)
        if not config_key:
            for e in self.out.get(job_key, ()):
                p = self.sfn_key(e.attrs.get("via_state_machine"))
                if p and p not in found:
                    found.append(p)
        return found

    def tasks_of(self, pipeline_key):
        result, stack = [], [pipeline_key]
        while stack:
            k = stack.pop()
            for e in self.edges_out(k, "contains"):
                result.append(e.dst)
                stack.append(e.dst)
        return result

    def jobs_of(self, pipeline_key):
        jobs = []
        for t in self.tasks_of(pipeline_key):
            for e in self.edges_out(t, "depends_on", "invokes"):
                if e.dst not in jobs:
                    jobs.append(e.dst)
        return jobs

    def children_of(self, pipeline_key):
        """State machines started by this one (nested executions)."""
        kids = []
        for t in [pipeline_key] + self.tasks_of(pipeline_key):
            for e in self.edges_out(t, "depends_on", "starts"):
                if e.dst not in kids:
                    kids.append(e.dst)
        return kids

    def starters_of(self, pipeline_key):
        """Nodes (states or functions) that start this state machine."""
        return [e.src for e in self.edges_in(pipeline_key, "depends_on", "starts")]

    def job_outputs(self, job_key, config_key=None):
        """(table, edge) pairs a job produces: derives_from with this job, plus writes."""
        seen, out = set(), []
        for e in self.inn_by_job.get(job_key, ()):
            if config_key and e.attrs.get("config_key") != config_key:
                continue
            if e.dst not in seen:
                seen.add(e.dst)
                out.append((e.dst, e))
        for e in self.edges_out(job_key, "writes"):
            if config_key and e.attrs.get("config_key") != config_key:
                continue
            if e.dst not in seen:
                seen.add(e.dst)
                out.append((e.dst, e))
        return out

    def job_inputs(self, job_key, config_key=None):
        seen, out = set(), []
        for e in self.inn_by_job.get(job_key, ()):
            if config_key and e.attrs.get("config_key") != config_key:
                continue
            if e.src not in seen:
                seen.add(e.src)
                out.append((e.src, e))
        for e in self.edges_out(job_key, "reads"):
            if config_key and e.attrs.get("config_key") != config_key:
                continue
            if e.dst not in seen:
                seen.add(e.dst)
                out.append((e.dst, e))
        return out

    def bound_instances(self, job_key):
        inst = {}
        for e in self.out.get(job_key, ()):
            ck = e.attrs.get("config_key")
            if ck:
                inst.setdefault((e.attrs.get("config_table"), ck), set()).add(e.attrs.get("via_state_machine") or "")
        for e in self.inn_by_job.get(job_key, ()):
            ck = e.attrs.get("config_key")
            if ck:
                inst.setdefault((e.attrs.get("config_table"), ck), set())
        return [{"config_table": t, "config_key": k, "state_machines": sorted(x for x in v if x)}
                for (t, k), v in sorted(inst.items(), key=lambda i: (i[0][0] or "", i[0][1]))]

    # ---------- consumers, load times, gaps ----------
    def consumers_of(self, table_key):
        res = [e.src for e in self.edges_in(table_key, "consumes")]
        return res

    def load_time(self, key):
        n = self.nodes.get(key)
        if not n:
            return None
        for p in LOAD_TIME_PATHS:
            v = n["attrs"]
            for part in p.split("."):
                v = v.get(part) if isinstance(v, dict) else None
            if v:
                src = n["attrs"].get("last_loaded", {}).get("source") if p.startswith("last_loaded") else p
                return {"at": str(v), "source": src}
        return None

    def gaps_for(self, key):
        n = self.nodes.get(key)
        res = list(self.gaps_by_object.get(key, ()))
        if n:
            res += [g for g in self.gaps_by_object.get(n["name"], ()) if g not in res]
        return res


def _find_tables(con):
    rows = con.execute("SELECT table_schema, table_name FROM information_schema.tables "
                       "WHERE table_catalog = 'kfg' AND table_name IN ('node', 'edge')").fetchall()
    schemas = {t: s for s, t in rows}
    if "node" not in schemas or "edge" not in schemas:
        raise RuntimeError(f"No graph node and edge tables found: {rows}")
    return f'kfg."{schemas["node"]}".node', f'kfg."{schemas["edge"]}".edge'


def _loads(s):
    if s is None:
        return {}
    if isinstance(s, dict):
        return s
    try:
        v = json.loads(s)
        return v if isinstance(v, dict) else {}
    except ValueError:
        return {}


def current_graph_file(data_root):
    root = Path(data_root)
    name = (root / "graph" / "CURRENT").read_text(encoding="utf-8").strip()
    return root / "graph" / name


def load(data_root) -> Graph:
    root = Path(data_root)
    path = current_graph_file(root)
    snapshot = re.sub(r"^graph\.|\.duckdb$", "", path.name)
    built = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat(timespec="seconds")
    g = Graph(path=path, snapshot_id=snapshot, built_at=built)

    con = duckdb.connect()
    try:
        con.execute(f"ATTACH '{path.as_posix()}' AS kfg (READ_ONLY)")
        NODE, EDGE = _find_tables(con)
        rows = con.execute(f"SELECT node_key, node_type, layer, parent_key, name, data_type, "
                           f"CAST(attrs AS VARCHAR) FROM {NODE} WHERE NOT coalesce(deleted, false)").fetchall()
        for key, nt, layer, parent, name, dt, attrs in rows:
            a = _loads(attrs)
            if nt == "column":
                lite = {k: a[k] for k in COLUMN_KEEP if k in a}
                g.columns[key] = {"name": name, "table": parent, "data_type": dt, "attrs": lite}
                g.table_columns[parent].append(key)
            else:
                g.nodes[key] = {"key": key, "type": nt, "layer": layer or "none", "parent": parent,
                                "name": name, "data_type": dt, "system": a.get("system"), "attrs": a}
        erows = con.execute(f"SELECT edge_id, src_key, dst_key, edge_type, transform_class, expression, origin, "
                            f"tier, job_key, CAST(attrs AS VARCHAR) FROM {EDGE}").fetchall()
    finally:
        con.close()

    for r in erows:
        e = Edge(r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], _loads(r[9]))
        g.out[e.src].append(e)
        g.inn[e.dst].append(e)
        if e.type == "derives_from" and e.job and e.dst not in g.columns:
            g.inn_by_job[e.job].append(e)

    gap_dir = root / "gaps" / snapshot
    if gap_dir.is_dir():
        for f in sorted(gap_dir.glob("*.csv")):
            with f.open(encoding="utf-8", newline="") as fh:
                for row in csv.DictReader(fh):
                    row = {k: (v or "") for k, v in row.items() if k}
                    row.setdefault("rule", f.stem)
                    g.gaps.append(row)
                    if row.get("object"):
                        g.gaps_by_object[row["object"]].append(row)
                    if row.get("location"):
                        g.gaps_by_object[row["location"]].append(row)

    nodes = g.nodes.values()
    g.flags = {
        "triggers_harvested": any("triggers" in n["attrs"] for n in nodes),
        "consumers_harvested": any(e.type == "consumes" for es in g.out.values() for e in es)
        or any(n["layer"] == "consumer" for n in nodes),
        "terms_harvested": any(n["type"] == "glossary_term" for n in nodes),
        "load_times_present": any(g.load_time(n["key"]) for n in nodes if n["type"] in DATA_TYPES),
        "column_lineage_beyond_distill": any(
            e.type == "derives_from" and e.origin in ("parsed", "parsed_partial")
            for es in g.out.values() for e in es if e.src in g.columns),
    }
    return g
