import { html, useState } from "../lib/preact.js";
import { href, patch } from "../lib/router.js";
import { LineageCanvas } from "../lib/lineage-canvas.js";
import { Empty, LAYERS, LAYER_LABEL, Layer, NodeLink, Picker, TYPE_LABEL, detailHref, layerVar } from "../lib/ui.js";

function Side({ s, onPickNote }) {
  if (!s) return html`<aside class="side narrow card"><p class="muted" style="margin:0">Click a table to see how it connects.</p></aside>`;
  const isTable = s.type === "table" || s.type === "extract";
  return html`<aside class="side narrow card stack" aria-label="Selected">
    <div class="stack" style="gap:4px"><span class="muted small">${TYPE_LABEL[s.type] || s.type}</span>
      <b class="mono" style="overflow-wrap:anywhere">${s.name}</b>
      <div class="row"><${Layer} layer=${s.layer} />${s.system ? html`<span class="small">${s.system}</span>` : null}</div>
      ${s.loaded ? html`<span class="small muted">Last loaded ${s.loaded.at} (as of snapshot)</span>` : null}</div>
    <div class="row">
      <a class="btn small primary" href=${detailHref(s.key)}>Details</a>
      ${isTable ? html`<a class="btn small" href=${href("lineage", { key: s.key })}>Centre here</a>
        <a class="btn small" href=${href("flow", { key: s.key })}>Flow</a>
        <a class="btn small" href=${href("impact", { mode: "stale", key: s.key })}>Stale check</a>` : null}
    </div>
    <div class="stack" style="gap:6px"><h3>Links shown · ${s.edges.length}</h3>${s.edges.map((e) => {
      const other = e.src === s.key ? e.dst : e.src;
      return html`<div class="rowi" style="flex-direction:column;gap:2px">
        <span class="small">${e.type === "consumes" ? "used by" : e.src === s.key ? "feeds" : "from"} <span class="mono">${s.nodeName(other) || other}</span></span>
        ${e.job_name ? html`<span class="small muted">job <a class="mono" href=${detailHref(e.job)}>${e.job_name}</a>
          ${e.orchestrator ? html` in <a class="mono" href=${detailHref(e.orchestrator.key)}>${e.orchestrator.name}</a>`
            : e.orchestrator_candidates > 1 ? html` in one of ${e.orchestrator_candidates} state machines (not recorded for this branch)` : null}</span>` : null}
        <span class="small muted">${[e.origin, e.tier, e.transform_class, e.config_key].filter(Boolean).join(" · ")}</span>
      </div>`;
    })}</div>
  </aside>`;
}

export function Lineage({ params }) {
  const key = params.get("key");
  const depth = Math.max(1, Math.min(4, parseInt(params.get("depth") || "1", 10) || 1));
  const jobs = params.get("jobs") === "1";
  const [sel, setSel] = useState(null);
  return html`
    <h1>Lineage</h1>
    <div class="card stack noprint">
      <${Picker} label="Start from a table or a column" types=${["table", "extract", "column"]} onPick=${(r) => patch({ key: r.key })} />
      ${key ? html`<div class="row small">
        <label class="row">Open with <select class="select" style="width:auto" value=${depth} onChange=${(e) => patch({ depth: e.target.value })}>
          ${[1, 2, 3, 4].map((d) => html`<option value=${d}>${d} hop${d > 1 ? "s" : ""} each side</option>`)}</select></label>
        <label class="row"><input type="checkbox" checked=${jobs} onChange=${(e) => patch({ jobs: e.target.checked ? "1" : null })} /> Show jobs on the links</label>
        <span class="muted">Use + and − on a table to show or hide one more hop. Drag to move, scroll to zoom. Open a table's columns and click one to trace it.</span>
      </div>` : null}
    </div>
    ${!key ? html`<${Empty}>Pick a table to see what feeds it and what it feeds.</${Empty}>` : html`
      <div class="split">
        <div class="main wide"><${LineageCanvas} rootKey=${key} depth=${depth} showJobs=${jobs} height=${620} onSelect=${setSel} /></div>
        <${Side} s=${sel} />
      </div>
      <div class="row small muted">${LAYERS.filter((l) => l !== "none").map((l) => html`<span class="layer" style=${`--c:${layerVar(l)}`}>${LAYER_LABEL[l]}</span>`)}
        <span>dashed line: used by a consumer</span><span>amber: a column's path</span></div>`}`;
}
