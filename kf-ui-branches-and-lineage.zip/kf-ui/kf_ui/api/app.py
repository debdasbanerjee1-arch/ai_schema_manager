"""Read-only FastAPI service over the query library. It also serves the UI.

Every endpoint is GET. Nothing writes to the graph, the inventory or AWS.
"""

from __future__ import annotations

import time
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles

from ..query import Fabric

STATIC = Path(__file__).resolve().parents[1] / "static"
CHECK_EVERY = 60  # seconds between checks of CURRENT


def create_app(fabric: Fabric) -> FastAPI:
    app = FastAPI(title="Knowledge Fabric", docs_url="/api/docs", redoc_url=None, openapi_url="/api/openapi.json")
    state = {"checked": time.time()}

    @app.middleware("http")
    async def refresh_and_guard(request: Request, call_next):
        if request.method not in ("GET", "HEAD"):
            return JSONResponse({"detail": "This service is read-only."}, status_code=405)
        if request.url.path.startswith("/api/") and time.time() - state["checked"] > CHECK_EVERY:
            state["checked"] = time.time()
            try:
                fabric.refresh()
            except Exception:  # keep serving the graph already loaded
                pass
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response

    def run(fn, *a, **kw):
        try:
            return fn(*a, **kw)
        except KeyError as exc:
            raise HTTPException(404, f"Not in the current graph: {exc.args[0] if exc.args else ''}")
        except ValueError as exc:
            raise HTTPException(400, str(exc))

    @app.get("/api/meta")
    def meta():
        return fabric.meta()

    @app.get("/api/search")
    def search(q: str, type: list[str] | None = Query(None), layer: str | None = None, system: str | None = None,
               limit: int = 30, columns: bool = True, one_off: bool = False):
        return fabric.search(q, types=set(type) if type else None, layer=layer, system=system, limit=min(limit, 200),
                             include_columns=columns, include_one_off=one_off)

    @app.get("/api/detail")
    def detail(key: str):
        return run(fabric.detail, key)

    @app.get("/api/lineage")
    def lineage(key: str, direction: str = "both", depth: int = 2, lens: str = "data", level: str = "table"):
        if direction not in ("both", "up", "down"):
            raise HTTPException(400, "direction must be both, up or down")
        if not fabric.g.get(key):
            raise HTTPException(404, f"Not in the current graph: {key}")
        return run(fabric.lineage, key, direction=direction, depth=max(1, min(depth, 6)), lens=lens, level=level)

    @app.get("/api/lineage/start")
    def lineage_start(key: str):
        return run(fabric.lineage_start, key)

    @app.get("/api/lineage/step")
    def lineage_step(key: str, direction: str, limit: int = 25):
        return run(fabric.lineage_step, key, direction, max(1, min(limit, 1000)))

    @app.get("/api/lineage/columns")
    def lineage_columns(key: str):
        return run(fabric.lineage_columns, key)

    @app.get("/api/lineage/column_path")
    def column_path(key: str):
        return run(fabric.column_path, key)

    @app.get("/api/flow")
    def flow(key: str):
        return run(fabric.flow, key)

    @app.get("/api/impact/failure")
    def failure(key: str, config_key: str | None = None):
        return run(fabric.failure, key, config_key or None)

    @app.get("/api/impact/stale")
    def stale(key: str):
        return run(fabric.stale, key)

    @app.get("/api/impact/column")
    def column(key: str):
        return run(fabric.column_change, key)

    @app.get("/api/runbook")
    def runbook(mode: str, key: str, config_key: str | None = None, download: bool = False):
        if mode not in ("failure", "stale", "column"):
            raise HTTPException(400, "mode must be failure, stale or column")
        md = run(fabric.runbook, mode, key, config_key or None)
        headers = {}
        if download:
            safe = "".join(c if c.isalnum() or c in "-_." else "_" for c in key.split(".")[-1])[:80]
            headers["Content-Disposition"] = f'attachment; filename="runbook-{mode}-{safe}.md"'
        return PlainTextResponse(md, media_type="text/markdown; charset=utf-8", headers=headers)

    @app.get("/api/config/tables")
    def config_tables():
        return fabric.config_tables()

    @app.get("/api/config")
    def config(table: str, q: str = ""):
        return fabric.config_deps(table, q)

    @app.get("/api/terms")
    def terms(q: str):
        return fabric.terms(q)

    @app.get("/api/health")
    def health():
        return fabric.health()

    @app.get("/api/inventory/summary")
    def inventory_summary():
        return fabric.inventory_summary()

    def _inv_args(request: Request):
        p = request.query_params
        filters = {}
        for k in p.keys():
            if k.startswith("f."):
                filters[k[2:]] = p.getlist(k)
        return dict(filters=filters, q=p.get("q", ""), quick=p.getlist("quick"), sort=p.get("sort", "name"),
                    desc=p.get("desc") in ("1", "true"))

    @app.get("/api/inventory")
    def inventory(request: Request, kind: str, offset: int = 0, limit: int = 100):
        return run(fabric.inventory, kind, offset=max(0, offset), limit=max(1, min(limit, 500)), **_inv_args(request))

    @app.get("/api/inventory.csv")
    def inventory_csv(request: Request, kind: str):
        text = run(fabric.inventory_csv, kind, **_inv_args(request))
        return Response(text, media_type="text/csv; charset=utf-8",
                        headers={"Content-Disposition": f'attachment; filename="inventory-{kind}.csv"'})

    @app.get("/api/{rest:path}")
    def not_found(rest: str):
        raise HTTPException(404, "No such endpoint")

    app.mount("/static", StaticFiles(directory=STATIC), name="static")

    @app.get("/")
    def index():
        return FileResponse(STATIC / "index.html")

    return app


def serve(data_root, ops=None, systems=None, host="127.0.0.1", port=8765):
    import uvicorn
    fabric = Fabric(data_root, ops, systems)
    print(f"Knowledge Fabric UI on http://{host}:{port}  (graph {fabric.g.path.name}, read-only)")
    uvicorn.run(create_app(fabric), host=host, port=port, log_level="warning")
