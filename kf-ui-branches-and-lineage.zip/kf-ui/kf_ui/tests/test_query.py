"""Tests on the synthetic graphs. No AWS, no network."""

import ast
import pathlib

import pytest

from kf_ui.query import Fabric
from kf_ui.query.redact import redact
from kf_ui.sample.build_sample import build

R2D = "aws.glue_job.auk-prd-cdp-raw2dis-arc1-hudi-load-batch"
R2D_SM = "aws.sfn.auk-prd-cdp-datapipeline-arc1-comp-event-raw2dis-sh5"
DIS_ADDR = "glue.auk_prd_cdp_dis_db.arc1_composer_dbo_address"
PUB_ADDR = "glue.auk_prd_adx_pub_db.adviser_address"


def _fabric(root):
    return Fabric(root, root / "config" / "ops.yaml", root / "config" / "source_systems.yaml")


@pytest.fixture(scope="session")
def full(tmp_path_factory):
    return _fabric(build(tmp_path_factory.mktemp("full"), "full"))


@pytest.fixture(scope="session")
def today(tmp_path_factory):
    return _fabric(build(tmp_path_factory.mktemp("today"), "today"))


def names(result):
    return {r["name"] for gr in result["groups"] for r in gr["rows"]}


def test_no_aws_sdk_imports():
    pkg = pathlib.Path(__file__).resolve().parents[1]
    for f in pkg.rglob("*.py"):
        tree = ast.parse(f.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            mods = [a.name for a in node.names] if isinstance(node, ast.Import) else \
                [node.module or ""] if isinstance(node, ast.ImportFrom) else []
            for m in mods:
                assert not m.split(".")[0] in ("boto3", "botocore", "aioboto3"), f"{f} imports {m}"


def test_graph_opened_read_only(full):
    import duckdb
    con = duckdb.connect()
    con.execute(f"ATTACH '{full.g.path.as_posix()}' AS x (READ_ONLY)")
    con.close()  # a writer holding the file would make this fail; the Fabric keeps no connection open


def test_failure_does_not_fan_out_by_job(full):
    # one branch of the raw2dis job: only its own table and what derives from it
    r = full.failure(R2D, "arc1_composer_dbo_contribution")
    n = names(r)
    assert "arc1_composer_dbo_contribution" in n
    assert "arc1_composer_dbo_address" not in n


def test_failure_whole_job(full):
    r = full.failure(R2D)
    n = names(r)
    assert {"arc1_composer_dbo_address", "adviser_domain_adviser_address", "adviser_address",
            "Adviser dashboard", "mylo.adviser_address"} <= n
    assert "arc2_composer_dbo_address" not in n
    titles = [s["title"] for s in r["steps"]]
    assert titles[0] == "Check the inputs arrived"
    assert titles[1].startswith("Restart auk-prd-cdp-datapipeline-arc1")
    kinds = {s["handoff"]["type"] for s in r["steps"] if s.get("handoff")}
    assert {"schedule_only", "event", "no_trigger_found"} <= kinds


def test_handoff_not_harvested_today(today):
    r = today.failure(R2D)
    kinds = {s["handoff"]["type"] for s in r["steps"] if s.get("handoff")}
    assert kinds == {"not_harvested"}
    assert any("Consumers are not harvested" in n for n in r["notes"])


def test_stale_traces_one_path_and_finds_schedule_cause(full):
    r = full.stale(PUB_ADDR)
    up = next(gr for gr in r["groups"] if gr["name"].startswith("Upstream"))
    ups = {x["name"] for x in up["rows"]}
    assert "arc1_dbo_address" in ups and "arc1_dbo_contribution" not in ups
    assert "Likely cause" in r["steps"][0]["detail"]


def test_stale_without_load_times(today):
    r = today.stale("glue.dis_domain.adviser_domain_adviser_address")
    assert "no load times" in r["steps"][0]["detail"].lower()


def test_column_change(full):
    r = full.column_change(f"{DIS_ADDR}.postcode")
    n = names(r)
    assert "arc2_composer_dbo_address.postcode" in n and "arc3_composer_dbo_address.postcode" in n
    assert "dis/mi_decom/arc1/adviser_domain/adviser_address.sql" in n
    assert "adviser_address.postcode" in n
    assert any(gr["layer"] == "table_only" for gr in r["groups"])


def test_column_change_today_notes_raw_to_distill_only(today):
    r = today.column_change(f"{DIS_ADDR}.postcode")
    assert any("Customer" in x for x in names(r)) is False
    assert r["steps"]


def test_config_deps(full):
    r = full.config_deps("auk-prd-cdp-data-mapping-config-table")
    item = next(i for i in r["items"] if i["config_key"] == "arc1_composer_dbo_address")
    assert [w["key"] for w in item["writes"]] == [DIS_ADDR]
    assert R2D_SM in [s["key"] for s in item["state_machines"]]
    assert r["totals"]["consumers_downstream"] >= 1


def test_terms_rank_and_question_words(full, today):
    r = full.terms("Where can I get the platform charges applied to a wrapper or policy?")
    assert r["terms"][0]["term"] == "platform charge" and r["terms"][0]["approved"]
    r = full.terms("Which table holds contribution details?")
    assert r["terms"][0]["term"] == "contribution"
    t = today.terms("contribution")
    assert t["terms"] == [] and t["names"] and "not in this snapshot" in t["note"]


def test_search_and_aliases(full):
    assert full.search("TargetPlan")["alias_system"] == "COMPASS"
    keys = [r["key"] for r in full.search("adviser_address")["results"]]
    assert PUB_ADDR in keys


def test_detail_redacts(full):
    assert redact({"host": "x", "port": 1, "username_key": "u", "pswd_key": "p", "table": "ok"}) == \
        {"host": "[hidden]", "port": "[hidden]", "username_key": "[hidden]", "pswd_key": "[hidden]", "table": "ok"}
    d = full.detail(R2D)
    assert d["orchestrators"][0]["key"] == R2D_SM
    assert len(d["bound_instances"]) == 3


def test_flow_handoffs(full):
    f = full.flow("glue.dis_domain.contribution_domain_member_contributions")
    labels = [s["handoff_in"]["label"] for s in f["segments"] if s["handoff_in"]]
    assert "Event" in labels


def test_ops(full):
    problems = full.health()["ops_problems"]
    assert [p["key"] for p in problems] == ["aws.glue_job.does-not-exist"]
    assert full.ops.tags("aws.glue_job.auk-prd-cust-dis-generic-extract") == ["not recorded: add to ops.yaml"]
    draft = full.ops_draft()
    assert R2D + ":" not in draft and "aws.sfn.auk-prd-cust-domain-generic-extract-sh1:" in draft


def test_ambiguous_job_gap_shown(full):
    r = full.health()
    assert any(x["reason"] == "ambiguous_job" for x in r["gaps"])


def test_runbook(full):
    md = full.runbook("failure", R2D)
    assert md.startswith("# Recovery checklist") and "as of the snapshot" in md


# ---------------------------------------------------------------- inventory
def test_inventory_kinds_and_counts(full):
    s = {x["kind"]: x["n"] for x in full.inventory_summary()}
    assert s["tables"] == 24 and s["glue_jobs"] == 11 and s["state_machines"] == 11
    assert s["dms_tasks"] == 3 and s["lambdas"] == 1 and s["consumers"] == 6


def test_inventory_filters_facets_and_paging(full):
    r = full.inventory("tables", filters={"layer": "distill"}, limit=2)
    assert r["matched"] == 6 and len(r["rows"]) == 2
    layer_facet = {f["value"]: f["n"] for f in r["facets"]["layer"]}
    assert layer_facet["raw"] == 6  # facet counts ignore their own filter
    cols = [c["id"] for c in r["columns"]]
    assert "distill_kind" in cols and "raw_stage" not in cols  # columns empty for every match are hidden
    r = full.inventory("tables", sort="outputs", desc=True, limit=1)
    assert r["rows"][0]["outputs"] == max(x["outputs"] for x in full.inventory("tables", limit=100)["rows"])


def test_inventory_quick_filters(full, today):
    j = full.inventory("glue_jobs", quick=["no_lineage"])
    assert {r["name"] for r in j["rows"]} == {"auk-prd-pal-generic-extract-a", "auk-prd-pal-generic-extract-b"}
    sm = full.inventory("state_machines", filters={"trigger": "event"})
    assert [r["name"] for r in sm["rows"]] == ["auk-prd-contrib-domain-generic-extract-sh1"]
    assert {f["value"] for f in today.inventory("state_machines")["facets"]["trigger"]} == {"not harvested"}
    jobs = full.inventory("glue_jobs", quick=["no_ops"])
    assert R2D not in [r["key"] for r in jobs["rows"]]


def test_inventory_csv(full):
    text = full.inventory_csv("dms_tasks")
    assert text.splitlines()[0].startswith("key,Name") and len(text.splitlines()) == 4


def test_account_ids_masked(monkeypatch):
    from kf_ui.query.redact import mask_text
    monkeypatch.delenv("KF_UI_SHOW_ACCOUNT_IDS", raising=False)
    s = "s3://auk-prd-data-scripts-eu-west-1-123456789012/glue/x.py"
    assert "123456789012" not in mask_text(s)
    arn = redact({"aws": {"arn": "arn:aws:states:eu-west-2:123456789012:stateMachine:x"}})["aws"]["arn"]
    assert arn == "arn:aws:states:eu-west-2:<account>:stateMachine:x"
    monkeypatch.setenv("KF_UI_SHOW_ACCOUNT_IDS", "1")
    assert "123456789012" in mask_text(s)


def test_empty_results_explain_themselves(full):
    r = full.failure("aws.glue_job.auk-prd-pal-generic-extract-a")
    assert r["groups"] == [] and "no recorded outputs" in r["empty"]
    assert r["empty"] in full.runbook("failure", "aws.glue_job.auk-prd-pal-generic-extract-a")
    s = full.stale("src.sqlserver.PRD_AGComposer.dbo.address")
    assert "No lineage into this table" in s["empty"]


def test_flow_keeps_parallel_branches_in_dependency_order(full):
    f = full.flow("glue.dis_domain.customer_domain_customer_address_unified")
    by = {s["key"]: s for s in f["segments"]}
    pos = {s["key"]: s["n"] for s in f["segments"]}
    for arc in ("arc1", "arc2", "arc3"):
        dms, sm = f"aws.dms_task.{arc}-composer-cdc", f"aws.sfn.auk-prd-cdp-datapipeline-{arc}-comp-event-raw2dis-sh5"
        assert pos[dms] < pos[sm]
        assert [a["step"] for a in by[sm]["after"]] == [pos[dms]]
    unified = by["aws.sfn.auk-prd-cust-domain-generic-extract-sh1"]
    assert len(unified["after"]) == 3 and unified["n"] == len(f["segments"])
    assert by["aws.dms_task.arc2-composer-cdc"]["after"] == []  # a separate input, not "after" another DMS task


CTXN = "aws.glue_job.auk-prd-cdp-ctxn-dis-generic-extract"
SUMM = "glue.dis_domain.arc2_chgtxn_charge_credit_summary_adviser"


def test_branch_names_its_state_machine(full):
    sm, cands = full.g.orchestrator_choice(R2D, "arc1_composer_dbo_address")
    assert sm == R2D_SM and cands == [R2D_SM]


def test_shared_job_without_bound_branch_is_not_guessed(full):
    sm, cands = full.g.orchestrator_choice(CTXN, "dis_hudi_arc2_chgtxn_charge_credit_summary_adviser")
    assert sm is None and len(cands) == 2
    f = full.flow(SUMM)
    step = next(s for s in f["segments"] if s["key"] == CTXN)
    assert step["kind"] == "unknown_state_machine" and len(step["candidates"]) == 2
    r = full.failure("aws.glue_job.auk-prd-cdp-raw2dis-arc2-hudi-load-batch")
    assert any(st["title"].startswith("Find which state machine runs auk-prd-cdp-ctxn-dis-generic-extract") for st in r["steps"])
    r = full.failure(CTXN)
    assert r["steps"][1]["title"] == "Restart the state machine that ran it"
    s = full.stale(SUMM)
    w = next(gr for gr in s["groups"] if gr["name"].startswith("Writers"))
    assert "run by one of" in w["rows"][0]["why"]


def test_flow_orders_links_inside_a_step(full):
    f = full.flow(SUMM)
    step = next(s for s in f["segments"] if s["key"] == CTXN)
    assert [(st["from"]["name"], st["to"]["name"]) for st in step["steps"]] == [
        ("arc2_composer_dbo_address", "arc2_chgtxn_charge_credit_txn_adviser"),
        ("arc2_chgtxn_charge_credit_txn_adviser", "arc2_chgtxn_charge_credit_summary_adviser")]


def test_job_detail_branches_combine_state_machine_inputs_outputs(full):
    d = full.detail(R2D)
    rows = {r["config_key"]: r for r in d["branches"]}
    r = rows["arc1_composer_dbo_address"]
    assert [x["key"] for x in r["state_machines"]] == [R2D_SM]
    assert [x["name"] for x in r["reads"]] == ["arc1_dbo_address"]
    assert [x["name"] for x in r["writes"]] == ["arc1_composer_dbo_address"]
    d = full.detail(CTXN)
    assert all(not r["state_machines"] for r in d["branches"])  # not recorded: never guessed
    assert len(d["unbranched_orchestrators"]) == 2


def test_lineage_diagram_queries(full):
    s = full.lineage_start(DIS_ADDR + ".postcode")
    assert s["root"]["key"] == DIS_ADDR and s["focus_column"] == DIS_ADDR + ".postcode"
    assert s["root"]["has_up"] and s["root"]["has_down"]
    up = full.lineage_step(DIS_ADDR, "up")
    assert [n["name"] for n in up["nodes"]] == ["arc1_dbo_address"]
    assert up["edges"][0]["job_name"] == "auk-prd-cdp-raw2dis-arc1-hudi-load-batch"
    assert up["edges"][0]["orchestrator"]["key"] == R2D_SM
    down = full.lineage_step(DIS_ADDR, "down", limit=1)
    assert down["total"] == 2 and down["more"] == 1 and len(down["nodes"]) == 1
    pub = full.lineage_step("glue.auk_prd_adx_pub_db.adviser_address", "down")
    assert [n["name"] for n in pub["nodes"]] == ["Adviser dashboard"] and pub["edges"][0]["type"] == "consumes"
    cols = full.lineage_columns(DIS_ADDR)["columns"]
    pc = next(c for c in cols if c["name"] == "postcode")
    assert pc["n_up"] == 1 and pc["n_down"] == 2


def test_column_path_follows_direction_only(full):
    p = full.column_path(DIS_ADDR + ".postcode")
    names = {(c["table"].split(".")[-1], c["name"]) for c in p["columns"]}
    assert ("arc1_dbo_address", "postcode") in names and ("adviser_address", "postcode") in names
    # the customer table also takes postcode from ARC2 and ARC3; those are siblings, not on this path
    assert ("arc2_composer_dbo_address", "postcode") not in names
