import { html, useState } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { go, href } from "../lib/router.js";
import { forget, recent } from "../lib/recent.js";
import { LAYERS, LAYER_LABEL, Layer, Loading, Picker, Stats, detailHref, layerVar } from "../lib/ui.js";

// Each task card starts its task directly: pick a component and the right screen opens.
const TASKS = [
  { id: "fail", title: "Something failed", text: "What it affects, and the recovery checklist.",
    types: ["glue_job", "pipeline", "dms_task", "lambda_function"], hint: "e.g. a raw2dis job",
    open: (r) => go("impact", { mode: "failure", key: r.key }) },
  { id: "stale", title: "Data looks stale", text: "Who populates the table, which hop may be behind, and who is affected.",
    types: ["table", "extract"], hint: "e.g. adviser_address",
    open: (r) => go("impact", { mode: "stale", key: r.key }) },
  { id: "change", title: "Planning a change", text: "Config, code, downstream columns and consumers a column change touches.",
    types: ["column"], hint: "e.g. postcode",
    open: (r) => go("impact", { mode: "column", key: r.key }) },
  { id: "trace", title: "Trace a table", text: "What feeds it, what it feeds, and the jobs in between.",
    types: ["table", "extract"], hint: "e.g. arc1_composer_dbo_address",
    open: (r) => go("lineage", { key: r.key }) },
];

const HARVEST = [
  ["triggers_harvested", "Triggers (schedules and events)"],
  ["consumers_harvested", "Consumers (dashboards, APIs, extracts)"],
  ["terms_harvested", "Business terms"],
  ["load_times_present", "Load times"],
  ["column_lineage_beyond_distill", "Column lineage beyond Distill"],
];

function TaskCard({ t }) {
  return html`<section class="card stack" style="gap:8px" aria-labelledby=${"t-" + t.id}>
    <h2 id=${"t-" + t.id}>${t.title}</h2>
    <p class="muted" style="margin:0">${t.text}<span class="sr"> Pick ${t.hint}.</span></p>
    <${Picker} id=${"home-" + t.id} types=${t.types} placeholder=${t.hint} onPick=${t.open} />
  </section>`;
}

function TermsCard() {
  const [q, setQ] = useState("");
  const submit = (e) => { e.preventDefault(); if (q.trim()) go("discover", { tab: "terms", q: q.trim() }); };
  return html`<section class="card stack" style="gap:8px" aria-labelledby="t-terms">
    <h2 id="t-terms">Find data by meaning</h2>
    <p class="muted" style="margin:0">Where a business term lives: tables, columns and systems.</p>
    <form onSubmit=${submit} class="row" style="flex-wrap:nowrap">
      <label class="sr" for="home-terms">Business term or question</label>
      <input id="home-terms" class="input big" type="search" value=${q} onInput=${(e) => setQ(e.target.value)}
        placeholder="e.g. platform charges" />
      <button class="btn primary" type="submit" style="height:46px">Find</button>
    </form>
  </section>`;
}

function ConfigCard() {
  const { data } = useApi("/api/config/tables", {}, "cfg");
  return html`<section class="card stack" style="gap:8px" aria-labelledby="t-cfg">
    <h2 id="t-cfg">Config dependencies</h2>
    <p class="muted" style="margin:0">Which jobs and state machines a DynamoDB config table drives, and what they write.</p>
    <label class="sr" for="home-cfg">Config table</label>
    <select id="home-cfg" class="select" style="height:46px" value=""
      onChange=${(e) => e.target.value && go("discover", { tab: "config", table: e.target.value })}>
      <option value="">Choose a config table…</option>
      ${(data || []).map((t) => html`<option value=${t.name}>${t.name} (${t.items} items)</option>`)}
    </select>
  </section>`;
}

function Recent() {
  const [list, setList] = useState(recent());
  if (!list.length) return null;
  return html`<section class="card stack" style="gap:8px" aria-labelledby="h-recent">
    <div class="row" style="justify-content:space-between"><h2 id="h-recent">Recently viewed</h2>
      <button class="btn small" onClick=${() => { forget(); setList([]); }}>Clear</button></div>
    <div class="row">${list.map((c) => html`<a class="chip" href=${detailHref(c.key)} title=${c.key}>
      <span class="mono">${c.name}</span><span class="n">${c.label || c.type}</span></a>`)}</div>
  </section>`;
}

export function Home({ meta }) {
  return html`
    <section class="stack" style="gap:8px" aria-labelledby="h-find">
      <h1 id="h-find">What are you looking for?</h1>
      <${Picker} id="home-search" placeholder="Find a table, job, state machine, column or config key"
        autofocus=${true} onPick=${(r) => go("detail", { key: r.key })} />
    </section>
    <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(min(100%,380px),1fr))">
      ${TASKS.map((t) => html`<${TaskCard} t=${t} />`)}
      <${TermsCard} />
      <${ConfigCard} />
    </div>
    <${Recent} />
    ${!meta ? html`<${Loading} />` : html`
      <${Stats} items=${[
        { n: meta.counts.tables.toLocaleString(), label: "Tables" }, { n: meta.counts.columns.toLocaleString(), label: "Columns" },
        { n: meta.counts.glue_jobs.toLocaleString(), label: "Glue jobs" }, { n: meta.counts.state_machines.toLocaleString(), label: "State machines" },
        { n: meta.counts.dms_tasks.toLocaleString(), label: "DMS tasks" }, { n: meta.counts.lambdas.toLocaleString(), label: "Lambda functions" },
        { n: meta.counts.edges.toLocaleString(), label: "Links in the graph" }]} />
      <div class="split">
        <section class="card main stack" aria-labelledby="h-layers">
          <h2 id="h-layers">Tables by layer</h2>
          ${LAYERS.filter((l) => meta.tables_by_layer[l]).map((l) => {
            const total = Object.values(meta.tables_by_layer).reduce((a, b) => a + b, 0) || 1;
            return html`<a class="row" href=${href("inventory", { kind: "tables", "f.layer": l })} style="color:var(--ink)">
              <span style="width:110px">${LAYER_LABEL[l]}</span>
              <span class="grow" style="background:var(--surface-2);border-radius:4px;height:10px">
                <span style=${`display:block;height:10px;border-radius:4px;background:${layerVar(l)};width:${(100 * meta.tables_by_layer[l] / total).toFixed(1)}%`}></span>
              </span>
              <b style="width:60px;text-align:right">${meta.tables_by_layer[l].toLocaleString()}</b>
            </a>`;
          })}
          <h3 style="margin-top:8px">Systems</h3>
          <div class="row">${Object.entries(meta.systems).map(([s, n]) => html`
            <a class="chip" href=${href("inventory", { kind: "tables", "f.system": s })}>${s} <span class="n">${n}</span></a>`)}</div>
        </section>
        <section class="card side stack" aria-labelledby="h-health">
          <h2 id="h-health">In this snapshot</h2>
          <ul style="margin:0;padding-left:0;list-style:none" class="stack">${HARVEST.map(([k, label]) => html`
            <li class="row"><span class=${"badge " + (meta.flags[k] ? "green" : "amber")}>${meta.flags[k] ? "Yes" : "Not yet"}</span> ${label}</li>`)}</ul>
          <p style="margin:0"><a href=${href("health")}>${meta.gaps_total.toLocaleString()} open gaps</a>${meta.ops_problems ? html` · ${meta.ops_problems} ops.yaml problems` : null}</p>
        </section>
      </div>`}`;
}
