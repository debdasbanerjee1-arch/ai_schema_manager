import { html, useEffect, useState } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { remember } from "../lib/recent.js";
import { href } from "../lib/router.js";
import { Badge, Empty, ErrorBox, Gaps, Layer, Loading, NodeLink, OpsTags, TYPE_LABEL, copyText, detailHref } from "../lib/ui.js";

const JOBS = ["glue_job", "lambda_function", "dms_task"];

const List = ({ title, items }) => (items && items.length) ? html`
  <section class="stack" style="gap:6px"><h3>${title} · ${items.length}</h3>
    <div class="rows">${items.map((n) => html`<div class="rowi"><span class="nm"><${NodeLink} node=${n} /></span>
      ${n.layer && n.layer !== "none" ? html`<${Layer} layer=${n.layer} />` : null}</div>`)}</div></section>` : null;

function value(v) {
  if (v === null || v === undefined) return "";
  if (typeof v === "object") return html`<code class="mono">${JSON.stringify(v)}</code>`;
  return String(v);
}

function Actions({ c }) {
  const t = c.type;
  const links = [];
  if (t === "table" || t === "extract") {
    links.push(["Lineage", href("lineage", { key: c.key })], ["End-to-end flow", href("flow", { key: c.key })],
      ["Stale check", href("impact", { mode: "stale", key: c.key })]);
  } else if (t === "column") {
    links.push(["Column lineage", href("lineage", { key: c.key, level: "column" })], ["Column change", href("impact", { mode: "column", key: c.key })]);
  } else if (JOBS.includes(t) || t === "pipeline") {
    links.push(["Failure impact", href("impact", { mode: "failure", key: c.key })]);
  }
  return html`<div class="row noprint">${links.map(([l, h], i) => html`<a class=${"btn" + (i === 0 ? " primary" : "")} href=${h}>${l}</a>`)}</div>`;
}

export function Detail({ params }) {
  const key = params.get("key");
  const { data, error, loading } = useApi("/api/detail", { key }, key);
  const [copied, setCopied] = useState(false);
  useEffect(() => { if (data) remember(data.component); }, [data]);
  if (!key) return html`<${Empty}>Pick a component from search or the inventory.</${Empty}>`;
  if (error) return html`<${ErrorBox} error=${error} />`;
  if (loading || !data) return html`<${Loading} />`;
  const c = data.component;
  return html`
    <div class="stack" style="gap:8px">
      <div class="row muted small"><span>${c.label}</span>${c.layer && c.layer !== "none" ? html` · <${Layer} layer=${c.layer} />` : null}
        ${c.system ? html` · <span>${c.system}</span>` : null}</div>
      <h1 class="mono" style="font-size:20px">${c.name}</h1>
      <div class="row"><code class="mono muted">${c.key}</code>
        <button class="btn small" onClick=${async () => setCopied(await copyText(c.key))}>${copied ? "Copied" : "Copy key"}</button></div>
      <${OpsTags} tags=${data.ops_tags} />
      <${Actions} c=${c} />
    </div>
    <div class="split">
      <div class="main stack">
        ${data.columns ? html`<section class="card stack"><h2>Columns · ${data.columns.length}</h2>
          ${data.columns.length ? html`<div class="tablewrap" style="max-height:420px"><table class="data">
            <thead><tr><th>Column</th><th>Type</th><th>Key</th><th>Partition</th></tr></thead>
            <tbody>${data.columns.map((col) => html`<tr>
              <td><a class="mono" href=${detailHref(col.key)}>${col.name.split(".").pop()}</a></td>
              <td class="mono">${col.data_type || ""}</td>
              <td>${col.pk_ordinal ? html`<${Badge} tone="accent">PK ${col.pk_ordinal}</${Badge}>` : col.is_key_discriminator ? html`<${Badge}>discriminator</${Badge}>` : ""}</td>
              <td>${col.is_partition_key ? "yes" : ""}</td></tr>`)}</tbody></table></div>` : html`<p class="muted" style="margin:0">No column nodes (source tables have none).</p>`}
        </section>` : null}
        ${JOBS.includes(c.type) ? html`<section class="card stack">
          <${List} title="Run by" items=${data.orchestrators} />
          ${data.bound_instances && data.bound_instances.length ? html`<section class="stack" style="gap:6px">
            <h3>Branches (config items) · ${data.bound_instances.length}</h3>
            <div class="rows">${data.bound_instances.map((b) => html`<div class="rowi">
              <span class="nm mono">${b.config_key}</span><span class="why">${b.config_table}</span>
              <a class="btn small" href=${href("impact", { mode: "failure", key: c.key, ck: b.config_key })}>Impact of this branch</a></div>`)}</div>
          </section>` : null}
          <${List} title="Inputs" items=${data.inputs} />
          <${List} title="Outputs" items=${data.outputs} />
          ${!data.orchestrators.length && !data.inputs.length && !data.outputs.length ? html`<p class="note" style="margin:0">
            Not linked to anything in the graph: no state machine runs it and it has no recorded inputs or outputs.</p>` : null}
        </section>` : null}
        ${c.type === "pipeline" ? html`<section class="card stack">
          <section class="stack" style="gap:6px"><h3>Trigger</h3>
            ${data.triggers === null || data.triggers === undefined ? html`<p class="muted" style="margin:0">Not harvested in this snapshot.</p>`
              : data.triggers.length ? html`<div class="rows">${data.triggers.map((t) => html`<div class="rowi"><span class="nm">${t.kind}</span>
                  <span class="why mono">${t.expression || t.rule || t.name || ""}</span></div>`)}</div>`
              : html`<p class="muted" style="margin:0">None found.</p>`}</section>
          <${List} title="Jobs and functions it runs" items=${data.jobs} />
          <${List} title="State machines it starts" items=${data.children} />
          <${List} title="Started by" items=${data.started_by} />
        </section>` : null}
        ${c.type === "column" ? html`<section class="card stack">
          <${List} title="Derived from" items=${data.upstream} />
          <${List} title="Feeds" items=${data.downstream} />
          <${List} title="Business terms" items=${data.terms} />
          ${!data.upstream.length && !data.downstream.length ? html`<p class="muted" style="margin:0">No column lineage recorded for this column.</p>` : null}
        </section>` : null}
        ${data.consumers && data.consumers.length ? html`<section class="card"><${List} title="Consumers" items=${data.consumers} /></section>` : null}
        <section class="card stack"><h2>Connections</h2>
          ${data.neighbours.length ? data.neighbours.map((g) => html`<details>
            <summary><b>${g.group}</b> <span class="muted">${g.size}</span></summary>
            <div class="rows" style="margin-top:6px">${g.rows.map((r) => html`<div class="rowi">
              <span class="nm"><${NodeLink} node=${r} /></span>
              <span class="why small">${[r.edge.origin, r.edge.tier, r.edge.config_key, r.edge.job ? "job " + r.edge.job.split(".").pop() : ""].filter(Boolean).join(" · ")}</span></div>`)}
              ${g.size > g.rows.length ? html`<p class="muted small">Showing ${g.rows.length} of ${g.size}.</p>` : null}</div></details>`)
            : html`<p class="muted" style="margin:0">No connections.</p>`}
        </section>
      </div>
      <aside class="side stack">
        ${data.loaded ? html`<section class="card"><h3>Last loaded</h3><p style="margin:6px 0 0">${data.loaded.at}
          <span class="muted small"> (${data.loaded.source}, as of snapshot)</span></p></section>` : null}
        ${data.ops ? html`<section class="card stack"><h2>ops.yaml</h2><dl class="kv">${Object.entries(data.ops).map(([k, v]) => html`<dt>${k}</dt><dd>${
          k === "runbook_url" ? html`<a href=${v} target="_blank" rel="noopener">${v}</a>` : v}</dd>`)}</dl></section>` : null}
        <${Gaps} gaps=${data.gaps} title="Gaps naming this component" />
        <section class="card stack"><h2>Attributes</h2>
          <dl class="kv">${Object.entries(data.attrs).filter(([k]) => !["evidence", "snapshot"].includes(k)).map(([k, v]) => html`<dt>${k}</dt><dd>${value(v)}</dd>`)}</dl>
          ${data.attrs.evidence ? html`<details><summary class="muted">Evidence (${data.attrs.evidence.length})</summary>
            <ul class="mono small">${data.attrs.evidence.map((e) => html`<li>${e}</li>`)}</ul></details>` : null}
        </section>
      </aside>
    </div>`;
}
