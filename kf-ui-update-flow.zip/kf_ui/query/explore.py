"""Search, component detail, lineage, end-to-end flow, config dependencies, terms, health."""

from __future__ import annotations

from collections import Counter, deque

from . import certainty as cert
from .impact import _consumers, _downstream, _orch, handoff
from .redact import redact
from .store import CONSUMER_TYPES, JOB_TYPES, ORCH_TYPES
from .text import match_score, norm, stems, words_of

TYPE_LABEL = {"table": "Table", "column": "Column", "glue_job": "Glue job", "lambda_function": "Lambda",
              "dms_task": "DMS task", "pipeline": "State machine", "pipeline_task": "State",
              "extract": "Extract", "dashboard": "Dashboard", "api_endpoint": "API", "glossary_term": "Term",
              "channel": "Channel", "data_model": "Data model", "chart": "Chart"}


def meta(g, ops):
    c = Counter(n["type"] for n in g.nodes.values())
    layers = Counter(n["layer"] for n in g.nodes.values() if n["type"] == "table")
    return {"snapshot": g.snapshot_id, "built_at": g.built_at, "graph_file": g.path.name,
            "counts": {"tables": c.get("table", 0), "columns": len(g.columns), "glue_jobs": c.get("glue_job", 0),
                       "state_machines": c.get("pipeline", 0), "dms_tasks": c.get("dms_task", 0),
                       "lambdas": c.get("lambda_function", 0), "nodes": len(g.nodes) + len(g.columns),
                       "edges": sum(len(v) for v in g.out.values())},
            "tables_by_layer": dict(layers), "systems": dict(Counter(n["system"] for n in g.nodes.values()
                                                                      if n["type"] == "table" and n["system"]).most_common()),
            "flags": g.flags, "gaps_total": len(g.gaps), "coverage": coverage(g), "gaps": gaps_summary(g)[:8],
            "certainty_legend": cert.legend(),
            "gaps_by_reason": dict(Counter(x.get("reason") for x in g.gaps).most_common()),
            "ops_problems": len(ops.validate(g))}


# ---------------------------------------------------------------- search
def search(g, q, types=None, layer=None, system=None, limit=50, aliases=None, include_columns=True,
           include_one_off=False):
    aliases = {norm(k): v for k, v in (aliases or {}).items()}
    sys_from_alias = aliases.get(norm(q))
    results = []
    for k, n in g.nodes.items():
        if n["type"] == "pipeline_task":
            continue
        if types and n["type"] not in types:
            continue
        if layer and n["layer"] != layer:
            continue
        if system and n.get("system") != system:
            continue
        if not include_one_off and n["attrs"].get("replication_mode") == "one_off":
            continue
        s = match_score(q, n["name"], k)
        if not s and sys_from_alias and n.get("system") == sys_from_alias:
            s = 20
        if s:
            results.append((s, {**g.ref(k), "label": TYPE_LABEL.get(n["type"], n["type"])}))
    if include_columns and (not types or "column" in types) and len(norm(q)) >= 3:
        for k, c in g.columns.items():
            s = match_score(q, c["name"])
            if s >= 60:
                r = g.ref(k)
                if layer and r["layer"] != layer or system and r["system"] != system:
                    continue
                results.append((s - 5, {**r, "label": "Column"}))
    results.sort(key=lambda x: (-x[0], x[1]["name"]))
    return {"query": q, "alias_system": sys_from_alias, "total": len(results),
            "results": [r for _, r in results[:limit]]}


# ---------------------------------------------------------------- detail
def detail(g, ops, key):
    n = g.get(key)
    if not n:
        raise KeyError(key)
    nb = {}
    for e in g.out.get(key, ()):
        nb.setdefault(f"{e.type}{'/' + e.relation if e.relation else ''} →", []).append({**g.ref(e.dst), "edge": e.brief()})
    for e in g.inn.get(key, ()):
        nb.setdefault(f"← {e.type}{'/' + e.relation if e.relation else ''}", []).append({**g.ref(e.src), "edge": e.brief()})
    neighbours = [{"group": k, "size": len(v), "rows": v[:50]} for k, v in sorted(nb.items())]
    out = {"component": {**g.ref(key), "label": TYPE_LABEL.get(n["type"], n["type"])},
           "attrs": redact(n.get("attrs", {})), "ops": ops.get(key), "ops_tags": ops.tags(key),
           "neighbours": neighbours, "gaps": g.gaps_for(key), "snapshot": g.snapshot_id, "built_at": g.built_at,
           "attr_certainty": {k: cert.certainty("derived_name" if k == "source_equivalent" else None, None,
                                                n.get("attrs", {}).get(k + "_method") or n.get("attrs", {}).get("source_equivalent_method"))
                              for k in ("source_equivalent",) if n.get("attrs", {}).get(k)}}
    if n["type"] in JOB_TYPES:
        out["orchestrators"] = [g.ref(o) for o in g.orchestrators_of(key)]
        out["bound_instances"] = g.bound_instances(key)
        out["inputs"] = [g.ref(i) for i, _ in g.job_inputs(key)]
        out["outputs"] = [g.ref(o) for o, _ in g.job_outputs(key)]
        out["branches"], out["unbranched_orchestrators"] = branches(g, key)
    if n["type"] in ORCH_TYPES:
        out["jobs"] = [g.ref(j) for j in g.jobs_of(key)]
        out["children"] = [g.ref(c) for c in g.children_of(key)]
        out["started_by"] = [g.ref(s) for s in g.starters_of(key)]
        out["triggers"] = n["attrs"].get("triggers")
    if n["type"] in ("table", "extract"):
        out["columns"] = [{**g.ref(c), "data_type": g.columns[c]["data_type"], **g.columns[c]["attrs"]}
                          for c in g.table_columns.get(key, [])]
        out["loaded"] = g.load_time(key)
        out["consumers"] = [g.ref(c) for c in g.consumers_of(key)]
    if n["type"] == "column":
        out["upstream"] = [{**g.ref(e.src), "edge": e.brief()} for e in g.column_lineage_in(key)]
        out["downstream"] = [{**g.ref(e.dst), "edge": e.brief()} for e in g.column_lineage_out(key)]
        out["terms"] = [g.ref(e.dst) for e in g.edges_out(key, "means")]
    return out


def branches(g, job):
    """One row per branch (config item) of a job: its state machine, what it reads, what it writes.

    The state machine is only the one named on the branch's own edges (via_state_machine);
    when none is named, state_machines is empty and the screen says "not recorded". Inputs
    and outputs with no config key form a last row with config_key None."""
    rows = {}

    def row(ck, ct=None):
        r = rows.setdefault(ck, {"config_key": ck, "config_table": ct, "state_machines": [], "reads": [], "writes": []})
        if ct and not r["config_table"]:
            r["config_table"] = ct
        return r

    def add(lst, k):
        if k not in lst:
            lst.append(k)

    for e in g.out.get(job, ()):
        ck = e.attrs.get("config_key")
        r = row(ck, e.attrs.get("config_table"))
        sm = g.sfn_key(e.attrs.get("via_state_machine"))
        if sm:
            add(r["state_machines"], sm)
        if e.type == "reads":
            add(r["reads"], e.dst)
        elif e.type == "writes":
            add(r["writes"], e.dst)
    for e in g.inn_by_job.get(job, ()):
        r = row(e.attrs.get("config_key"), e.attrs.get("config_table"))
        add(r["reads"], e.src)
        add(r["writes"], e.dst)
    named = {sm for r in rows.values() for sm in r["state_machines"]}
    unbranched = [g.ref(o) for o in g.orchestrators_of(job) if o not in named]
    out = []
    for ck in sorted(rows, key=lambda k: (k is None, k or "")):
        r = rows[ck]
        if ck is None and not (r["reads"] or r["writes"]):
            continue
        out.append({"config_key": ck, "config_table": r["config_table"],
                    "state_machines": [g.ref(x) for x in r["state_machines"]],
                    "reads": [g.ref(x) for x in r["reads"]], "writes": [g.ref(x) for x in r["writes"]]})
    return out, unbranched


# ---------------------------------------------------------------- lineage
def lineage(g, key, direction="both", depth=3, lens="data", level="table"):
    if level == "column" or g.is_column(key):
        fwd, back = g.column_lineage_out, g.column_lineage_in
    else:
        fwd, back = g.table_lineage_out, g.table_lineage_in
    nodes, edges, seen_e = {key: 0}, [], set()

    def walk(step, sign):
        q = deque([(key, 0)])
        while q:
            x, d = q.popleft()
            if d >= depth:
                continue
            for e in step(x):
                y = e.dst if sign > 0 else e.src
                if e.id not in seen_e:
                    seen_e.add(e.id)
                    edges.append(e)
                if y not in nodes:
                    nodes[y] = sign * (d + 1)
                    q.append((y, d + 1))
    if direction in ("both", "down"):
        walk(fwd, 1)
    if direction in ("both", "up"):
        walk(back, -1)
    out_nodes = []
    for k, d in nodes.items():
        r = {**g.ref(k), "depth": d, "gaps": len(g.gaps_for(k)), "loaded": g.load_time(k)}
        if level == "table" and not g.is_column(k):
            r["consumers"] = [g.ref(c) for c in g.consumers_of(k)]
            r["more_up"] = bool(g.table_lineage_in(k)) and d == -depth
            r["more_down"] = bool(g.table_lineage_out(k)) and d == depth
        out_nodes.append(r)
    out_edges = []
    for e in edges:
        b = e.brief()
        if lens == "orchestration" and e.job:
            o, cands = g.orchestrator_choice(e.job, e.attrs.get("config_key"))
            b["job_name"] = g.name(e.job)
            b["orchestrator"] = g.ref(o) if o else None
            b["orchestrator_candidates"] = [g.ref(c) for c in cands] if not o and len(cands) > 1 else []
        out_edges.append(b)
    return {"root": g.ref(key), "direction": direction, "depth": depth, "lens": lens, "level": level,
            "nodes": out_nodes, "edges": out_edges, "snapshot": g.snapshot_id}


# ---------------------------------------------------------------- lineage diagram (one hop at a time)
def node_info(g, key):
    """What the diagram needs to draw one node and its expand handles."""
    n = g.get(key) or {}
    is_table = n.get("type") in ("table", "extract")
    up = g.table_lineage_in(key) if is_table else []
    down = (g.table_lineage_out(key) + g.edges_in(key, "consumes")) if is_table else []
    return {**g.ref(key), "has_up": bool(up), "has_down": bool(down), "n_up": len({e.src for e in up}),
            "n_down": len({e.dst for e in g.table_lineage_out(key)} | {e.src for e in g.edges_in(key, "consumes")}) if is_table else 0,
            "n_cols": len(g.table_columns.get(key, ())), "gaps": len(g.gaps_for(key)), "loaded": g.load_time(key)}


def _edge_info(g, e, src, dst):
    b = {"id": e.id, "src": src, "dst": dst, "type": e.type, "origin": e.origin, "tier": e.tier, "certainty": cert.of_edge(e),
         "transform_class": e.tc, "config_key": e.attrs.get("config_key"), "job": e.job,
         "job_name": g.name(e.job) if e.job else None, "orchestrator": None, "orchestrator_candidates": 0}
    if e.job:
        o, cands = g.orchestrator_choice(e.job, e.attrs.get("config_key"))
        b["orchestrator"] = g.ref(o) if o else None
        b["orchestrator_candidates"] = 0 if o else len(cands)
    return b


def lineage_start(g, key):
    """The diagram's starting table. A column key starts from its table, with that column in focus."""
    if g.is_column(key):
        return {"root": node_info(g, g.columns[key]["table"]), "focus_column": key}
    if not g.get(key):
        raise KeyError(key)
    return {"root": node_info(g, key), "focus_column": None}


def lineage_step(g, key, direction, limit=25):
    """The neighbours one hop upstream or downstream of a table, with the links to them."""
    if direction not in ("up", "down"):
        raise ValueError("direction must be up or down")
    if not g.get(key):
        raise KeyError(key)
    pairs = []
    if direction == "up":
        pairs = [(e.src, e, e.src, key) for e in g.table_lineage_in(key)]
    else:
        pairs = [(e.dst, e, key, e.dst) for e in g.table_lineage_out(key)]
        pairs += [(e.src, e, key, e.src) for e in g.edges_in(key, "consumes")]
    order, seen = [], set()
    for k, *_ in pairs:
        if k not in seen:
            seen.add(k)
            order.append(k)
    order.sort(key=lambda k: g.name(k).lower())
    keep = set(order[:limit])
    return {"key": key, "direction": direction, "total": len(order), "more": max(0, len(order) - limit),
            "nodes": [node_info(g, k) for k in order[:limit]],
            "edges": [_edge_info(g, e, s, d) for k, e, s, d in pairs if k in keep]}


def lineage_columns(g, key):
    cols = []
    for c in g.table_columns.get(key, []):
        info = g.columns[c]
        cols.append({"key": c, "name": info["name"], "data_type": info["data_type"],
                     "pk": info["attrs"].get("pk_ordinal"), "n_up": len(g.column_lineage_in(c)),
                     "n_down": len(g.column_lineage_out(c))})
    return {"key": key, "columns": cols}


def column_path(g, col):
    """Every column upstream and downstream of one column, and the links between them.
    Upstream follows only incoming links and downstream only outgoing ones, so sibling
    columns that merely share a source are not included."""
    if not g.is_column(col):
        raise KeyError(col)
    seen, edges = {col}, {}
    for step, nxt in ((g.column_lineage_in, lambda e: e.src), (g.column_lineage_out, lambda e: e.dst)):
        q, visited = deque([col]), {col}
        while q:
            x = q.popleft()
            for e in step(x):
                edges[e.id] = {"id": e.id, "src": e.src, "dst": e.dst, "job": e.job, "expression": e.expr, "certainty": cert.of_edge(e),
                               "transform_class": e.tc, "sql_file": e.attrs.get("sql_file")}
                y = nxt(e)
                if y not in visited:
                    visited.add(y)
                    seen.add(y)
                    q.append(y)
    cols = [{"key": c, "table": g.columns[c]["table"], "name": g.columns[c]["name"]} for c in seen if c in g.columns]
    return {"key": col, "columns": cols, "edges": list(edges.values()), "tables": sorted({c["table"] for c in cols})}


# ---------------------------------------------------------------- end-to-end flow
def flow(g, key, ops=None):
    """The steps a table's data passes through, upstream and downstream, in dependency order.

    A step is one state machine (or a DMS task, or a job no state machine runs). Steps are
    ordered so that every step comes after the steps that write what it reads; parallel
    input branches stay separate. Each step lists the steps it comes after, with the
    hand-off type for each."""
    import heapq

    n = g.get(key)
    if not n:
        raise KeyError(key)
    depth, q, edges, seen = {key: 0}, deque([key]), [], set()
    while q:
        x = q.popleft()
        for e in g.table_lineage_in(x):
            if e.id not in seen:
                seen.add(e.id)
                edges.append(e)
            if e.src not in depth:
                depth[e.src] = depth[x] - 1
                q.append(e.src)
    down, _ = _downstream(g, {key: (None, None)})
    for k, hop, e, job in down:
        if e is not None and e.type == "derives_from" and e.id not in seen:
            seen.add(e.id)
            edges.append(e)
        depth.setdefault(k, hop)

    segs = {}
    for e in edges:
        job, ck = e.job, e.attrs.get("config_key")
        o, cands = g.orchestrator_choice(job, ck) if job else (None, [])
        sk = o or job or f"nojob:{e.dst}"
        if sk not in segs:
            jn = g.nodes.get(job, {}) if job else {}
            kind = "dms" if jn.get("type") == "dms_task" else ("state_machine" if o else (
                "unknown_state_machine" if len(cands) > 1 else ("job" if job else "no_job")))
            segs[sk] = {"key": sk, "orch": o, "orchestrator": g.ref(o) if o else None, "jobs": [], "steps": [],
                        "candidates": [g.ref(c) for c in cands] if kind == "unknown_state_machine" else [], "kind": kind,
                        "reads": set(), "writes": set(), "rank": 10 ** 6,
                        "ops_tags": ops.tags(o or job) if ops and (o or job) else []}
        s_ = segs[sk]
        s_["reads"].add(e.src)
        s_["writes"].add(e.dst)
        s_["rank"] = min(s_["rank"], depth.get(e.src, 0))
        if job and all(j["key"] != job for j in s_["jobs"]):
            s_["jobs"].append(g.ref(job))
        s_["steps"].append({"from": g.ref(e.src), "to": g.ref(e.dst), "job": g.ref(job) if job else None,
                            "config_key": ck, "tier": e.tier, "origin": e.origin, "certainty": cert.of_edge(e),
                            "_d": depth.get(e.src, 0)})

    writers = {}
    for sk, s_ in segs.items():
        for t in s_["writes"]:
            writers.setdefault(t, []).append(sk)
    preds = {sk: {} for sk in segs}
    for sk, s_ in segs.items():
        for t in sorted(s_["reads"]):
            for pk in writers.get(t, ()):
                if pk != sk:
                    preds[sk].setdefault(pk, t)
    succ = {sk: [] for sk in segs}
    for sk, ps in preds.items():
        for pk in ps:
            succ[pk].append(sk)
    indeg = {sk: len(ps) for sk, ps in preds.items()}
    sort_key = lambda sk: (segs[sk]["rank"], g.name(segs[sk]["orch"] or sk))
    heap = [(sort_key(sk), sk) for sk in segs if indeg[sk] == 0]
    heapq.heapify(heap)
    order = []
    while heap:
        _, sk = heapq.heappop(heap)
        order.append(sk)
        for nx in succ[sk]:
            indeg[nx] -= 1
            if indeg[nx] == 0:
                heapq.heappush(heap, (sort_key(nx), nx))
    order += sorted((sk for sk in segs if sk not in order), key=sort_key)  # cycles, if any
    index = {sk: i + 1 for i, sk in enumerate(order)}

    out, written = [], set().union(*(x["writes"] for x in segs.values()))
    for sk in order:
        s_ = segs[sk]
        after = []
        for pk, t in sorted(preds[sk].items(), key=lambda i: index[i[0]]):
            p_ = segs[pk]
            h = handoff(g, p_["orch"], s_["orch"], t, [j["key"] for j in p_["jobs"]]) if s_["orch"] else None
            after.append({"step": index[pk], "name": g.name(p_["orch"] or pk) if not pk.startswith("nojob:") else "a view or derivation",
                          "table": g.ref(t), "handoff": h})
        steps = sorted(s_["steps"], key=lambda st: (st.pop("_d"), st["to"]["name"]))  # upstream first inside a step
        side = ("builds" if key in s_["writes"] else "up" if any(depth.get(t, 1) < 0 for t in s_["writes"])
                else "reads" if key in s_["reads"] else "down")
        out.append({"n": index[sk], "key": sk, "kind": s_["kind"], "orchestrator": s_["orchestrator"], "jobs": s_["jobs"],
                    "candidates": s_["candidates"], "steps": steps, "ops_tags": s_["ops_tags"], "after": after,
                    "handoff_in": after[0]["handoff"] if after else None,
                    "name": g.name(s_["orch"]) if s_["orch"] else (s_["jobs"][0]["name"] if s_["jobs"] else g.name(min(s_["writes"]))),
                    "side": side, "role": _flow_role(g, s_), "group": s_["jobs"][0]["key"] if s_["jobs"] else s_["kind"],
                    "reads": [g.ref(t) for t in sorted(s_["reads"] - s_["writes"], key=g.name)],
                    "writes": [g.ref(t) for t in sorted(s_["writes"], key=lambda t: (t != key, g.name(t)))],
                    "inputs": [g.ref(t) for t in sorted(s_["reads"] - written, key=g.name)],
                    "schedule": _schedule(g, s_["orch"])})
    found = _consumers(g, [key] + [k for k, *_ in down])
    consumers = [{**g.ref(c), "tables": sorted(set(ts))} for c, ts in found.items()]
    return {"table": g.ref(key), "segments": out, "consumers": consumers, "summary": _flow_summary(out, consumers),
            "name_prefix": name_prefix([s["name"] for s in out] + [j["name"] for s in out for j in s["jobs"]]),
            "triggers_harvested": g.flags.get("triggers_harvested"), "snapshot": g.snapshot_id}


def _flow_role(g, seg):
    """What a step does, from what it writes: ingest, load (to Distill), publish, extract or other."""
    if seg["kind"] == "dms":
        return "ingest"
    c = Counter()
    for t in seg["writes"]:
        n = g.nodes.get(t, {})
        a = n.get("attrs", {})
        if n.get("type") in CONSUMER_TYPES or n.get("type") == "extract" or n.get("layer") == "consumer":
            c["extract"] += 1
        elif a.get("distill_kind") == "domain" or n.get("layer") == "published":
            c["publish"] += 1
        elif n.get("layer") == "distill":
            c["load"] += 1
        elif n.get("layer") == "raw":
            c["ingest"] += 1
        else:
            c["other"] += 1
    return c.most_common(1)[0][0] if c else "other"


def _schedule(g, orch):
    """The schedule expressions on a state machine's triggers, if harvested."""
    if not orch:
        return None
    trs = g.nodes.get(orch, {}).get("attrs", {}).get("triggers") or []
    ex = [str(t.get("expression") or t.get("name")) for t in trs if isinstance(t, dict) and t.get("kind") == "schedule"]
    return ", ".join(ex) or None


UNKNOWN_HANDOFFS = {"not_harvested", "no_trigger_found"}


def _flow_summary(segments, consumers):
    by_side = Counter(s["side"] for s in segments)
    readers = [s for s in segments if s["side"] == "reads"]
    handoffs = [a["handoff"] for s in segments for a in s["after"]]
    sources = {t["key"] for s in segments if s["side"] in ("up", "builds") and not s["after"] for t in s["inputs"]}
    return {"sources": len(sources), "builders": by_side["builds"], "upstream": by_side["up"],
            "readers": len(readers), "readers_are_state_machines": bool(readers) and all(s["kind"] == "state_machine" for s in readers),
            "downstream": by_side["down"], "consumers": len(consumers), "handoffs": len(handoffs),
            "unknown_handoffs": sum(1 for h in handoffs if not h or h["type"] in UNKNOWN_HANDOFFS)}


def name_prefix(names, share=0.6):
    """The longest hyphen-separated prefix (up to three parts) that most step names share, e.g.
    'auk-prd-cdp-', so cards can show the part that differs. Empty when none is common enough."""
    names = [n for n in names if n]
    best = ""
    for k in (1, 2, 3):
        c = Counter("-".join(n.split("-")[:k]) + "-" for n in names if n.count("-") >= k)
        if not c:
            break
        p, hits = c.most_common(1)[0]
        if hits >= 2 and hits >= share * len(names):
            best = p
    return best


# ---------------------------------------------------------------- config dependencies
def config_tables(g):
    c = Counter()
    keys = {}
    for es in g.out.values():
        for e in es:
            t = e.attrs.get("config_table")
            if t:
                c[t] += 1
                keys.setdefault(t, set()).add(e.attrs.get("config_key"))
    return [{"name": t, "edges": n, "items": len(keys[t])} for t, n in c.most_common()]


def config_deps(g, config_table, q=""):
    items = {}
    for es in g.out.values():
        for e in es:
            if e.attrs.get("config_table") != config_table:
                continue
            ck = e.attrs.get("config_key") or "(no key)"
            it = items.setdefault(ck, {"config_key": ck, "jobs": set(), "state_machines": set(), "reads": set(),
                                       "writes": set()})
            job = e.job if e.type == "derives_from" else (e.src if g.nodes.get(e.src, {}).get("type") in JOB_TYPES else None)
            if job:
                it["jobs"].add(job)
                for o in g.orchestrators_of(job, ck):
                    it["state_machines"].add(o)
            sm = g.sfn_key(e.attrs.get("via_state_machine"))
            if sm:
                it["state_machines"].add(sm)
            if e.type == "reads":
                it["reads"].add(e.dst)
            elif e.type == "writes":
                it["writes"].add(e.dst)
            elif e.type == "derives_from" and not g.is_column(e.dst):
                it["reads"].add(e.src)
                it["writes"].add(e.dst)
            elif e.type == "derives_from":
                it["writes"].add(g.columns[e.dst]["table"])
    ql = (q or "").lower()
    rows, all_jobs, all_tables, all_cons = [], set(), set(), set()
    for ck, it in sorted(items.items()):
        down, _ = _downstream(g, {t: (None, None) for t in it["writes"]})
        cons = set(_consumers(g, [k for k, *_ in down]))
        cons |= {k for k, *_ in down if (g.get(k) or {}).get("layer") == "consumer"}
        all_jobs |= it["jobs"] | it["state_machines"]
        all_tables |= it["writes"]
        all_cons |= cons
        if ql and ql not in ck.lower():
            continue
        gaps = g.gaps_for(ck)
        rows.append({"config_key": ck, "jobs": [g.ref(j) for j in sorted(it["jobs"])],
                     "state_machines": [g.ref(s) for s in sorted(it["state_machines"])],
                     "reads": [g.ref(t) for t in sorted(it["reads"])], "writes": [g.ref(t) for t in sorted(it["writes"])],
                     "consumers": [g.ref(c) for c in sorted(cons)], "gaps": gaps,
                     "bound": bool(it["jobs"] or it["state_machines"])})
    return {"config_table": config_table, "items": rows,
            "totals": {"items": len(items), "jobs_and_state_machines": len(all_jobs), "tables_written": len(all_tables),
                       "consumers_downstream": len(all_cons)},
            "notes": [] if g.flags.get("consumers_harvested") else ["Consumers are not harvested yet (R9)."],
            "snapshot": g.snapshot_id}


# ---------------------------------------------------------------- terms
def terms(g, q, limit=30):
    st = stems(q)
    out = {"query": q, "terms_harvested": g.flags.get("terms_harvested"), "terms": [], "names": []}
    if not st:
        return out
    found = []
    for k, n in g.nodes.items():
        if n["type"] != "glossary_term":
            continue
        name_w = words_of(n["name"])
        hay = " ".join(name_w + words_of(n["attrs"].get("definition", "")))
        if all(any(w.startswith(s) for w in hay.split()) for s in st):
            in_name = sum(1 for s in st if any(w.startswith(s) for w in name_w))
            certified = n["attrs"].get("tier") == "certified" or n["attrs"].get("origin") in ("declared", "connector")
            found.append((in_name * 2 + (1 if certified else 0), k, n, certified))
    found.sort(key=lambda x: (-x[0], x[2]["name"]))
    listed = set()
    for _, k, n, certified in found:
        cols = [g.ref(e.src) for e in g.edges_in(k, "means")]
        listed |= {c["key"] for c in cols}
        out["terms"].append({"key": k, "term": n["name"], "definition": n["attrs"].get("definition"),
                             "origin": n["attrs"].get("origin"), "tier": n["attrs"].get("tier"),
                             "certainty": cert.certainty(n["attrs"].get("origin"), n["attrs"].get("tier")),
                             "approved": certified, "columns": cols})
    names = []
    for k, n in g.nodes.items():
        if n["type"] not in ("table", "extract"):
            continue
        w = words_of(n["name"])
        hit = sum(1 for s in st if any(x.startswith(s) for x in w))
        if hit:
            names.append((hit, {**g.ref(k), "what": "table"}))
    for k, c in g.columns.items():
        if k in listed:
            continue
        w = words_of(c["name"])
        hit = sum(1 for s in st if any(x.startswith(s) for x in w))
        if hit:
            names.append((hit, {**g.ref(k), "what": "column"}))
    names.sort(key=lambda x: (-x[0], x[1]["name"]))
    out["names_total"] = len(names)
    out["names"] = [r for _, r in names[:limit]]
    if not g.flags.get("terms_harvested"):
        out["note"] = "Business terms are not in this snapshot yet (R10), so only name matches are shown."
    return out


# ---------------------------------------------------------------- coverage and gaps in plain words
GAP_LABELS = {
    "ambiguous_job": "State machines whose job couldn't be pinned down",
    "generic_extract_target_unresolved": "Extract jobs whose output table couldn't be found",
    "unresolved_ref": "Config references that point to nothing found",
    "source_endpoint_unresolved": "DMS tasks whose source database couldn't be identified",
    "orphan_node": "Components not connected to anything",
    "data_mapping_no_raw": "Data mappings with no Raw input found",
    "source_equivalent_not_found": "Distill tables with no matching source table",
    "sql_table_unresolved": "SQL that refers to a table not found",
    "raw2dis_io_unresolved": "Raw to Distill jobs with unknown inputs or outputs",
    "no_known_trigger": "State machines with no known trigger",
    "sql_parse_failed": "SQL files that couldn't be read",
    "code_object_missing": "Code files referenced but not found",
}
DESCRIPTION_KEYS = ("description", "business_description", "comment", "table_comment")


def gap_label(reason):
    return GAP_LABELS.get(reason) or (reason or "other").replace("_", " ").capitalize()


def coverage(g):
    """How complete the map is: shares computed from the graph, each linked to the items still missing."""
    cache = g.__dict__.setdefault("_coverage", None)
    if cache is not None:
        return cache
    tables = [n for n in g.nodes.values() if n["type"] == "table"]
    described = 0
    for n in tables:
        a = n["attrs"]
        if any(a.get(k) for k in DESCRIPTION_KEYS) or any(g.edges_out(c, "means") for c in g.table_columns.get(n["key"], ())):
            described += 1
    out = [{"id": "described", "label": "Tables with a description or business term", "num": described, "den": len(tables),
            "link": None}]
    for layer, label in (("raw", "Raw tables with lineage"), ("distill", "Distill tables with lineage"),
                         ("published", "Published tables with lineage")):
        ts = [n for n in tables if n["layer"] == layer]
        if not ts:
            continue
        with_l = sum(1 for n in ts if g.table_lineage_in(n["key"]) or g.table_lineage_out(n["key"]))
        out.append({"id": "lineage_" + layer, "label": label, "num": with_l, "den": len(ts),
                    "link": {"screen": "inventory", "params": {"kind": "tables", "f.layer": layer, "quick": "no_lineage"}}})
    jobs = [k for k, n in g.nodes.items() if n["type"] == "glue_job"]
    resolved = sum(1 for k in jobs if g.job_inputs(k) and g.job_outputs(k))
    out.append({"id": "jobs_io", "label": "Glue jobs with known inputs and outputs", "num": resolved, "den": len(jobs),
                "link": {"screen": "inventory", "params": {"kind": "glue_jobs", "quick": "no_lineage"}}})
    sms = [n for n in g.nodes.values() if n["type"] == "pipeline"]
    if g.flags.get("triggers_harvested"):
        trig = sum(1 for n in sms if n["attrs"].get("triggers"))
        out.append({"id": "triggers", "label": "State machines with a known trigger", "num": trig, "den": len(sms), "link": None})
    else:
        out.append({"id": "triggers", "label": "State machines with a known trigger", "num": None, "den": len(sms),
                    "note": "not harvested yet", "link": None})
    for x in out:
        x["pct"] = round(100 * x["num"] / x["den"]) if x.get("num") is not None and x["den"] else None
    g.__dict__["_coverage"] = out
    return out


def gaps_summary(g):
    by = Counter((x.get("rule"), x.get("reason")) for x in g.gaps)
    return [{"rule": r, "reason": s, "label": gap_label(s), "n": n} for (r, s), n in sorted(by.items(), key=lambda i: -i[1])]


def gaps_list(g, reason, rule=None, q="", offset=0, limit=100):
    ql = (q or "").lower()
    items = [x for x in g.gaps if x.get("reason") == reason and (not rule or x.get("rule") == rule)
             and (not ql or ql in (x.get("object", "") + " " + x.get("location", "") + " " + x.get("detail", "")).lower())]
    rows = []
    for x in items[offset: offset + limit]:
        obj = x.get("object", "")
        rows.append({**{k: x.get(k, "") for k in ("rule", "reason", "object", "location", "detail")},
                     "node": g.ref(obj) if g.get(obj) else None})
    return {"reason": reason, "label": gap_label(reason), "total": len(items), "offset": offset, "rows": rows,
            "snapshot": g.snapshot_id}


# ---------------------------------------------------------------- health
def health(g, ops):
    by = Counter((x.get("rule"), x.get("reason")) for x in g.gaps)
    return {"snapshot": g.snapshot_id, "built_at": g.built_at, "flags": g.flags,
            "gaps": gaps_summary(g), "coverage": coverage(g), "certainty_legend": cert.legend(),
            "ops_problems": ops.validate(g),
            "tables_without_layer": sum(1 for n in g.nodes.values() if n["type"] == "table" and n["layer"] == "none")}


def consumer_count(g):
    def count(key):
        n = g.nodes.get(key, {})
        if n.get("type") in ORCH_TYPES:
            seeds = {}
            for j in g.jobs_of(key):
                for o, e in g.job_outputs(j):
                    seeds.setdefault(o, (j, e))
        elif n.get("type") in JOB_TYPES:
            seeds = {o: (key, e) for o, e in g.job_outputs(key)}
        else:
            return 0
        down, _ = _downstream(g, seeds)
        return len(_consumers(g, [k for k, *_ in down])) + sum(1 for k, *_ in down if (g.get(k) or {}).get("type") in CONSUMER_TYPES)
    return count
