"""Browser smoke test: every screen loads with no JavaScript errors.

Skipped unless Python Playwright and its Chromium are installed
(pip install playwright; python -m playwright install chromium).
"""

import socket
import threading
import time
import urllib.parse as u

import pytest

pw = pytest.importorskip("playwright.sync_api")
uvicorn = pytest.importorskip("uvicorn")

from kf_ui.api.app import create_app  # noqa: E402
from kf_ui.query import Fabric  # noqa: E402
from kf_ui.sample.build_sample import build  # noqa: E402

R2D = "aws.glue_job.auk-prd-cdp-raw2dis-arc1-hudi-load-batch"
DIS = "glue.auk_prd_cdp_dis_db.arc1_composer_dbo_address"
SCREENS = ["#/", "#/inventory?kind=tables", "#/inventory?kind=glue_jobs", "#/detail?key=" + u.quote(R2D),
           "#/detail?key=" + u.quote(DIS), "#/lineage?key=" + u.quote(DIS), "#/lineage?key=" + u.quote(DIS + ".postcode") + "&depth=2&jobs=1", "#/flow?key=" + u.quote(DIS),
           "#/flow?view=table&key=" + u.quote(DIS), "#/flow?jobs_only=1&key=" + u.quote(DIS),
           "#/impact?mode=failure&key=" + u.quote(R2D), "#/impact?mode=stale&key=" + u.quote(DIS),
           "#/impact?mode=column&key=" + u.quote(DIS + ".postcode"), "#/discover?tab=config",
           "#/discover?tab=terms&q=contribution", "#/health", "#/search?q=address"]


@pytest.fixture(scope="module")
def base(tmp_path_factory):
    root = build(tmp_path_factory.mktemp("ui"), "full")
    app = create_app(Fabric(root, root / "config" / "ops.yaml"))
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error"))
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    for _ in range(50):
        if server.started:
            break
        time.sleep(0.1)
    yield f"http://127.0.0.1:{port}/"
    server.should_exit = True


def test_screens_have_no_errors(base):
    with pw.sync_playwright() as p:
        try:
            browser = p.chromium.launch()
        except Exception as exc:  # browser not downloaded
            pytest.skip(f"Chromium not available: {exc}")
        page = browser.new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
        for h in SCREENS:
            page.goto(base + h)
            page.wait_for_load_state("networkidle")
            assert page.inner_text("main").strip(), f"empty screen {h}"
        browser.close()
    assert errors == []


MEMBER = "glue.auk_prd_cdp_dis_db.arc1_composer_dbo_member_account"


@pytest.fixture(scope="module")
def fan_base(tmp_path_factory):
    root = build(tmp_path_factory.mktemp("fan"), "fanout")
    app = create_app(Fabric(root, root / "config" / "ops.yaml"))
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error"))
    threading.Thread(target=server.run, daemon=True).start()
    for _ in range(50):
        if server.started:
            break
        time.sleep(0.1)
    yield f"http://127.0.0.1:{port}/"
    server.should_exit = True


def test_flow_groups_fan_out_and_opens_focused(fan_base):
    """18 readers become 3 group nodes; further steps stay hidden until asked for; a click lights a path."""
    with pw.sync_playwright() as p:
        try:
            browser = p.chromium.launch()
        except Exception as exc:  # browser not downloaded
            pytest.skip(f"Chromium not available: {exc}")
        page = browser.new_page(viewport={"width": 1440, "height": 1000})
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.goto(fan_base + "#/flow?key=" + u.quote(MEMBER))
        page.wait_for_selector(".fnode.focal")
        assert page.locator(".fnode.group").count() == 3
        assert page.locator(".fl-h b", has_text="Downstream").count() == 0
        assert page.locator(".flow-label").count() == 0  # no hand-off pills over the lines
        page.locator(".fn-more").first.click()
        page.wait_for_selector(".fl-h b:has-text('Downstream')")
        page.locator(".fnode.focal .fn-name").click()
        assert page.locator(".fnode.dim").count() == 0 or page.locator(".fnode.lit").count() > 0
        page.locator("button.btn", has_text="Show all").click()
        page.locator(".seg button", has_text="Table").click()
        page.wait_for_selector("table.data tbody tr")
        assert page.locator("table.data tbody tr").count() == 29
        browser.close()
    assert errors == []
