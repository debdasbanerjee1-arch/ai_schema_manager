import { html, useEffect, useLayoutEffect, useMemo, useRef, useState } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { patch } from "../lib/router.js";
import { rememberTask } from "../lib/recent.js";
import { Cert, Empty, ErrorBox, Handoff, Layer, Loading, NodeLink, OpsTags, Picker, TYPE_LABEL, detailHref } from "../lib/ui.js";
import { ROLE, buildModel, lineType, pathOf, short } from "../lib/flow-model.js";

const KIND = { dms: "DMS replication", state_machine: "State machine", job: "Job, no state machine found",
  no_job: "View or derivation", unknown_state_machine: "State machine not known" };
// How a step is started, drawn as the line style into it. Colour is never the only cue.
const LINE = {
  enforced: { label: "Previous step", long: "Started by the previous step" },
  event: { label: "Event", long: "Started by an event" },
  schedule_only: { label: "Schedule only", long: "Runs on its own schedule" },
  unknown: { label: "Not known", long: "Start not known" },
};
const SIDE = { up: "Upstream", builds: "Builds this table", reads: "Reads this table", down: "Downstream" };
const TABLE_VIEW_AT = 15; // open in the table view when the focused diagram would hold more step nodes than this

const LineSample = ({ t }) => html`<svg class="ls" width="34" height="8" aria-hidden="true"><line x1="1" y1="4" x2="33" y2="4" class=${"fl-" + t} /></svg>`;

function startedBy(s, harvested) {
  if (s.kind === "no_job") return { t: null, text: "A view: built when it is read" };
  if (!s.after.length) return { t: null, text: s.schedule ? "Schedule: " + s.schedule : "Where the data enters" };
  const types = [...new Set(s.after.map((a) => lineType(a.handoff)))];
  const t = types.length === 1 ? types[0] : "unknown";
  if (t !== "unknown") return { t, text: LINE[t].long };
  const h = s.after.find((a) => a.handoff)?.handoff;
  return { t, text: !harvested ? "Trigger not harvested yet" : h && h.type === "no_trigger_found" ? "No trigger found" : "Start not known" };
}

const outsLine = (s) => {
  const o = s.writes;
  if (!o.length) return null;
  return html`<div class="fn-line" title=${o.map((t) => t.name).join("\n")}>Writes <span class="mono">${o[0].name}</span>${o.length > 1 ? html` <span class="muted">+${o.length - 1} more</span>` : null}</div>`;
};

const NextButton = ({ n, onNext }) => (n.hiddenNext || n.nextShown) ? html`<button class="fn-more"
  aria-label=${n.nextShown && !n.hiddenNext ? "Hide the next steps" : `Show ${n.hiddenNext} next steps`}
  onClick=${(e) => { e.stopPropagation(); onNext(n); }}>${n.nextShown && !n.hiddenNext ? "− hide next" : `+${n.hiddenNext} next`}</button>` : null;

function StepCard({ n, prefix, data, cls, onSelect, onNext }) {
  const s = n.seg;
  const st = startedBy(s, data.triggers_harvested);
  return html`<div class=${"fnode step " + cls} data-v=${n.id} onClick=${() => onSelect(n.id)}>
    <div class="fn-top"><span>${KIND[s.kind] || s.kind}</span>${s.side === "builds" ? html`<span class="badge accent">builds this table</span>` : null}</div>
    <button class="fn-name" title=${s.name} onClick=${(e) => { e.stopPropagation(); onSelect(n.id); }}><span class="clamp">${short(s.name, prefix)}</span></button>
    ${s.kind === "state_machine" && s.jobs.length ? html`<div class="fn-line" title=${s.jobs.map((j) => j.name).join("\n")}>Runs <span class="mono">${short(s.jobs[0].name, prefix)}</span></div>`
      : s.kind === "unknown_state_machine" ? html`<div class="fn-line warn">One of ${s.candidates.length} state machines</div>` : null}
    ${outsLine(s)}
    <div class="fn-foot">${st.t ? html`<${LineSample} t=${st.t} />` : null}<span class="fn-trig">${st.text}</span>
      <${NextButton} n=${n} onNext=${onNext} /></div>
  </div>`;
}

function GroupCard({ n, prefix, data, cls, open, onToggle, onSelect, onNext, selId }) {
  const ms = n.members;
  const allSm = ms.every((m) => m.kind === "state_machine");
  const starts = ms.map((m) => startedBy(m, data.triggers_harvested));
  const st = new Set(starts.map((x) => x.t + x.text)).size === 1 ? starts[0] : { t: "unknown", text: "Mixed or not known" };
  const label = `${ms.length} ${allSm ? "state machines" : "steps"}`;
  const SHOW = 12;
  return html`<div class=${"fnode group " + cls + (open ? " open" : "")} data-v=${n.id} onClick=${() => onSelect(n.id)}>
    <div class="fn-top"><span>${n.other ? "Other steps" : "Group"}</span>
      <button class="fn-toggle" aria-expanded=${open} aria-label=${open ? "Hide the list" : `List the ${label}`} onClick=${(e) => { e.stopPropagation(); onToggle(n.id); }}>${open ? "Hide list ▴" : "List ▾"}</button></div>
    <button class="fn-name" onClick=${(e) => { e.stopPropagation(); onSelect(n.id); }}><span class="clamp">${label}</span></button>
    ${n.job ? html`<div class="fn-line" title=${n.job.name}>All run <span class="mono">${short(n.job.name, prefix)}</span></div>`
      : html`<div class="fn-line">Different jobs</div>`}
    <div class="fn-foot">${st.t ? html`<${LineSample} t=${st.t} />` : null}<span class="fn-trig">${st.text}</span><${NextButton} n=${n} onNext=${onNext} /></div>
    ${open ? html`<ul class="fn-members">${ms.slice(0, SHOW).map((m) => html`<li>
        <button class=${selId === "s:" + m.n ? "sel" : ""} title=${m.name} onClick=${(e) => { e.stopPropagation(); onSelect("s:" + m.n); }}>
          <span class="mono">${short(m.name, prefix)}</span>
          <span class="muted">${m.writes[0] ? "→ " + m.writes[0].name + (m.writes.length > 1 ? ` +${m.writes.length - 1}` : "") : ""}</span></button></li>`)}
      ${ms.length > SHOW ? html`<li class="muted small">+${ms.length - SHOW} more: see the table view</li>` : null}</ul>` : null}
  </div>`;
}

function TableCard({ n, cls, onSelect }) {
  if (n.type === "tables") {
    return html`<div class=${"fnode tbl " + cls} data-v=${n.id} onClick=${() => onSelect(n.id)}>
      <div class="fn-top"><span>Tables</span><span class="badge">${n.tables.length}</span></div>
      <button class="fn-name" title=${n.tables.map((t) => t.name).join("\n")} onClick=${(e) => { e.stopPropagation(); onSelect(n.id); }}><span class="clamp">${n.tables.length} tables</span></button>
    </div>`;
  }
  return html`<div class=${"fnode tbl " + cls + (n.focal ? " focal" : "")} data-v=${n.id} onClick=${() => onSelect(n.id)}>
    <div class="fn-top"><${Layer} layer=${n.ref.layer} />${n.focal ? html`<span class="badge accent">this table</span>` : null}</div>
    <button class="fn-name" title=${n.ref.name} onClick=${(e) => { e.stopPropagation(); onSelect(n.id); }}><span class="clamp">${n.ref.name}</span></button>
  </div>`;
}

function Lines({ boxRef, model, lit, tick }) {
  const [paths, setPaths] = useState([]);
  useLayoutEffect(() => {
    const box = boxRef.current;
    if (!box) return;
    const B = box.getBoundingClientRect();
    const at = {};
    box.querySelectorAll("[data-v]").forEach((el) => {
      const r = el.getBoundingClientRect();
      at[el.dataset.v] = { l: r.left - B.left, r: r.right - B.left, y: r.top - B.top + Math.min(r.height / 2, 46) };
    });
    const out = [];
    for (const e of model.edges) {
      const a = at[e.from], b = at[e.to];
      if (!a || !b) continue;
      const dx = Math.max(20, (b.l - a.r) / 2);
      const t = e.kind === "handoff" ? (e.types.size === 1 ? [...e.types][0] : "unknown") : "write";
      const dim = !!lit && !lit.edges.has(e.id);
      out.push({ id: e.id, t, dim, on: !!lit && !dim, title: e.titles.join("\n"),
        d: `M${a.r},${a.y} C${a.r + dx},${a.y} ${b.l - dx},${b.y} ${b.l - 5},${b.y}`,
        head: `M${b.l - 7},${b.y - 4} L${b.l},${b.y} L${b.l - 7},${b.y + 4} Z` });
    }
    setPaths(out);
  }, [model, lit, tick]);
  return html`<svg class="fl-edges" aria-hidden="true">${paths.map((p) => html`<g key=${p.id} class=${"fl-" + p.t + (p.dim ? " dim" : "") + (p.on ? " on" : "")}>
    <path d=${p.d}>${p.title ? html`<title>${p.title}</title>` : null}</path><path class="head" d=${p.head} /></g>`)}</svg>`;
}

function Summary({ s, harvested }) {
  const items = [
    s.sources ? [s.sources, s.sources === 1 ? "source table" : "source tables"] : null,
    s.upstream ? [s.upstream, s.upstream === 1 ? "step further upstream" : "steps further upstream"] : null,
    [s.builders, s.builders === 1 ? "step builds it" : "steps build it"],
    [s.readers, (s.readers_are_state_machines ? "state machine" : "step") + (s.readers === 1 ? " reads it" : "s read it")],
    s.downstream ? [s.downstream, "further downstream"] : null,
    s.consumers ? [s.consumers, s.consumers === 1 ? "consumer" : "consumers"] : null,
    !s.handoffs ? null : s.unknown_handoffs ? [s.unknown_handoffs, `of ${s.handoffs} hand-offs have an unknown trigger`, "warn"]
      : [s.handoffs, s.handoffs === 1 ? "hand-off, trigger known" : "hand-offs, all triggers known"],
  ].filter(Boolean);
  return html`<div class="card fl-summary" aria-label="Summary">${items.map(([n, l, c]) => html`<div><b class=${c || ""}>${n}</b><span>${l}</span></div>`)}
    ${!harvested ? html`<p class="small muted fl-note">Triggers aren't harvested yet, so every hand-off line is grey: the graph can't yet say what starts each step.</p>` : null}</div>`;
}

function Legend({ prefix, tables }) {
  return html`<div class="row small muted fl-legend noprint">
    <b class="ink">Started by</b>
    ${Object.entries(LINE).map(([t, l]) => html`<span class="row" style="gap:6px"><${LineSample} t=${t} />${l.label}</span>`)}
    ${tables ? html`<span class="row" style="gap:6px"><${LineSample} t="write" />writes or reads a table</span>` : null}
    ${prefix ? html`<span class="fl-prefix">Names shown without <span class="mono">${prefix}</span>; hover for the full name</span>` : null}
  </div>`;
}

// ---------------------------------------------------------------- details of the selected node
function StepDetails({ s, data, model, onSelect }) {
  return html`<section class="card stack" aria-label="Selected step">
    <div class="row" style="justify-content:space-between"><h2>${KIND[s.kind] || s.kind}: <span class="mono">${s.name}</span></h2><${OpsTags} tags=${s.ops_tags} /></div>
    <div class="small muted">${ROLE[s.role][0]} · ${SIDE[s.side]}${s.schedule ? " · schedule " + s.schedule : ""}</div>
    ${s.orchestrator ? html`<div><${NodeLink} node=${s.orchestrator} /></div>` : null}
    ${s.candidates && s.candidates.length ? html`<div class="stack" style="gap:4px">
      <span class="badge red wrap">The branch's config doesn't name its state machine; it is one of these:</span>
      ${s.candidates.map((c) => html`<div><${NodeLink} node=${c} showType=${false} /></div>`)}</div>` : null}
    ${s.jobs.length ? html`<div class="small">Runs ${s.jobs.map((j, i) => html`${i ? ", " : ""}<${NodeLink} node=${j} showType=${false} />`)}</div>` : null}
    <div class="stack" style="gap:4px"><h3>What it does</h3>${s.steps.map((st) => html`<div class="small">
      <span class="mono">${st.from.name}</span> → <a class="mono" href=${detailHref(st.to.key)}>${st.to.name}</a>
      ${st.config_key && !st.config_key.endsWith(st.to.name) ? html` <span class="muted">(branch ${st.config_key})</span>` : null}
      ${st.to.key === data.table.key ? html` <span class="badge accent">this table</span>` : null}
      ${st.certainty ? html` <${Cert} c=${st.certainty} />` : null}</div>`)}</div>
    <div class="stack" style="gap:4px"><h3>Waits for</h3>
      ${s.after.length ? s.after.map((a) => html`<div class="row small">
        <button class="linkish mono" onClick=${() => onSelect("s:" + a.step)}>${model.by[a.step].name}</button>
        ${a.handoff ? html`<${Handoff} h=${a.handoff} /><span class="muted">${a.handoff.why}</span>`
          : s.kind === "unknown_state_machine" ? html`<span class="badge">Hand-off unknown</span>` : null}
        <span class="muted">· reads <span class="mono">${a.table.name}</span></span></div>`)
        : html`<span class="small muted">Nothing upstream in the graph: this is where the data enters.</span>`}
    </div>
  </section>`;
}

function GroupDetails({ n, data, prefix, onSelect }) {
  return html`<section class="card stack" aria-label="Selected group">
    <h2>${n.members.length} steps${n.job ? html` that run <span class="mono">${n.job.name}</span>` : null}</h2>
    <div class="tablewrap" style="max-height:340px"><table class="data"><thead><tr><th>Step</th><th>Writes</th><th>Started by</th></tr></thead>
      <tbody>${n.members.map((m) => html`<tr onClick=${() => onSelect("s:" + m.n)} style="cursor:pointer">
        <td class="mono" title=${m.name}>${short(m.name, prefix)}</td>
        <td class="mono long">${m.writes.map((t) => t.name).join(", ")}</td>
        <td>${startedBy(m, data.triggers_harvested).text}</td></tr>`)}</tbody></table></div>
  </section>`;
}

function TableDetails({ n, data, onSelect }) {
  const refs = n.type === "tables" ? n.tables : [n.ref];
  const has = (k) => refs.some((r) => r.key === k);
  const writers = data.segments.filter((s) => s.writes.some((t) => has(t.key)));
  const readers = data.segments.filter((s) => s.after.some((a) => has(a.table.key)) || s.reads.some((t) => has(t.key)));
  const users = (data.consumers || []).filter((c) => (c.tables || []).some(has));
  const list = (ss, cs = []) => ss.length || cs.length ? html`${ss.map((s) => html`<div><button class="linkish mono" onClick=${() => onSelect("s:" + s.n)}>${s.name}</button></div>`)}
    ${cs.map((c) => html`<div><${NodeLink} node=${c} /></div>`)}` : html`<span class="small muted">None in this flow.</span>`;
  return html`<section class="card stack" aria-label="Selected table">
    <h2>${refs.length > 1 ? `${refs.length} tables` : html`<span class="mono">${refs[0].name}</span>`}</h2>
    <div class="row small">${refs.slice(0, 20).map((r) => html`<a class=${refs.length > 1 ? "mono" : ""} href=${detailHref(r.key)}>${refs.length > 1 ? r.name : "Open the table"}</a>`)}
      ${refs.length === 1 ? html`<a href=${"#/lineage?key=" + encodeURIComponent(refs[0].key)}>Open its lineage</a>` : null}</div>
    <div class="grid2"><div class="stack" style="gap:4px"><h3>Written by</h3>${list(writers)}</div>
      <div class="stack" style="gap:4px"><h3>Read by</h3>${list(readers, users)}</div></div>
  </section>`;
}

function Details({ sel, model, data, prefix, onSelect }) {
  if (!sel) return html`<p class="small muted noprint" style="margin:0">Click a step or table to light up its path and see its details.</p>`;
  if (sel.startsWith("s:")) { const s = model.by[sel.slice(2)]; return s ? html`<${StepDetails} s=${s} data=${data} model=${model} onSelect=${onSelect} />` : null; }
  const n = model.nodes[sel];
  if (!n) return null;
  if (n.type === "group") return html`<${GroupDetails} n=${n} data=${data} prefix=${prefix} onSelect=${onSelect} />`;
  if (n.type === "table" || n.type === "tables") return html`<${TableDetails} n=${n} data=${data} onSelect=${onSelect} />`;
  return null;
}

// ---------------------------------------------------------------- table view
const COLS = [
  ["stage", "Stage", (s) => s.n], ["name", "Step", (s) => s.name], ["kind", "Kind", (s) => KIND[s.kind] || s.kind],
  ["job", "Runs", (s) => (s.jobs[0] ? s.jobs[0].name : "")], ["reads", "Reads", (s) => s.reads.map((t) => t.name).join(", ")],
  ["writes", "Writes", (s) => s.writes.map((t) => t.name).join(", ")], ["start", "Started by", null], ["schedule", "Schedule", (s) => s.schedule || ""],
];
const clip = (refs) => html`<div class="fl-names" title=${refs.map((t) => t.name).join("\n")}>${refs.slice(0, 2).map((t) => html`<div>${t.name}</div>`)}${refs.length > 2 ? html`<div class="muted">+${refs.length - 2} more</div>` : null}</div>`;

function FlowTable({ data, prefix, sel, onSelect }) {
  const [sort, setSort] = useState({ id: "stage", desc: false });
  const [q, setQ] = useState("");
  const start = (s) => { const t = startedBy(s, data.triggers_harvested).text; return t === "Trigger not harvested yet" ? "Not harvested" : t; };
  const val = (s, id) => (id === "start" ? start(s) : COLS.find((c) => c[0] === id)[2](s));
  const ql = q.trim().toLowerCase();
  const rows = data.segments.filter((s) => !ql || COLS.some(([id]) => String(val(s, id)).toLowerCase().includes(ql)));
  rows.sort((a, b) => { const x = val(a, sort.id), y = val(b, sort.id); const r = typeof x === "number" ? x - y : String(x).localeCompare(String(y)); return sort.desc ? -r : r; });
  const th = ([id, label]) => html`<th aria-sort=${sort.id === id ? (sort.desc ? "descending" : "ascending") : "none"}>
    <button onClick=${() => setSort({ id, desc: sort.id === id ? !sort.desc : false })}>${label}${sort.id === id ? (sort.desc ? " ▾" : " ▴") : ""}</button></th>`;
  return html`<div class="stack" style="gap:8px">
    <input class="input" type="search" placeholder="Filter steps, jobs or tables" aria-label="Filter steps" value=${q} onInput=${(e) => setQ(e.target.value)} style="max-width:420px" />
    <div class="tablewrap"><table class="data"><thead><tr>${COLS.map(th)}</tr></thead><tbody>
      ${rows.map((s) => html`<tr class=${sel === "s:" + s.n ? "sel" : ""} onClick=${() => onSelect("s:" + s.n)} style="cursor:pointer">
        <td>${ROLE[s.role][0]}<div class="small muted">${SIDE[s.side]}</div></td>
        <td class="mono" title=${s.name}>${short(s.name, prefix)}</td>
        <td>${KIND[s.kind] || s.kind}</td>
        <td class="mono" title=${s.jobs.map((j) => j.name).join("\n")}>${s.jobs[0] && s.kind !== "dms" ? short(s.jobs[0].name, prefix) : ""}</td>
        <td class="mono">${clip(s.reads)}</td><td class="mono">${clip(s.writes)}</td>
        <td>${start(s)}</td><td class="mono">${s.schedule || ""}</td></tr>`)}
    </tbody></table></div>
    <p class="small muted" style="margin:0">${rows.length} of ${data.segments.length} steps, in run order unless sorted. Click a heading to sort.</p>
  </div>`;
}

// ---------------------------------------------------------------- screen
// The view is chosen from the default (focused) diagram, so opening more steps never switches it.
const curView = (view, defaultSize) => (view === "table" || view === "diagram" ? view : defaultSize > TABLE_VIEW_AT ? "table" : "diagram");

export function Flow({ params }) {
  const key = params.get("key");
  const view = params.get("view");
  const tables = params.get("jobs_only") !== "1";
  const { data, error } = useApi("/api/flow", { key }, key);
  useEffect(() => { if (data) rememberTask("End-to-end flow", data.table.name); }, [data]);
  const [sel, setSel] = useState(null);
  const [open, setOpen] = useState(new Set());
  const [expanded, setExpanded] = useState(new Set());
  const [all, setAll] = useState(false);
  const [tick, setTick] = useState(0);
  const boxRef = useRef();
  useEffect(() => { setSel(null); setOpen(new Set()); setExpanded(new Set()); setAll(false); }, [data]);
  useEffect(() => {
    const on = () => setTick((t) => t + 1);
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, []);
  const model = useMemo(() => (data && data.segments.length ? buildModel(data, { tables, all, expanded }) : null), [data, tables, all, expanded]);
  const defaultSize = useMemo(() => (data && data.segments.length ? buildModel(data, { tables: true, all: false, expanded: new Set() }).size : 0), [data]);
  useEffect(() => setTick((t) => t + 1), [open, view]);
  const scrolled = useRef(null);
  useLayoutEffect(() => {
    const box = boxRef.current;
    if (!box || !data || scrolled.current === data.table.key) return;
    const wrap = box.parentElement, f = box.querySelector(".fnode.focal") || box.querySelector(".badge.accent");
    if (!f) return;
    scrolled.current = data.table.key;
    const x = f.getBoundingClientRect().left - box.getBoundingClientRect().left;
    if (x > wrap.clientWidth * 0.55) wrap.scrollLeft = x - wrap.clientWidth * 0.4;
  });

  const v = model ? curView(view, defaultSize) : null;
  const head = html`<div class="row fl-head">
    <div class="stack" style="gap:6px;flex:1 1 420px;min-width:0"><h1>End-to-end flow</h1>
      <${Picker} label="Which table?" types=${["table", "extract"]} value=${data ? data.table.name : ""} onPick=${(r) => patch({ key: r.key })} /></div>
    ${model ? html`<div class="seg noprint" role="group" aria-label="View">
      <button class=${v === "diagram" ? "on" : ""} aria-pressed=${v === "diagram"} onClick=${() => patch({ view: "diagram" })}>Diagram</button>
      <button class=${v === "table" ? "on" : ""} aria-pressed=${v === "table"} onClick=${() => patch({ view: "table" })}>Table</button></div>` : null}
  </div>`;
  if (!key) return html`${head}<${Empty}>Pick a table to see every step its data passes through, from where it enters to what reads it.</${Empty}>`;
  if (error) return html`${head}<${ErrorBox} error=${error} />`;
  if (!data) return html`${head}<${Loading} />`;
  if (!model) return html`${head}<${Empty}>No lineage into or out of ${data.table.name} in the graph.</${Empty}>`;

  const prefix = data.name_prefix;
  const select = (id) => setSel((cur) => (cur === id ? null : id));
  const toggleOpen = (id) => setOpen((s) => { const x = new Set(s); x.has(id) ? x.delete(id) : x.add(id); return x; });
  const onNext = (n) => setExpanded((s) => {
    const x = new Set(s);
    if (n.nextShown && !n.hiddenNext) n.members.forEach((m) => x.delete(m.n)); else n.members.forEach((m) => x.add(m.n));
    return x;
  });
  const litId = sel && (model.nodes[sel] ? sel : sel.startsWith("s:") ? model.vid[sel.slice(2)] : null);
  const lit = pathOf(model, litId, sel && sel.startsWith("s:") && litId !== sel ? sel.slice(2) : null);
  const cls = (id) => (lit ? (lit.nodes.has(id) ? "lit" : "dim") : "") + (id === litId ? " sel" : "");
  const widths = model.columns.map((c) => (c.kind === "step" ? "minmax(196px, 236px)" : c.kind === "consumer" ? "minmax(150px, 190px)" : "minmax(140px, 176px)")).join(" ");

  return html`
    ${head}
    <${Summary} s=${data.summary} harvested=${data.triggers_harvested} />
    ${v === "diagram" ? html`
      <div class="row noprint fl-controls">
        <label class="row" style="gap:6px"><input type="checkbox" checked=${tables} onChange=${(e) => patch({ jobs_only: !e.target.checked })} /> Show tables between steps</label>
        ${model.hiddenSteps || all ? html`<button class="btn small" onClick=${() => { setAll(!all); setExpanded(new Set()); }}>${all ? "Focus: one hop downstream" : `Show all ${data.summary.downstream} further downstream`}</button>` : null}
        ${model.hiddenSteps && !all ? html`<span class="small muted">${model.hiddenSteps} steps further downstream are hidden. Use “+ next” on a card to open one branch.</span>` : null}
      </div>
      <${Legend} prefix=${prefix} tables=${tables} />
      <div class="fl-scroll">
        <div class="fl-canvas" ref=${boxRef} style=${`grid-template-columns:${widths}`}>
          <${Lines} boxRef=${boxRef} model=${model} lit=${lit} tick=${tick} />
          ${model.columns.map((c) => html`<div class=${"fl-lane " + c.kind}>
            <div class="fl-h"><b>${c.title}</b><span>${c.sub}</span></div>
            ${c.ids.map((id) => {
              const n = model.nodes[id];
              if (n.type === "step") return html`<${StepCard} key=${id} n=${n} prefix=${prefix} data=${data} cls=${cls(id)} onSelect=${select} onNext=${onNext} />`;
              if (n.type === "group") return html`<${GroupCard} key=${id} n=${n} prefix=${prefix} data=${data} cls=${cls(id)} open=${open.has(id)} onToggle=${toggleOpen} onSelect=${select} onNext=${onNext} selId=${sel} />`;
              if (n.type === "consumer") return html`<a key=${id} class=${"fnode cons " + cls(id)} data-v=${id} href=${detailHref(n.ref.key)}>
                <div class="fn-top"><span>${TYPE_LABEL[n.ref.type] || n.ref.type}</span></div><span class="fn-name"><span class="clamp">${n.ref.name}</span></span></a>`;
              return html`<${TableCard} key=${id} n=${n} cls=${cls(id)} onSelect=${select} />`;
            })}
          </div>`)}
        </div>
      </div>
      ${model.hiddenConsumers ? html`<p class="small muted" style="margin:0">${model.hiddenConsumers} more consumers sit behind hidden steps.</p>` : null}`
    : html`<${FlowTable} data=${data} prefix=${prefix} sel=${sel} onSelect=${select} />`}
    <${Details} sel=${sel} model=${model} data=${data} prefix=${prefix} onSelect=${(id) => setSel(id)} />`;
}
