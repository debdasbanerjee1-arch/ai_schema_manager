"""Knowledge Fabric analysis UI: query library, read-only API and screens."""

__version__ = "0.1.0"
