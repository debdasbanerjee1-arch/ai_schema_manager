import { html } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { patch } from "../lib/router.js";
import { Empty, ErrorBox, Handoff, Loading, NodeLink, Notes, OpsTags, Picker } from "../lib/ui.js";

const KIND = { dms: "DMS replication", state_machine: "State machine", job: "Job (no state machine found)" };

export function Flow({ params }) {
  const key = params.get("key");
  const { data, error } = useApi("/api/flow", { key }, key);
  const picker = html`<div class="card noprint"><${Picker} label="Which table?" types=${["table", "extract"]}
    value=${data ? data.table.name : ""} onPick=${(r) => patch({ key: r.key })} /></div>`;
  const legend = html`<div class="row small muted noprint">
    <span class="badge green">Enforced</span> the next step is started by the previous one
    <span class="badge blue">Event</span> started when the data or a completion event arrives
    <span class="badge amber">Schedule only</span> runs on its own clock; nothing makes it wait
    <span class="badge">Not harvested</span> trigger not in this snapshot</div>`;
  if (!key) return html`<h1>End-to-end flow</h1>${picker}<${Empty}>Pick a table to see every orchestrator its data passes through, and how each hands over to the next.</${Empty}>`;
  if (error) return html`<h1>End-to-end flow</h1>${picker}<${ErrorBox} error=${error} />`;
  if (!data) return html`<h1>End-to-end flow</h1>${picker}<${Loading} />`;
  return html`
    <h1>End-to-end flow</h1>${picker}${legend}
    ${!data.triggers_harvested ? html`<${Notes} notes=${["Triggers are not harvested yet, so hand-offs between state machines show as Not harvested."]} />` : null}
    ${data.segments.length ? html`<div class="flow">${data.segments.map((s, i) => html`
      ${i > 0 ? html`<div class="handoff"><span class="arrow" aria-hidden="true">↓</span>
        ${s.handoff_in ? html`<${Handoff} h=${s.handoff_in} /><span class="small muted">${s.handoff_in.why}</span>` : html`<span class="small muted">data passes on</span>`}</div>` : null}
      <section class="card seg-card" aria-label=${"Step " + (i + 1)}>
        <div class="seg-head"><span class="muted small">${i + 1}. ${KIND[s.kind] || s.kind}</span>
          ${s.orchestrator ? html`<${NodeLink} node=${s.orchestrator} showType=${false} />` : null}
          <${OpsTags} tags=${s.ops_tags} /></div>
        <div class="seg-body">
          ${s.jobs.map((j) => html`<div class="small">runs <${NodeLink} node=${j} showType=${false} /></div>`)}
          ${s.steps.map((st) => html`<div class="small">
            <span class="mono">${st.from.name}</span> → <a class="mono" href=${"#/detail?key=" + encodeURIComponent(st.to.key)}>${st.to.name}</a>
            ${st.to.key === data.table.key ? html` <span class="badge accent">this table</span>` : null}</div>`)}
        </div>
      </section>`)}</div>` : html`<${Empty}>No lineage into or out of ${data.table.name} in the graph.</${Empty}>`}
    ${data.consumers.length ? html`<section class="card stack"><h2>Consumers at the end</h2>
      <div class="row">${data.consumers.map((c) => html`<span class="chip"><${NodeLink} node=${c} /></span>`)}</div></section>` : null}`;
}
