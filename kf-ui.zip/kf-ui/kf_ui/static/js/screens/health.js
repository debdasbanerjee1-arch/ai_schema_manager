import { html } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { href } from "../lib/router.js";
import { ErrorBox, Loading } from "../lib/ui.js";

const FLAGS = [
  ["triggers_harvested", "Triggers", "Hand-offs between state machines (Enforced, Event, Schedule only) need the events harvester and Glue triggers."],
  ["consumers_harvested", "Consumers", "Dashboards, APIs and extracts need R9."],
  ["terms_harvested", "Business terms", "Term search needs R10 (data dictionary and Confluence drafts)."],
  ["load_times_present", "Load times", "Stale-table checks compare last load times from DMS statistics and bookmarks."],
  ["column_lineage_beyond_distill", "Column lineage beyond Distill", "Column changes past Distill need parsed SQL."],
];

export function Health() {
  const { data, error } = useApi("/api/health", {}, "health");
  if (error) return html`<${ErrorBox} error=${error} />`;
  if (!data) return html`<${Loading} />`;
  const total = data.gaps.reduce((a, g) => a + g.n, 0);
  return html`
    <h1>Health</h1>
    <p class="muted" style="margin:0">Snapshot ${data.snapshot}, graph built ${data.built_at}.</p>
    <div class="split">
      <section class="card main stack"><h2>What this snapshot can answer</h2>
        <div class="rows">${FLAGS.map(([k, label, why]) => html`<div class="rowi">
          <span class=${"badge " + (data.flags[k] ? "green" : "amber")}>${data.flags[k] ? "Yes" : "Not yet"}</span>
          <b style="flex:0 0 220px">${label}</b><span class="why">${why}</span></div>`)}</div>
        <h2 style="margin-top:8px">Gaps · ${total.toLocaleString()}</h2>
        <div class="tablewrap"><table class="data"><thead><tr><th>Rule</th><th>Reason</th><th class="num">Count</th></tr></thead>
          <tbody>${data.gaps.map((g) => html`<tr><td>${g.rule}</td><td class="mono">${g.reason}</td><td class="num">${g.n.toLocaleString()}</td></tr>`)}</tbody></table></div>
      </section>
      <aside class="side stack">
        <section class="card stack"><h2>Quick checks</h2>
          <a href=${href("inventory", { kind: "glue_jobs", quick: "not_orchestrated" })}>Glue jobs no state machine runs</a>
          <a href=${href("inventory", { kind: "tables", "f.layer": "published", quick: "no_lineage" })}>Published tables with no lineage</a>
          <a href=${href("inventory", { kind: "tables", "f.layer": "none" })}>Tables with no layer (${data.tables_without_layer.toLocaleString()})</a>
          <a href=${href("inventory", { kind: "state_machines", quick: "has_gaps" })}>State machines with gaps</a>
          <a href=${href("inventory", { kind: "glue_jobs", quick: "no_ops" })}>Glue jobs missing from ops.yaml</a>
        </section>
        <section class="card stack"><h2>ops.yaml · ${data.ops_problems.length} problem${data.ops_problems.length === 1 ? "" : "s"}</h2>
          ${data.ops_problems.length ? html`<div class="rows">${data.ops_problems.map((p) => html`<div class="rowi">
            <span class="nm mono">${p.key || "(file)"}</span><span class="why">${p.problem}</span></div>`)}</div>`
            : html`<p class="muted" style="margin:0">No problems found.</p>`}
        </section>
      </aside>
    </div>`;
}
