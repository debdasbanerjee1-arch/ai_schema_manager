import { html, useState } from "../lib/preact.js";
import { get, qs, useApi } from "../lib/api.js";
import { href, patch } from "../lib/router.js";
import { Empty, ErrorBox, Gaps, Groups, Loading, Notes, Picker, Stats, Steps, copyText, detailHref } from "../lib/ui.js";

const MODES = [
  ["failure", "A job failed", ["glue_job", "pipeline", "dms_task", "lambda_function"], "Which job, state machine, DMS task or Lambda failed?"],
  ["stale", "A table is stale", ["table", "extract"], "Which table is stale?"],
  ["column", "A column is changing", ["column"], "Which column is changing? Type table.column or just the column name"],
];
const COUNT_COLOR = { raw: "var(--l-raw)", distill: "var(--l-distill)", published: "var(--l-published)", consumer: "var(--l-consumer)",
  job: "var(--l-job)", upstream: "var(--l-source)", downstream: "var(--l-published)", config: "var(--ink-2)", code: "var(--l-job)" };

function Branches({ key_, ck }) {
  const { data } = useApi("/api/detail", { key: key_ }, key_);
  const inst = (data && data.bound_instances) || [];
  if (inst.length < 2) return null;
  return html`<label class="row small">Branch
    <select class="select" style="width:auto;min-width:260px" value=${ck || ""} onChange=${(e) => patch({ ck: e.target.value || null })}>
      <option value="">Whole job (all ${inst.length} branches)</option>
      ${inst.map((b) => html`<option value=${b.config_key}>${b.config_key}</option>`)}
    </select></label>`;
}

export function Impact({ params }) {
  const mode = params.get("mode") || "failure";
  const key = params.get("key");
  const ck = params.get("ck") || "";
  const m = MODES.find((x) => x[0] === mode) || MODES[0];
  const req = mode === "failure" ? { key, config_key: ck } : { key };
  const { data, error, loading } = useApi(`/api/impact/${mode}`, req, key ? mode + JSON.stringify(req) : null);
  const [copied, setCopied] = useState(false);
  const rb = { mode, key, config_key: mode === "failure" ? ck : "" };

  return html`
    <h1>Impact and recovery</h1>
    <div class="seg noprint" role="group" aria-label="What happened">${MODES.map(([k, label]) => html`
      <button class=${mode === k ? "on" : ""} aria-pressed=${mode === k} onClick=${() => { location.hash = href("impact", { mode: k }); }}>${label}</button>`)}</div>
    <div class="card stack noprint">
      <${Picker} key=${mode} label=${m[3]} types=${m[2]} value=${data ? data.component.name : ""}
        onPick=${(r) => patch({ key: r.key, ck: null })} />
      ${mode === "failure" && key ? html`<${Branches} key_=${key} ck=${ck} />` : null}
    </div>
    ${!key ? html`<${Empty}>Pick a component to see what it affects and the ${mode === "column" ? "change" : "recovery"} checklist.</${Empty}>` : null}
    <${ErrorBox} error=${error} />
    ${key && loading && !data ? html`<${Loading} what="Working it out" />` : null}
    ${data ? html`
      <div class="row muted"><a class="mono" href=${detailHref(data.component.key)}>${data.component.name}</a> · ${data.context}
        ${data.config_key ? html` · branch <span class="mono">${data.config_key}</span>` : null}</div>
      <${Stats} items=${data.counts.map((c) => ({ ...c, color: COUNT_COLOR[c.layer] }))} />
      <${Notes} notes=${data.notes} />
      <div class="split">
        <section class="card main stack" aria-labelledby="h-list"><h2 id="h-list">${data.list_title}</h2>
          ${data.empty ? html`<p class="note" style="margin:0">${data.empty}</p>` : html`<${Groups} groups=${data.groups} />`}
        </section>
        <aside class="card side stack" aria-labelledby="h-plan"><h2 id="h-plan">${data.plan_title}</h2>
          <${Steps} steps=${data.steps} />
          <div class="row noprint" style="border-top:1px solid var(--border);padding-top:12px">
            <a class="btn primary" href=${"/api/runbook" + qs({ ...rb, download: true })}>Download runbook</a>
            <button class="btn" onClick=${async () => setCopied(await copyText(await get("/api/runbook", rb)))}>${copied ? "Copied" : "Copy as Markdown"}</button>
            <button class="btn" onClick=${() => window.print()}>Print or PDF</button>
          </div>
          <p class="small muted" style="margin:0">Amber tags come from ops.yaml, kept by prod support. Built from snapshot ${data.snapshot}; check live status before acting.</p>
        </aside>
      </div>
      <${Gaps} gaps=${data.gaps} />` : null}`;
}
