import { html } from "../lib/preact.js";
import { href } from "../lib/router.js";
import { LAYERS, LAYER_LABEL, Loading, Stats, layerVar } from "../lib/ui.js";

const QUESTIONS = [
  ["Which jobs depend on this DynamoDB config?", "discover", { tab: "config" }],
  ["What feeds this table?", "flow", {}],
  ["Where can I find platform charges applied to a wrapper or policy?", "discover", { tab: "terms", q: "platform charges" }],
  ["Which table holds contribution details?", "discover", { tab: "terms", q: "contribution" }],
  ["A job failed: what is affected, and how do we recover?", "impact", { mode: "failure" }],
  ["A table is stale: who populates it, and who is affected?", "impact", { mode: "stale" }],
  ["A column is changing: which components are affected?", "impact", { mode: "column" }],
  ["Browse every table, job, state machine and task", "inventory", { kind: "tables" }],
];

const HARVEST = [
  ["triggers_harvested", "Triggers (schedules and events)"],
  ["consumers_harvested", "Consumers (dashboards, APIs, extracts)"],
  ["terms_harvested", "Business terms"],
  ["load_times_present", "Load times"],
  ["column_lineage_beyond_distill", "Column lineage beyond Distill"],
];

export function Home({ meta }) {
  if (!meta) return html`<${Loading} />`;
  const c = meta.counts;
  const total = Object.values(meta.tables_by_layer).reduce((a, b) => a + b, 0) || 1;
  return html`
    <h1>What do you want to find out?</h1>
    <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(260px,1fr))">${QUESTIONS.map(([q, s, p]) => html`
      <a class="card" href=${href(s, p)} style="color:var(--ink)"><b>${q}</b></a>`)}</div>
    <${Stats} items=${[
      { n: c.tables.toLocaleString(), label: "Tables" }, { n: c.columns.toLocaleString(), label: "Columns" },
      { n: c.glue_jobs.toLocaleString(), label: "Glue jobs" }, { n: c.state_machines.toLocaleString(), label: "State machines" },
      { n: c.dms_tasks.toLocaleString(), label: "DMS tasks" }, { n: c.lambdas.toLocaleString(), label: "Lambda functions" },
      { n: c.edges.toLocaleString(), label: "Links in the graph" }]} />
    <div class="split">
      <section class="card main stack" aria-labelledby="h-layers">
        <h2 id="h-layers">Tables by layer</h2>
        ${LAYERS.filter((l) => meta.tables_by_layer[l]).map((l) => html`
          <a class="row" href=${href("inventory", { kind: "tables", "f.layer": l })} style="color:var(--ink)">
            <span style="width:110px">${LAYER_LABEL[l]}</span>
            <span class="grow" style="background:var(--surface-2);border-radius:4px;height:10px">
              <span style=${`display:block;height:10px;border-radius:4px;background:${layerVar(l)};width:${(100 * meta.tables_by_layer[l] / total).toFixed(1)}%`}></span>
            </span>
            <b style="width:60px;text-align:right">${meta.tables_by_layer[l].toLocaleString()}</b>
          </a>`)}
        <h3 style="margin-top:8px">Systems</h3>
        <div class="row">${Object.entries(meta.systems).map(([s, n]) => html`
          <a class="chip" href=${href("inventory", { kind: "tables", "f.system": s })}>${s} <span class="n">${n}</span></a>`)}</div>
      </section>
      <section class="card side stack" aria-labelledby="h-health">
        <h2 id="h-health">In this snapshot</h2>
        <ul style="margin:0;padding-left:0;list-style:none" class="stack">${HARVEST.map(([k, label]) => html`
          <li class="row"><span class=${"badge " + (meta.flags[k] ? "green" : "amber")}>${meta.flags[k] ? "Yes" : "Not yet"}</span> ${label}</li>`)}</ul>
        <p style="margin:0"><a href=${href("health")}>${meta.gaps_total.toLocaleString()} open gaps</a>${meta.ops_problems ? html` · ${meta.ops_problems} ops.yaml problems` : null}</p>
      </section>
    </div>`;
}
