import { html, useEffect, useState } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { href, patch } from "../lib/router.js";
import { Badge, Empty, ErrorBox, Layer, Loading, NodeLink, Notes, Stats } from "../lib/ui.js";

function useDebounced(value, set, ms = 300) {
  const [text, setText] = useState(value || "");
  useEffect(() => setText(value || ""), [value]);
  useEffect(() => {
    if (text === (value || "")) return;
    const t = setTimeout(() => set(text), ms);
    return () => clearTimeout(t);
  }, [text]);
  return [text, setText];
}

const Names = ({ items, empty }) => items.length ? html`<div class="stack" style="gap:2px">${items.map((n) => html`<span><${NodeLink} node=${n} showType=${false} /></span>`)}</div>`
  : html`<span class="muted small">${empty || "none recorded"}</span>`;

function Config({ params }) {
  const tables = useApi("/api/config/tables", {}, "cfg");
  const table = params.get("table") || (tables.data && tables.data[0] && tables.data[0].name);
  const q = params.get("q") || "";
  const { data, error, loading } = useApi("/api/config", { table, q }, table ? table + "|" + q : null);
  const [text, setText] = useDebounced(q, (v) => patch({ q: v }));
  if (tables.error) return html`<${ErrorBox} error=${tables.error} />`;
  if (!tables.data) return html`<${Loading} />`;
  if (!tables.data.length) return html`<${Empty}>No configuration references in this graph.</${Empty}>`;
  return html`
    <div class="stack" style="gap:6px"><span class="label">Which DynamoDB config table?</span>
      <div class="row">${tables.data.map((t) => html`<button class=${"chip" + (t.name === table ? " on" : "")} aria-pressed=${t.name === table}
        onClick=${() => patch({ table: t.name, q: null })}><span class="mono">${t.name}</span><span class="n">${t.items} items</span></button>`)}</div></div>
    <${ErrorBox} error=${error} />
    ${data ? html`
      <${Stats} items=${[{ n: data.totals.items, label: "Items" }, { n: data.totals.jobs_and_state_machines, label: "Jobs and state machines that use it" },
        { n: data.totals.tables_written, label: "Tables they write" }, { n: data.totals.consumers_downstream, label: "Consumers downstream" }]} />
      <${Notes} notes=${data.notes} />
      <section class="card stack"><div class="row" style="justify-content:space-between"><h2>Items and what depends on them</h2>
        <div style="width:320px"><label class="label" for="cfg-q">Filter items</label>
          <input id="cfg-q" class="input" type="search" value=${text} onInput=${(e) => setText(e.target.value)} placeholder="for example address" /></div></div>
        ${loading ? html`<span class="small muted">updating…</span>` : null}
        ${data.items.length ? html`<div class="tablewrap"><table class="data">
          <thead><tr><th>Config key</th><th>Jobs</th><th>State machines</th><th>Reads</th><th>Writes</th><th>Consumers</th></tr></thead>
          <tbody>${data.items.map((it) => html`<tr>
            <td class="long"><span class="mono">${it.config_key}</span>${!it.bound ? html` <${Badge} tone="red">not bound</${Badge}>` : null}
              ${it.gaps.map((g) => html` <${Badge} tone="red">${g.reason}</${Badge}>`)}</td>
            <td class="long"><${Names} items=${it.jobs} /></td><td class="long"><${Names} items=${it.state_machines} /></td>
            <td class="long"><${Names} items=${it.reads} /></td><td class="long"><${Names} items=${it.writes} /></td>
            <td class="long"><${Names} items=${it.consumers} empty="" /></td>
          </tr>`)}</tbody></table></div>` : html`<${Empty}>No items match.</${Empty}>`}
      </section>` : html`<${Loading} />`}`;
}

const TRIES = ["platform charges", "contribution", "wrapper", "postcode", "adviser address"];

function Terms({ params }) {
  const q = params.get("q") || "";
  const { data, error, loading } = useApi("/api/terms", { q }, q || null);
  const [text, setText] = useDebounced(q, (v) => patch({ q: v }));
  return html`
    <div class="card stack" style="max-width:820px">
      <label class="label" for="term-q">Where can I find… (a business term, or a question)</label>
      <input id="term-q" class="input big" type="search" value=${text} onInput=${(e) => setText(e.target.value)}
        placeholder="for example: Which table holds contribution details?" />
      <div class="row small"><span class="muted">Try:</span>${TRIES.map((t) => html`<button class="chip" onClick=${() => patch({ q: t })}>${t}</button>`)}</div>
    </div>
    <${ErrorBox} error=${error} />
    ${q && loading && !data ? html`<${Loading} />` : null}
    ${data ? html`
      ${data.note ? html`<${Notes} notes=${[data.note]} />` : null}
      <section class="card stack"><h2>Business terms · ${data.terms.length}</h2>
        ${data.terms.length ? data.terms.map((t) => html`<div class="stack" style="gap:6px;padding:12px;border:1px solid var(--border);border-radius:10px">
          <div class="row"><b>${t.term}</b><${Badge} tone=${t.approved ? "green" : "amber"}>${t.approved ? "approved" : "draft"} · ${t.origin || ""}</${Badge}></div>
          ${t.definition ? html`<span class="d">${t.definition}</span>` : null}
          <div class="rows">${t.columns.map((c) => html`<div class="rowi"><span class="nm"><${NodeLink} node=${c} showType=${false} /></span>
            <${Layer} layer=${c.layer} /><span class="small">${c.system || ""}</span></div>`)}</div>
        </div>`) : html`<p class="muted" style="margin:0">${data.terms_harvested ? "No business term matches." : "No business terms in this snapshot yet."}</p>`}
      </section>
      <section class="card stack"><h2>Name matches · ${data.names_total || 0}</h2>
        <p class="small muted" style="margin:0">Tables and columns whose names contain the words you typed. Weaker evidence than a business term.</p>
        <div class="rows">${data.names.map((c) => html`<div class="rowi"><span class="nm"><${NodeLink} node=${c} showType=${false} /></span>
          <span class="small muted">${c.what}</span><${Layer} layer=${c.layer} /><span class="small">${c.system || ""}</span></div>`)}</div>
      </section>` : null}`;
}

export function Discover({ params }) {
  const tab = params.get("tab") || "config";
  return html`
    <h1>Discover</h1>
    <div class="seg" role="tablist">${[["config", "Config dependencies"], ["terms", "Find a business term"]].map(([k, l]) => html`
      <button role="tab" aria-selected=${tab === k} class=${tab === k ? "on" : ""} onClick=${() => { location.hash = href("discover", { tab: k }); }}>${l}</button>`)}</div>
    ${tab === "config" ? html`<${Config} params=${params} />` : html`<${Terms} params=${params} />`}`;
}
