import { html, useEffect, useState } from "../lib/preact.js";
import { qs, useApi } from "../lib/api.js";
import { href, patch } from "../lib/router.js";
import { ErrorBox, Layer, Loading, detailHref } from "../lib/ui.js";

const FACET_LABEL = { layer: "Layer", system: "System", database: "Database", distill_kind: "Distill kind",
  raw_stage: "Raw stage", subsystem: "Subsystem", product: "Product", command: "Command", family: "Family",
  trigger: "Trigger", sfn_type: "Type", status: "Status", migration_type: "Migration type",
  target_engine: "Target engine", runtime: "Runtime", type: "Type" };
const PAGE = 100;
const LONG = new Set(["name", "writers", "source_equivalent", "script_location", "run_by", "started_by", "starts",
  "invoked_by", "triggered_by", "uses", "handler", "primary_key"]);

function readParams(params) {
  const filters = {};
  for (const k of new Set(params.keys())) if (k.startsWith("f.")) filters[k] = params.getAll(k);
  return {
    kind: params.get("kind") || "tables", q: params.get("q") || "", quick: params.getAll("quick"),
    sort: params.get("sort") || "name", desc: params.get("desc") === "1",
    offset: parseInt(params.get("offset") || "0", 10) || 0, filters,
  };
}

function Facet({ field, values, selected }) {
  const [all, setAll] = useState(false);
  const shown = all ? values : values.slice(0, 8);
  const toggle = (v) => {
    const s = new Set(selected);
    s.has(v) ? s.delete(v) : s.add(v);
    patch({ ["f." + field]: [...s], offset: null });
  };
  if (!values.length) return null;
  return html`<div class="facet"><h3>${FACET_LABEL[field] || field}</h3>
    ${shown.map((v) => html`<label><input type="checkbox" checked=${selected.includes(String(v.value))}
      onChange=${() => toggle(String(v.value))} /><span class="mono" style="font-size:12px">${v.value}</span><span class="n">${v.n}</span></label>`)}
    ${values.length > 8 ? html`<button class="more" onClick=${() => setAll(!all)}>${all ? "Show fewer" : `Show all ${values.length}`}</button>` : null}
  </div>`;
}

export function Inventory({ params }) {
  const p = readParams(params);
  const summary = useApi("/api/inventory/summary", {}, "summary");
  const req = { kind: p.kind, q: p.q, quick: p.quick, sort: p.sort, desc: p.desc, offset: p.offset, limit: PAGE, ...p.filters };
  const key = JSON.stringify(req);
  const { data, error, loading } = useApi("/api/inventory", req, key);
  const [text, setText] = useState(p.q);
  useEffect(() => setText(p.q), [p.q]);
  useEffect(() => {
    if (text === p.q) return;
    const t = setTimeout(() => patch({ q: text, offset: null }), 300);
    return () => clearTimeout(t);
  }, [text]);

  const sortBy = (c) => patch({ sort: c, desc: p.sort === c ? !p.desc : ["name"].includes(c) ? false : true, offset: null });
  const csv = "/api/inventory.csv" + qs({ kind: p.kind, q: p.q, quick: p.quick, sort: p.sort, desc: p.desc, ...p.filters });
  const activeFilters = Object.values(p.filters).some((v) => v.length) || p.quick.length || p.q;

  return html`
    <div class="row" style="justify-content:space-between"><h1>Inventory</h1>
      <a class="btn" href=${csv} download>Download CSV</a></div>
    <div class="seg" role="tablist" aria-label="Kind">${(summary.data || []).map((k) => html`
      <button role="tab" aria-selected=${p.kind === k.kind} class=${p.kind === k.kind ? "on" : ""}
        onClick=${() => { location.hash = href("inventory", { kind: k.kind }); }}>${k.label} <span class="muted small">${k.n.toLocaleString()}</span></button>`)}
    </div>
    <div class="split">
      <aside class="card side facets" style="flex:0 1 260px" aria-label="Filters">
        <div><label class="label" for="inv-q">Name contains</label>
          <input id="inv-q" class="input" type="search" value=${text} onInput=${(e) => setText(e.target.value)} /></div>
        ${data ? html`<div class="facet"><h3>Quick filters</h3><div class="row">${data.quick.map((x) => html`
          <button class=${"chip" + (p.quick.includes(x.id) ? " on" : "")} aria-pressed=${p.quick.includes(x.id)}
            onClick=${() => patch({ quick: p.quick.includes(x.id) ? p.quick.filter((y) => y !== x.id) : [...p.quick, x.id], offset: null })}>
            ${x.label} <span class="n">${x.n}</span></button>`)}</div></div>
          ${Object.entries(data.facets).map(([f, vals]) => html`<${Facet} field=${f} values=${vals} selected=${p.filters["f." + f] || []} />`)}` : null}
        ${activeFilters ? html`<button class="btn small" onClick=${() => { location.hash = href("inventory", { kind: p.kind }); }}>Clear filters</button>` : null}
      </aside>
      <section class="main stack" aria-label="Results">
        <${ErrorBox} error=${error} />
        ${!data && loading ? html`<${Loading} />` : null}
        ${data ? html`
          <div class="row muted">${data.matched.toLocaleString()} of ${data.total.toLocaleString()} ${data.label.toLowerCase()}
            ${loading ? html`<span class="small">updating…</span>` : null}</div>
          <div class="tablewrap"><table class="data">
            <thead><tr>${data.columns.map((c) => html`<th class=${c.numeric ? "num" : ""} aria-sort=${p.sort === c.id ? (p.desc ? "descending" : "ascending") : null}>
              <button onClick=${() => sortBy(c.id)}>${c.label}${p.sort === c.id ? (p.desc ? " ↓" : " ↑") : ""}</button></th>`)}</tr></thead>
            <tbody>${data.rows.map((r) => html`<tr>${data.columns.map((c) => html`<td class=${c.numeric ? "num" : LONG.has(c.id) ? "long" : ""}>${
              c.id === "name" ? html`<a href=${detailHref(r.key)} class="mono">${r.name}</a>`
              : c.id === "layer" ? html`<${Layer} layer=${r.layer} />`
              : c.id === "gaps" && r.gaps ? html`<span class="badge red">${r.gaps}</span>`
              : String(r[c.id] ?? "")}</td>`)}</tr>`)}</tbody>
          </table></div>
          ${data.matched > PAGE ? html`<div class="row">
            <button class="btn small" disabled=${p.offset === 0} onClick=${() => patch({ offset: Math.max(0, p.offset - PAGE) || null })}>Previous</button>
            <span class="muted small">${p.offset + 1}–${Math.min(p.offset + PAGE, data.matched)} of ${data.matched.toLocaleString()}</span>
            <button class="btn small" disabled=${p.offset + PAGE >= data.matched} onClick=${() => patch({ offset: p.offset + PAGE })}>Next</button>
          </div>` : null}` : null}
      </section>
    </div>`;
}
