import { html, render, useEffect, useState } from "./lib/preact.js";
import { get } from "./lib/api.js";
import { go, href, useRoute } from "./lib/router.js";
import { Picker, ago, detailHref } from "./lib/ui.js";
import { Home } from "./screens/home.js";
import { Inventory } from "./screens/inventory.js";
import { Detail } from "./screens/detail.js";
import { Lineage } from "./screens/lineage.js";
import { Flow } from "./screens/flow.js";
import { Impact } from "./screens/impact.js";
import { Discover } from "./screens/discover.js";
import { Health } from "./screens/health.js";
import { Search } from "./screens/search.js";

const NAV = [["home", "Home"], ["inventory", "Inventory"], ["lineage", "Lineage"], ["flow", "Flow"],
  ["impact", "Impact and recovery"], ["discover", "Discover"], ["health", "Health"]];
const SCREENS = { home: Home, inventory: Inventory, detail: Detail, lineage: Lineage, flow: Flow, impact: Impact,
  discover: Discover, health: Health, search: Search };

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
// 20261013T105815Z -> 13 Oct 2026
const snapDate = (id) => /^\d{8}T/.test(id) ? `${+id.slice(6, 8)} ${MONTHS[+id.slice(4, 6) - 1]} ${id.slice(0, 4)}` : id;

function Shell() {
  const route = useRoute();
  const [meta, setMeta] = useState(null);
  const [err, setErr] = useState(null);
  useEffect(() => { get("/api/meta").then(setMeta, setErr); }, [route.screen]);
  const Screen = SCREENS[route.screen] || Home;
  const old = meta && (Date.now() - Date.parse(meta.built_at)) / 864e5 > 7;
  return html`
    <header class="top"><div class="top-inner">
      <a class="brand" href=${href("home")}>Knowledge Fabric</a>
      <nav class="nav" aria-label="Main">${NAV.map(([k, label]) => html`
        <a href=${href(k)} class=${route.screen === k ? "on" : ""} aria-current=${route.screen === k ? "page" : null}>${label}</a>`)}
      </nav>
      ${meta ? html`<span class=${"snap" + (old ? " old" : "")} title=${"Snapshot " + meta.snapshot + ", graph " + meta.graph_file + ", built " + meta.built_at}>
        Graph ${snapDate(meta.snapshot)} · ${ago(meta.built_at)}</span>` : null}
      <div class="top-search" onKeyDown=${(e) => { if (e.key === "Enter" && e.target.value && !e.defaultPrevented) go("search", { q: e.target.value }); }}>
        <${Picker} id="global-search" placeholder="Search tables, jobs, columns…" onPick=${(r) => go("detail", { key: r.key })} />
      </div>
    </div></header>
    <main id="main">
      ${err ? html`<p class="err">The service could not be reached: ${String(err.message || err)}</p>` : null}
      <${Screen} params=${route.params} meta=${meta} key=${route.screen} />
    </main>`;
}

const root = document.getElementById("app");
root.textContent = "";
render(html`<${Shell} />`, root);
