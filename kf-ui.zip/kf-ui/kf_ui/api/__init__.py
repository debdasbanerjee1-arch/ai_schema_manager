"""Read-only HTTP API and static UI."""
