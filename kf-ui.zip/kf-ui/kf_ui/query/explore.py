"""Search, component detail, lineage, end-to-end flow, config dependencies, terms, health."""

from __future__ import annotations

from collections import Counter, deque

from .impact import _consumers, _downstream, _orch, handoff
from .redact import redact
from .store import CONSUMER_TYPES, JOB_TYPES, ORCH_TYPES
from .text import match_score, norm, stems, words_of

TYPE_LABEL = {"table": "Table", "column": "Column", "glue_job": "Glue job", "lambda_function": "Lambda",
              "dms_task": "DMS task", "pipeline": "State machine", "pipeline_task": "State",
              "extract": "Extract", "dashboard": "Dashboard", "api_endpoint": "API", "glossary_term": "Term",
              "channel": "Channel", "data_model": "Data model", "chart": "Chart"}


def meta(g, ops):
    c = Counter(n["type"] for n in g.nodes.values())
    layers = Counter(n["layer"] for n in g.nodes.values() if n["type"] == "table")
    return {"snapshot": g.snapshot_id, "built_at": g.built_at, "graph_file": g.path.name,
            "counts": {"tables": c.get("table", 0), "columns": len(g.columns), "glue_jobs": c.get("glue_job", 0),
                       "state_machines": c.get("pipeline", 0), "dms_tasks": c.get("dms_task", 0),
                       "lambdas": c.get("lambda_function", 0), "nodes": len(g.nodes) + len(g.columns),
                       "edges": sum(len(v) for v in g.out.values())},
            "tables_by_layer": dict(layers), "systems": dict(Counter(n["system"] for n in g.nodes.values()
                                                                      if n["type"] == "table" and n["system"]).most_common()),
            "flags": g.flags, "gaps_total": len(g.gaps),
            "gaps_by_reason": dict(Counter(x.get("reason") for x in g.gaps).most_common()),
            "ops_problems": len(ops.validate(g))}


# ---------------------------------------------------------------- search
def search(g, q, types=None, layer=None, system=None, limit=50, aliases=None, include_columns=True,
           include_one_off=False):
    aliases = {norm(k): v for k, v in (aliases or {}).items()}
    sys_from_alias = aliases.get(norm(q))
    results = []
    for k, n in g.nodes.items():
        if n["type"] == "pipeline_task":
            continue
        if types and n["type"] not in types:
            continue
        if layer and n["layer"] != layer:
            continue
        if system and n.get("system") != system:
            continue
        if not include_one_off and n["attrs"].get("replication_mode") == "one_off":
            continue
        s = match_score(q, n["name"], k)
        if not s and sys_from_alias and n.get("system") == sys_from_alias:
            s = 20
        if s:
            results.append((s, {**g.ref(k), "label": TYPE_LABEL.get(n["type"], n["type"])}))
    if include_columns and (not types or "column" in types) and len(norm(q)) >= 3:
        for k, c in g.columns.items():
            s = match_score(q, c["name"])
            if s >= 60:
                r = g.ref(k)
                if layer and r["layer"] != layer or system and r["system"] != system:
                    continue
                results.append((s - 5, {**r, "label": "Column"}))
    results.sort(key=lambda x: (-x[0], x[1]["name"]))
    return {"query": q, "alias_system": sys_from_alias, "total": len(results),
            "results": [r for _, r in results[:limit]]}


# ---------------------------------------------------------------- detail
def detail(g, ops, key):
    n = g.get(key)
    if not n:
        raise KeyError(key)
    nb = {}
    for e in g.out.get(key, ()):
        nb.setdefault(f"{e.type}{'/' + e.relation if e.relation else ''} →", []).append({**g.ref(e.dst), "edge": e.brief()})
    for e in g.inn.get(key, ()):
        nb.setdefault(f"← {e.type}{'/' + e.relation if e.relation else ''}", []).append({**g.ref(e.src), "edge": e.brief()})
    neighbours = [{"group": k, "size": len(v), "rows": v[:50]} for k, v in sorted(nb.items())]
    out = {"component": {**g.ref(key), "label": TYPE_LABEL.get(n["type"], n["type"])},
           "attrs": redact(n.get("attrs", {})), "ops": ops.get(key), "ops_tags": ops.tags(key),
           "neighbours": neighbours, "gaps": g.gaps_for(key), "snapshot": g.snapshot_id, "built_at": g.built_at}
    if n["type"] in JOB_TYPES:
        out["orchestrators"] = [g.ref(o) for o in g.orchestrators_of(key)]
        out["bound_instances"] = g.bound_instances(key)
        out["inputs"] = [g.ref(i) for i, _ in g.job_inputs(key)]
        out["outputs"] = [g.ref(o) for o, _ in g.job_outputs(key)]
    if n["type"] in ORCH_TYPES:
        out["jobs"] = [g.ref(j) for j in g.jobs_of(key)]
        out["children"] = [g.ref(c) for c in g.children_of(key)]
        out["started_by"] = [g.ref(s) for s in g.starters_of(key)]
        out["triggers"] = n["attrs"].get("triggers")
    if n["type"] in ("table", "extract"):
        out["columns"] = [{**g.ref(c), "data_type": g.columns[c]["data_type"], **g.columns[c]["attrs"]}
                          for c in g.table_columns.get(key, [])]
        out["loaded"] = g.load_time(key)
        out["consumers"] = [g.ref(c) for c in g.consumers_of(key)]
    if n["type"] == "column":
        out["upstream"] = [{**g.ref(e.src), "edge": e.brief()} for e in g.column_lineage_in(key)]
        out["downstream"] = [{**g.ref(e.dst), "edge": e.brief()} for e in g.column_lineage_out(key)]
        out["terms"] = [g.ref(e.dst) for e in g.edges_out(key, "means")]
    return out


# ---------------------------------------------------------------- lineage
def lineage(g, key, direction="both", depth=3, lens="data", level="table"):
    if level == "column" or g.is_column(key):
        fwd, back = g.column_lineage_out, g.column_lineage_in
    else:
        fwd, back = g.table_lineage_out, g.table_lineage_in
    nodes, edges, seen_e = {key: 0}, [], set()

    def walk(step, sign):
        q = deque([(key, 0)])
        while q:
            x, d = q.popleft()
            if d >= depth:
                continue
            for e in step(x):
                y = e.dst if sign > 0 else e.src
                if e.id not in seen_e:
                    seen_e.add(e.id)
                    edges.append(e)
                if y not in nodes:
                    nodes[y] = sign * (d + 1)
                    q.append((y, d + 1))
    if direction in ("both", "down"):
        walk(fwd, 1)
    if direction in ("both", "up"):
        walk(back, -1)
    out_nodes = []
    for k, d in nodes.items():
        r = {**g.ref(k), "depth": d, "gaps": len(g.gaps_for(k)), "loaded": g.load_time(k)}
        if level == "table" and not g.is_column(k):
            r["consumers"] = [g.ref(c) for c in g.consumers_of(k)]
            r["more_up"] = bool(g.table_lineage_in(k)) and d == -depth
            r["more_down"] = bool(g.table_lineage_out(k)) and d == depth
        out_nodes.append(r)
    out_edges = []
    for e in edges:
        b = e.brief()
        if lens == "orchestration" and e.job:
            o = _orch(g, e.job, e.attrs.get("config_key"))
            b["job_name"] = g.name(e.job)
            b["orchestrator"] = g.ref(o) if o else None
        out_edges.append(b)
    return {"root": g.ref(key), "direction": direction, "depth": depth, "lens": lens, "level": level,
            "nodes": out_nodes, "edges": out_edges, "snapshot": g.snapshot_id}


# ---------------------------------------------------------------- end-to-end flow
def flow(g, key, ops=None):
    """Orchestrators the data of one table passes through, upstream to downstream, with hand-offs."""
    n = g.get(key)
    if not n:
        raise KeyError(key)
    # upstream: nearest first, then reverse
    hops, dist, q = [], {key: 0}, deque([key])
    while q:
        x = q.popleft()
        for e in g.table_lineage_in(x):
            if e.src not in dist:
                dist[e.src] = dist[x] + 1
                hops.append((dist[e.src], e))
                q.append(e.src)
    hops = [e for _, e in sorted(hops, key=lambda h: -h[0])]
    down, _ = _downstream(g, {key: (None, None)})
    hops += [e for k, hop, e, job in down if e is not None and e.type == "derives_from"]

    segments = []
    for e in hops:
        job = e.job
        o = _orch(g, job, e.attrs.get("config_key")) if job else None
        seg_key = o or job or "unknown"
        seg = next((s for s in segments if s["key"] == seg_key), None)
        if not seg:
            jn = g.nodes.get(job, {}) if job else {}
            seg = {"key": seg_key, "orchestrator": g.ref(o) if o else None, "jobs": [], "steps": [],
                   "kind": "dms" if jn.get("type") == "dms_task" else ("state_machine" if o else "job"),
                   "handoff_in": None, "ops_tags": ops.tags(seg_key) if ops else []}
            # hand-off into this segment: who wrote the table this hop reads
            ins = g.table_lineage_in(e.src)
            wj = ins[0].job if ins else None
            wo = _orch(g, wj) if wj else None
            if o and segments:
                seg["handoff_in"] = handoff(g, wo, o, e.src, [wj] if wj else [])
                seg["handoff_from"] = g.ref(wo) if wo else (g.ref(wj) if wj else None)
            segments.append(seg)
        if job and all(j["key"] != job for j in seg["jobs"]):
            seg["jobs"].append(g.ref(job))
        seg["steps"].append({"from": g.ref(e.src), "to": g.ref(e.dst), "job": g.ref(job) if job else None,
                             "config_key": e.attrs.get("config_key"), "tier": e.tier, "origin": e.origin})
    consumers = [g.ref(c) for c in _consumers(g, [key] + [k for k, *_ in down])]
    return {"table": g.ref(key), "segments": segments, "consumers": consumers,
            "triggers_harvested": g.flags.get("triggers_harvested"), "snapshot": g.snapshot_id}


# ---------------------------------------------------------------- config dependencies
def config_tables(g):
    c = Counter()
    keys = {}
    for es in g.out.values():
        for e in es:
            t = e.attrs.get("config_table")
            if t:
                c[t] += 1
                keys.setdefault(t, set()).add(e.attrs.get("config_key"))
    return [{"name": t, "edges": n, "items": len(keys[t])} for t, n in c.most_common()]


def config_deps(g, config_table, q=""):
    items = {}
    for es in g.out.values():
        for e in es:
            if e.attrs.get("config_table") != config_table:
                continue
            ck = e.attrs.get("config_key") or "(no key)"
            it = items.setdefault(ck, {"config_key": ck, "jobs": set(), "state_machines": set(), "reads": set(),
                                       "writes": set()})
            job = e.job if e.type == "derives_from" else (e.src if g.nodes.get(e.src, {}).get("type") in JOB_TYPES else None)
            if job:
                it["jobs"].add(job)
                for o in g.orchestrators_of(job, ck):
                    it["state_machines"].add(o)
            sm = g.sfn_key(e.attrs.get("via_state_machine"))
            if sm:
                it["state_machines"].add(sm)
            if e.type == "reads":
                it["reads"].add(e.dst)
            elif e.type == "writes":
                it["writes"].add(e.dst)
            elif e.type == "derives_from" and not g.is_column(e.dst):
                it["reads"].add(e.src)
                it["writes"].add(e.dst)
            elif e.type == "derives_from":
                it["writes"].add(g.columns[e.dst]["table"])
    ql = (q or "").lower()
    rows, all_jobs, all_tables, all_cons = [], set(), set(), set()
    for ck, it in sorted(items.items()):
        down, _ = _downstream(g, {t: (None, None) for t in it["writes"]})
        cons = set(_consumers(g, [k for k, *_ in down]))
        cons |= {k for k, *_ in down if (g.get(k) or {}).get("layer") == "consumer"}
        all_jobs |= it["jobs"] | it["state_machines"]
        all_tables |= it["writes"]
        all_cons |= cons
        if ql and ql not in ck.lower():
            continue
        gaps = g.gaps_for(ck)
        rows.append({"config_key": ck, "jobs": [g.ref(j) for j in sorted(it["jobs"])],
                     "state_machines": [g.ref(s) for s in sorted(it["state_machines"])],
                     "reads": [g.ref(t) for t in sorted(it["reads"])], "writes": [g.ref(t) for t in sorted(it["writes"])],
                     "consumers": [g.ref(c) for c in sorted(cons)], "gaps": gaps,
                     "bound": bool(it["jobs"] or it["state_machines"])})
    return {"config_table": config_table, "items": rows,
            "totals": {"items": len(items), "jobs_and_state_machines": len(all_jobs), "tables_written": len(all_tables),
                       "consumers_downstream": len(all_cons)},
            "notes": [] if g.flags.get("consumers_harvested") else ["Consumers are not harvested yet (R9)."],
            "snapshot": g.snapshot_id}


# ---------------------------------------------------------------- terms
def terms(g, q, limit=30):
    st = stems(q)
    out = {"query": q, "terms_harvested": g.flags.get("terms_harvested"), "terms": [], "names": []}
    if not st:
        return out
    found = []
    for k, n in g.nodes.items():
        if n["type"] != "glossary_term":
            continue
        name_w = words_of(n["name"])
        hay = " ".join(name_w + words_of(n["attrs"].get("definition", "")))
        if all(any(w.startswith(s) for w in hay.split()) for s in st):
            in_name = sum(1 for s in st if any(w.startswith(s) for w in name_w))
            certified = n["attrs"].get("tier") == "certified" or n["attrs"].get("origin") in ("declared", "connector")
            found.append((in_name * 2 + (1 if certified else 0), k, n, certified))
    found.sort(key=lambda x: (-x[0], x[2]["name"]))
    listed = set()
    for _, k, n, certified in found:
        cols = [g.ref(e.src) for e in g.edges_in(k, "means")]
        listed |= {c["key"] for c in cols}
        out["terms"].append({"key": k, "term": n["name"], "definition": n["attrs"].get("definition"),
                             "origin": n["attrs"].get("origin"), "tier": n["attrs"].get("tier"),
                             "approved": certified, "columns": cols})
    names = []
    for k, n in g.nodes.items():
        if n["type"] not in ("table", "extract"):
            continue
        w = words_of(n["name"])
        hit = sum(1 for s in st if any(x.startswith(s) for x in w))
        if hit:
            names.append((hit, {**g.ref(k), "what": "table"}))
    for k, c in g.columns.items():
        if k in listed:
            continue
        w = words_of(c["name"])
        hit = sum(1 for s in st if any(x.startswith(s) for x in w))
        if hit:
            names.append((hit, {**g.ref(k), "what": "column"}))
    names.sort(key=lambda x: (-x[0], x[1]["name"]))
    out["names_total"] = len(names)
    out["names"] = [r for _, r in names[:limit]]
    if not g.flags.get("terms_harvested"):
        out["note"] = "Business terms are not in this snapshot yet (R10), so only name matches are shown."
    return out


# ---------------------------------------------------------------- health
def health(g, ops):
    by = Counter((x.get("rule"), x.get("reason")) for x in g.gaps)
    return {"snapshot": g.snapshot_id, "built_at": g.built_at, "flags": g.flags,
            "gaps": [{"rule": r, "reason": s, "n": n} for (r, s), n in sorted(by.items(), key=lambda i: -i[1])],
            "ops_problems": ops.validate(g),
            "tables_without_layer": sum(1 for n in g.nodes.values() if n["type"] == "table" and n["layer"] == "none")}


def consumer_count(g):
    def count(key):
        n = g.nodes.get(key, {})
        if n.get("type") in ORCH_TYPES:
            seeds = {}
            for j in g.jobs_of(key):
                for o, e in g.job_outputs(j):
                    seeds.setdefault(o, (j, e))
        elif n.get("type") in JOB_TYPES:
            seeds = {o: (key, e) for o, e in g.job_outputs(key)}
        else:
            return 0
        down, _ = _downstream(g, seeds)
        return len(_consumers(g, [k for k, *_ in down])) + sum(1 for k, *_ in down if (g.get(k) or {}).get("type") in CONSUMER_TYPES)
    return count
