"""Markdown runbook from an impact, stale or column-change result. The screen and the
export are built from the same result, so they never disagree."""

from datetime import datetime, timezone

CLOSING = ("Built from the Knowledge Fabric graph as of the snapshot above. "
           "Check live status in your monitoring tools before acting.")


def to_markdown(r):
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    comp = r["component"]
    lines = [f"# {r['plan_title']}: {comp['name']}", "",
             f"- Mode: {r['mode']}",
             f"- Component: `{comp['key']}`" + (f" (branch `{r['config_key']}`)" if r.get("config_key") else ""),
             f"- Context: {r['context']}",
             f"- Snapshot: {r['snapshot']} (graph built {r['built_at']})",
             f"- Generated: {now}", "", f"## {r['list_title']}"]
    if r.get("empty"):
        lines += ["", r["empty"]]
    for gr in r["groups"]:
        lines += ["", f"### {gr['name']} ({gr['size']})"]
        for row in gr["rows"]:
            lines.append(f"- {row['name']}" + (f": {row['why']}" if row.get("why") else ""))
    lines += ["", f"## {r['plan_title']}", ""]
    for s in r["steps"]:
        tags = [t for t in s.get("ops", []) if t]
        lines.append(f"{s['n']}. **{s['title']}**: {s['detail']}" + (f" _[{'; '.join(tags)}]_" if tags else ""))
    if r.get("gaps"):
        lines += ["", "## Gaps on this path", ""]
        for x in r["gaps"]:
            lines.append(f"- {x.get('rule')} {x.get('reason')} at {x.get('at')}" + (f": {x.get('detail')}" if x.get("detail") else ""))
    if r.get("notes"):
        lines += ["", "## Notes", ""] + [f"- {n}" for n in r["notes"]]
    lines += ["", f"_{CLOSING}_", ""]
    return "\n".join(lines)
