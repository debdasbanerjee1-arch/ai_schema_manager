"""Inventory: browse every component of one kind, with filters, counts and graph columns.

Inventory fields come from the node attributes; graph columns (inputs, outputs, run by,
consumers, gaps, ops) come from the graph. Paging and filtering happen here, so there is
no row cap. Per-node statistics are computed once per loaded graph and cached.
"""

from __future__ import annotations

import csv
import io

from .redact import mask_text
from .store import CONSUMER_TYPES
from .text import norm

# Glue job family by name pattern (first match wins). Adjust to match config/harvest.yaml job_families.
FAMILY_PATTERNS = [("raw2dis", "raw2dis"), ("generic_extract", "generic-extract")]

KINDS = {
    "tables": "Tables",
    "glue_jobs": "Glue jobs",
    "state_machines": "State machines",
    "dms_tasks": "DMS tasks",
    "lambdas": "Lambda functions",
    "consumers": "Consumers",
}

COLUMNS = {
    "tables": [("name", "Name"), ("layer", "Layer"), ("system", "System"), ("database", "Database"),
               ("distill_kind", "Distill kind"), ("raw_stage", "Raw stage"), ("raw_zone", "Raw zone"),
               ("subsystem", "Subsystem"), ("source_system_db", "Source database"), ("catalogued", "Catalogued"),
               ("product", "Product"), ("replication_mode", "Replication"), ("table_type", "Table type"),
               ("primary_key", "Primary key"), ("source_equivalent", "Source equivalent"),
               ("columns", "Columns"), ("inputs", "Inputs"), ("outputs", "Outputs"), ("writers", "Written by"),
               ("consumers", "Consumers"), ("loaded", "Last loaded"), ("owner", "Owner"), ("gaps", "Gaps")],
    "glue_jobs": [("name", "Name"), ("command", "Command"), ("family", "Family"), ("run_by", "Run by"),
                  ("config_items", "Config items"), ("inputs", "Inputs"), ("outputs", "Outputs"),
                  ("script_location", "Script location"), ("owner", "Owner"), ("criticality", "Criticality"),
                  ("gaps", "Gaps")],
    "state_machines": [("name", "Name"), ("trigger", "Trigger"), ("states", "States"), ("jobs", "Jobs"),
                       ("started_by", "Started by"), ("starts", "Starts"), ("tables_written", "Tables written"),
                       ("sfn_type", "Type"), ("owner", "Owner"), ("criticality", "Criticality"), ("gaps", "Gaps")],
    "dms_tasks": [("name", "Name"), ("system", "System"), ("migration_type", "Migration type"), ("status", "Status"),
                  ("target_engine", "Target engine"), ("source_tables", "Source tables"),
                  ("raw_locations", "Raw locations"), ("owner", "Owner"), ("gaps", "Gaps")],
    "lambdas": [("name", "Name"), ("runtime", "Runtime"), ("handler", "Handler"), ("invoked_by", "Invoked by"),
                ("starts", "Starts"), ("triggered_by", "Triggered by"), ("outputs", "Outputs"), ("owner", "Owner"),
                ("gaps", "Gaps")],
    "consumers": [("name", "Name"), ("type", "Type"), ("uses", "Uses"), ("uses_count", "Tables used"),
                  ("owner", "Owner"), ("gaps", "Gaps")],
}

FACETS = {
    "tables": ["layer", "system", "database", "distill_kind", "raw_stage", "subsystem", "product"],
    "glue_jobs": ["command", "family"],
    "state_machines": ["trigger", "sfn_type"],
    "dms_tasks": ["system", "status", "migration_type", "target_engine"],
    "lambdas": ["runtime"],
    "consumers": ["type"],
}

QUICK = {
    "no_lineage": "No lineage",
    "not_orchestrated": "Not orchestrated",
    "has_gaps": "Has gaps",
    "no_ops": "Missing from ops.yaml",
}

NUMERIC = {"columns", "inputs", "outputs", "consumers", "gaps", "config_items", "states", "jobs",
           "tables_written", "source_tables", "raw_locations", "uses_count"}
NOT_SET = "(not set)"


def _family(name):
    for fam, pat in FAMILY_PATTERNS:
        if pat in (name or ""):
            return fam
    return "other"


def _join(items, limit=3):
    items = [i for i in items if i]
    if not items:
        return ""
    return ", ".join(items[:limit]) + (f" +{len(items) - limit}" if len(items) > limit else "")


def _trigger_type(g, attrs):
    tr = attrs.get("triggers")
    if tr is None:
        return "not harvested" if not g.flags.get("triggers_harvested") else "none found"
    kinds = sorted({t.get("kind", "other") for t in tr if isinstance(t, dict)})
    return "+".join(kinds) if kinds else "none found"


def _rows(g, ops, kind):
    cache = g.__dict__.setdefault("_inventory_cache", {})
    if kind in cache:
        return cache[kind]
    ops_data = {k: ops.get(k) for k in ops.keys()} if ops else {}
    rows = []

    def base(k, n):
        o = ops_data.get(k) or {}
        gaps = len(g.gaps_for(k))
        return {"key": k, "name": g.name(k), "owner": o.get("owner", ""), "criticality": o.get("criticality", ""),
                "gaps": gaps, "_in_ops": k in ops_data}

    for k, n in g.nodes.items():
        t, a = n["type"], n["attrs"]
        if kind == "tables" and t == "table":
            aws = a.get("aws") or {}
            ins, outs = g.table_lineage_in(k), g.table_lineage_out(k)
            writers = {e.job for e in ins if e.job} | {e.src for e in g.edges_in(k, "writes")}
            se = a.get("source_equivalent")
            pk = a.get("primary_key")
            lt = g.load_time(k)
            r = {**base(k, n), "layer": n["layer"], "system": n.get("system") or NOT_SET,
                 "database": aws.get("database") or a.get("glue_database") or a.get("database") or NOT_SET,
                 "distill_kind": a.get("distill_kind") or "", "raw_stage": a.get("raw_stage") or "",
                 "raw_zone": a.get("raw_zone") or "", "subsystem": a.get("subsystem") or "",
                 "source_system_db": a.get("source_system_db") or "",
                 "catalogued": "no" if a.get("uncatalogued") else ("yes" if aws else ""),
                 "product": a.get("product") or "", "replication_mode": a.get("replication_mode") or "",
                 "table_type": a.get("table_type") or "",
                 "primary_key": ", ".join(pk) if isinstance(pk, list) else (pk or ""),
                 "source_equivalent": g.name(se) if se else "",
                 "columns": len(g.table_columns.get(k, ())), "inputs": len(ins), "outputs": len(outs),
                 "writers": _join(sorted(g.name(w) for w in writers)),
                 "consumers": len(g.consumers_of(k)), "loaded": lt["at"] if lt else "",
                 "_no_lineage": not ins and not outs, "_not_orchestrated": False}
            rows.append(r)
        elif kind == "glue_jobs" and t == "glue_job":
            orch = g.orchestrators_of(k)
            ins, outs = g.job_inputs(k), g.job_outputs(k)
            r = {**base(k, n), "command": a.get("command_name") or NOT_SET, "family": _family(n["name"]),
                 "run_by": _join([g.name(o) for o in orch], 2), "config_items": len(g.bound_instances(k)),
                 "inputs": len(ins), "outputs": len(outs),
                 "script_location": mask_text(a.get("script_location") or ""),
                 "_no_lineage": not ins and not outs, "_not_orchestrated": not orch}
            rows.append(r)
        elif kind == "state_machines" and t == "pipeline":
            jobs = g.jobs_of(k)
            written = set()
            for j in jobs:
                written |= {o for o, _ in g.job_outputs(j)}
            r = {**base(k, n), "trigger": _trigger_type(g, a), "states": len(g.tasks_of(k)), "jobs": len(jobs),
                 "started_by": _join([g.name(g.pipeline_of(s) or s) for s in g.starters_of(k)], 2),
                 "starts": _join([g.name(c) for c in g.children_of(k)], 2), "tables_written": len(written),
                 "sfn_type": a.get("sfn_type") or "",
                 "_no_lineage": not written, "_not_orchestrated": False}
            if a.get("processes_tables"):
                r["gaps"] += 1
            rows.append(r)
        elif kind == "dms_tasks" and t == "dms_task":
            srcs = [e.dst for e in g.edges_out(k, "reads")]
            raws = [o for o, _ in g.job_outputs(k)]
            systems = sorted({g.nodes.get(s, {}).get("system") for s in srcs if g.nodes.get(s, {}).get("system")})
            r = {**base(k, n), "system": "+".join(systems) or NOT_SET,
                 "migration_type": a.get("migration_type") or "", "status": a.get("status") or "",
                 "target_engine": a.get("target_engine") or ("s3" if raws else NOT_SET), "source_tables": len(srcs),
                 "raw_locations": len(raws), "_no_lineage": not srcs and not raws, "_not_orchestrated": False}
            rows.append(r)
        elif kind == "lambdas" and t == "lambda_function":
            invoked = [g.pipeline_of(e.src) for e in g.edges_in(k, "depends_on", "invokes")]
            starts = [e.dst for e in g.edges_out(k, "depends_on", "starts")]
            trig = [e.dst for e in g.edges_out(k, "depends_on", "triggered_by")]
            outs = g.job_outputs(k)
            r = {**base(k, n), "runtime": a.get("runtime") or NOT_SET, "handler": a.get("handler") or "",
                 "invoked_by": _join([g.name(p) for p in invoked if p], 2), "starts": _join([g.name(s) for s in starts], 2),
                 "triggered_by": _join([g.name(s) for s in trig], 2), "outputs": len(outs),
                 "_no_lineage": not outs and not starts, "_not_orchestrated": not invoked and not trig}
            rows.append(r)
        elif kind == "consumers" and (t in CONSUMER_TYPES or n["layer"] == "consumer"):
            uses = [e.dst for e in g.edges_out(k, "consumes")] + [e.src for e in g.edges_in(k, "derives_from")]
            r = {**base(k, n), "type": t, "uses": _join([g.name(u) for u in uses], 2), "uses_count": len(uses),
                 "_no_lineage": not uses, "_not_orchestrated": False}
            rows.append(r)
    rows.sort(key=lambda r: r["name"].lower())
    cache[kind] = rows
    return rows


def _match(r, filters, q, quick):
    for f, v in filters.items():
        vals = v if isinstance(v, (list, tuple, set)) else [v]
        if vals and str(r.get(f, "")) not in {str(x) for x in vals}:
            return False
    if q:
        nq = norm(q)
        if nq not in norm(r["name"]) and nq not in norm(r["key"]):
            return False
    for flag in quick:
        if flag == "no_lineage" and not r.get("_no_lineage"):
            return False
        if flag == "not_orchestrated" and not r.get("_not_orchestrated"):
            return False
        if flag == "has_gaps" and not r.get("gaps"):
            return False
        if flag == "no_ops" and r.get("_in_ops"):
            return False
    return True


def inventory(g, ops, kind, filters=None, q="", quick=(), sort="name", desc=False, offset=0, limit=100):
    if kind not in KINDS:
        raise ValueError(f"kind must be one of {sorted(KINDS)}")
    filters = {k: v for k, v in (filters or {}).items() if v not in (None, "", [])}
    rows = _rows(g, ops, kind)
    hits = [r for r in rows if _match(r, filters, q, quick)]
    if sort and sort != "name":
        hits.sort(key=lambda r: (r.get(sort) if sort in NUMERIC else str(r.get(sort, "")).lower()) or
                  (0 if sort in NUMERIC else ""), reverse=desc)
    elif desc:
        hits.reverse()
    facets = {}
    for f in FACETS[kind]:
        others = {k: v for k, v in filters.items() if k != f}
        counts = {}
        for r in rows:
            if _match(r, others, q, quick):
                v = r.get(f) or NOT_SET
                counts[v] = counts.get(v, 0) + 1
        facets[f] = [{"value": v, "n": n} for v, n in sorted(counts.items(), key=lambda i: (-i[1], str(i[0])))]
    quick_counts = {flag: sum(1 for r in rows if _match(r, filters, q, [flag])) for flag in QUICK}
    cols = COLUMNS[kind]
    # hide columns that are empty for every row in this kind (for example raw columns when no raw tables)
    present = [c for c in cols if c[0] in ("name",) or any(r.get(c[0]) not in ("", None, NOT_SET) for r in hits)]
    public = lambda r: {k: v for k, v in r.items() if not k.startswith("_")}
    return {"kind": kind, "label": KINDS[kind], "total": len(rows), "matched": len(hits),
            "offset": offset, "limit": limit, "columns": [{"id": c, "label": l, "numeric": c in NUMERIC} for c, l in present],
            "rows": [public(r) for r in hits[offset: offset + limit]], "facets": facets,
            "quick": [{"id": k, "label": v, "n": quick_counts[k]} for k, v in QUICK.items()],
            "filters": filters, "q": q, "sort": sort, "desc": desc, "snapshot": g.snapshot_id}


def summary(g, ops):
    """Counts per kind, for the Inventory tabs."""
    return [{"kind": k, "label": v, "n": len(_rows(g, ops, k))} for k, v in KINDS.items()]


def to_csv(g, ops, kind, filters=None, q="", quick=(), sort="name", desc=False):
    r = inventory(g, ops, kind, filters, q, quick, sort, desc, 0, 10 ** 9)
    buf = io.StringIO()
    cols = [c["id"] for c in r["columns"]]
    w = csv.writer(buf)
    w.writerow(["key"] + [c["label"] for c in r["columns"]])
    for row in r["rows"]:
        w.writerow([row["key"]] + [row.get(c, "") for c in cols])
    return buf.getvalue()
