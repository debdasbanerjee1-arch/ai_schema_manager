"""Deterministic graph queries for the Knowledge Fabric UI. No AWS calls, read-only."""

from __future__ import annotations

import threading
from pathlib import Path

from . import explore, impact, inventory, runbook
from .ops import Ops, draft
from .store import current_graph_file, load

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None


class Fabric:
    """The current graph plus ops.yaml and system aliases. Reloads when CURRENT changes."""

    def __init__(self, data_root, ops_path=None, systems_path=None):
        self.data_root = Path(data_root)
        self.ops = Ops(ops_path)
        self.aliases = self._aliases(systems_path)
        self._lock = threading.Lock()
        self.g = load(self.data_root)
        self._current = current_graph_file(self.data_root)

    @staticmethod
    def _aliases(path):
        if not path or yaml is None or not Path(path).is_file():
            return {}
        data = yaml.safe_load(Path(path).read_text(encoding="utf-8")) or {}
        systems = data.get("systems", data) if isinstance(data, dict) else {}
        out = {}
        if isinstance(systems, dict):
            items = [(name, v) for name, v in systems.items()]
        elif isinstance(systems, list):  # a list of {name: ..., aliases: [...]}
            items = [(v.get("name"), v) for v in systems if isinstance(v, dict) and v.get("name")]
        else:
            items = []
        for name, v in items:
            out[str(name)] = str(name)
            for a in (v or {}).get("aliases", []) if isinstance(v, dict) else []:
                out[str(a)] = str(name)
        return out

    def refresh(self):
        """Load a new graph if CURRENT points somewhere else. Returns True if it changed."""
        try:
            cur = current_graph_file(self.data_root)
        except OSError:
            return False
        if cur == self._current:
            return False
        g = load(self.data_root)
        with self._lock:
            self.g, self._current = g, cur
        return True

    # queries
    def meta(self): return explore.meta(self.g, self.ops)
    def search(self, q, **kw): return explore.search(self.g, q, aliases=self.aliases, **kw)
    def detail(self, key): return explore.detail(self.g, self.ops, key)
    def lineage(self, key, **kw): return explore.lineage(self.g, key, **kw)
    def flow(self, key): return explore.flow(self.g, key, self.ops)
    def config_tables(self): return explore.config_tables(self.g)
    def config_deps(self, table, q=""): return explore.config_deps(self.g, table, q)
    def terms(self, q): return explore.terms(self.g, q)
    def health(self): return explore.health(self.g, self.ops)
    def inventory_summary(self): return inventory.summary(self.g, self.ops)
    def inventory(self, kind, **kw): return inventory.inventory(self.g, self.ops, kind, **kw)
    def inventory_csv(self, kind, **kw): return inventory.to_csv(self.g, self.ops, kind, **kw)
    def failure(self, key, config_key=None): return impact.failure(self.g, self.ops, key, config_key)
    def stale(self, key): return impact.stale(self.g, self.ops, key)
    def column_change(self, key): return impact.column_change(self.g, self.ops, key)

    def runbook(self, mode, key, config_key=None):
        r = {"failure": lambda: self.failure(key, config_key), "stale": lambda: self.stale(key),
             "column": lambda: self.column_change(key)}[mode]()
        return runbook.to_markdown(r)

    def ops_draft(self):
        return draft(self.g, set(self.ops.keys()), explore.consumer_count(self.g))
