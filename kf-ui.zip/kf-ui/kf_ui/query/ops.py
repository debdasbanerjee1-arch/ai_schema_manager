"""config/ops.yaml: owner, criticality and rerun safety, maintained by prod support.

Read directly (not part of the graph), reloaded when the file changes.
"""

from __future__ import annotations

from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

FIELDS = ("owner", "criticality", "rerun_safe", "rerun_note", "runbook_url", "notes")
ALLOWED = {"criticality": {"high", "medium", "low"}, "rerun_safe": {"yes", "no", "conditional"}}
NOT_RECORDED = "not recorded: add to ops.yaml"


class Ops:
    def __init__(self, path=None):
        self.path = Path(path) if path else None
        self._mtime = None
        self._data = {}
        self.error = None

    def _refresh(self):
        if not self.path or not self.path.is_file():
            self._data, self._mtime = {}, None
            return
        m = self.path.stat().st_mtime
        if m == self._mtime:
            return
        if yaml is None:
            self.error = "PyYAML is not installed, so ops.yaml can't be read"
            return
        try:
            data = yaml.safe_load(self.path.read_text(encoding="utf-8")) or {}
            self._data = {str(k): (v or {}) for k, v in data.items()} if isinstance(data, dict) else {}
            self.error = None
        except Exception as exc:  # report, never crash the service
            self.error = f"ops.yaml could not be read: {exc}"
            self._data = {}
        self._mtime = m

    def get(self, key):
        self._refresh()
        e = self._data.get(key)
        if not e:
            return None
        out = {}
        for f in FIELDS:
            v = e.get(f)
            if isinstance(v, bool):  # YAML turns yes/no into booleans
                v = "yes" if v else "no"
            if v not in (None, ""):
                out[f] = str(v)
        return out or None

    def tags(self, key):
        e = self.get(key)
        if not e:
            return [NOT_RECORDED]
        t = []
        if "rerun_safe" in e:
            t.append("Rerun safe: " + e["rerun_safe"] + (f" ({e['rerun_note']})" if e.get("rerun_note") else ""))
        if "owner" in e:
            t.append("Owner: " + e["owner"])
        if "criticality" in e:
            t.append("Criticality: " + e["criticality"])
        return t or [NOT_RECORDED]

    def keys(self):
        self._refresh()
        return list(self._data)

    def validate(self, graph):
        """Problems: keys not in the graph, and values outside the allowed sets."""
        self._refresh()
        problems = []
        if self.error:
            problems.append({"key": None, "problem": self.error})
        for k, e in self._data.items():
            if k not in graph.nodes:
                problems.append({"key": k, "problem": "not in the current graph"})
            if not isinstance(e, dict):
                problems.append({"key": k, "problem": "entry is not a mapping"})
                continue
            for f, allowed in ALLOWED.items():
                v = e.get(f)
                if isinstance(v, bool):
                    v = "yes" if v else "no"
                if v not in (None, "") and str(v) not in allowed:
                    problems.append({"key": k, "problem": f"{f} must be one of {sorted(allowed)}, not {v!r}"})
            for f in e:
                if f not in FIELDS:
                    problems.append({"key": k, "problem": f"unknown field {f!r}"})
        return problems


def draft(graph, existing_keys, consumer_count):
    """YAML text with a blank entry for every orchestrator, job and consumer not yet in ops.yaml,
    most consumers downstream first. Never includes existing entries."""
    types = {"pipeline", "glue_job", "lambda_function", "dms_task", "dashboard", "api_endpoint", "extract"}
    keys = [k for k, n in graph.nodes.items() if n["type"] in types and k not in existing_keys]
    keys.sort(key=lambda k: (-consumer_count(k), k))
    lines = ["# New entries drafted by kf_ui. Fill in the values; leave a field out if unknown.",
             "# criticality: high | medium | low     rerun_safe: yes | no | conditional", ""]
    for k in keys:
        lines += [f"{k}:", "  owner: ", "  criticality: ", "  rerun_safe: ", "  rerun_note: ", ""]
    return "\n".join(lines)
