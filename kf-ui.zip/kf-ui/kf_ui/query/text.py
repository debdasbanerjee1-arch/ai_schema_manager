"""Text matching helpers: normalisation, stems, question-word removal."""

import re

STOP = {"the", "a", "an", "of", "to", "for", "and", "or", "in", "on", "is", "are", "which", "where", "what",
        "who", "how", "table", "tables", "column", "columns", "holds", "hold", "get", "can", "i", "we", "my",
        "applied", "details", "detail", "data", "find", "show", "me", "does", "do", "there", "any", "with"}


def norm(s):
    return re.sub(r"[\s_\-./:]+", "", (s or "").lower())


def stem(w):
    for suf in ("ies", "es", "s"):
        if len(w) > 4 and w.endswith(suf):
            return w[: -len(suf)] + ("y" if suf == "ies" else "")
    return w


def stems(q):
    words = re.split(r"[^a-z0-9]+", (q or "").lower())
    return [stem(w) for w in words if len(w) > 2 and w not in STOP]


def words_of(name):
    return [stem(w) for w in re.split(r"[^a-z0-9]+", (name or "").lower()) if w]


def match_score(query, name, key=""):
    """Score how well a search query matches a name. 0 means no match."""
    q, n = norm(query), norm(name)
    if not q:
        return 0
    if q == n:
        return 100
    if n.startswith(q):
        return 80
    if q in n:
        return 60
    if q in norm(key):
        return 40
    st = stems(query)
    if st:
        w = words_of(name)
        hit = sum(1 for s in st if any(x.startswith(s) for x in w))
        if hit == len(st):
            return 30 + hit
    return 0
