"""Hide sensitive-looking values before anything is shown.

A second line of defence: the inventory and graph should already be redacted.
- Attribute values whose names look sensitive (host, port, user, pswd, password, secret,
  token, credential, api key, private key) become [hidden].
- 12-digit AWS account IDs inside any text are masked, unless the environment variable
  KF_UI_SHOW_ACCOUNT_IDS=1 is set.
"""

import os
import re

SENSITIVE = re.compile(r"(^|_)(host|hostname|server|port|user|username|user_name|username_key|pswd|pswd_key|pwd|"
                       r"password|passwd|secret|token|credential|credentials|apikey|api_key|private_?key)(_|$)",
                       re.IGNORECASE)
ACCOUNT = re.compile(r"(?<!\d)\d{12}(?!\d)")
MASK = "[hidden]"
ACCOUNT_MASK = "<account>"


def mask_text(s):
    if not isinstance(s, str) or os.environ.get("KF_UI_SHOW_ACCOUNT_IDS") == "1":
        return s
    return ACCOUNT.sub(ACCOUNT_MASK, s)


def redact(value, key=None):
    if key is not None and SENSITIVE.search(str(key)):
        return MASK
    if isinstance(value, dict):
        return {k: redact(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(v) for v in value]
    return mask_text(value)
