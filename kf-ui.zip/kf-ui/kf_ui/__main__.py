"""Command line.

  python -m kf_ui serve --data-root <folder> [--ops ops.yaml] [--systems source_systems.yaml] [--port 8765]
  python -m kf_ui make-sample --out <folder> [--variant full|today]
  python -m kf_ui ask --data-root <folder> failure|stale|column|flow|config|terms|search|detail <key or text>
  python -m kf_ui runbook --data-root <folder> failure|stale|column <key>
  python -m kf_ui inventory --data-root <folder> <kind> [--filter field=value ...] [--quick no_lineage] [--q text] [--csv out.csv]
       kinds: tables, glue_jobs, state_machines, dms_tasks, lambdas, consumers
  python -m kf_ui ops-draft --data-root <folder> --ops <ops.yaml>     (prints new entries; never writes the file)
  python -m kf_ui ops-validate --data-root <folder> --ops <ops.yaml>
"""

import argparse
import json
import sys
from pathlib import Path


def _fabric(a):
    from .query import Fabric
    ops = a.ops or (Path(a.data_root) / "config" / "ops.yaml")
    systems = a.systems or (Path(a.data_root) / "config" / "source_systems.yaml")
    return Fabric(a.data_root, ops, systems)


def main(argv=None):
    p = argparse.ArgumentParser(prog="python -m kf_ui")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("make-sample")
    s.add_argument("--out", required=True)
    s.add_argument("--variant", choices=["full", "today"], default="full")
    for name in ("ask", "runbook", "ops-draft", "ops-validate", "inventory", "serve"):
        x = sub.add_parser(name)
        x.add_argument("--data-root", required=True)
        x.add_argument("--ops", help="path to ops.yaml (default <data-root>/config/ops.yaml)")
        x.add_argument("--systems", help="path to source_systems.yaml for aliases")
        if name == "serve":
            x.add_argument("--port", type=int, default=8765)
            x.add_argument("--host", default="127.0.0.1", help="keep 127.0.0.1 unless the service is put behind sign-in")
        if name == "inventory":
            x.add_argument("kind")
            x.add_argument("--filter", action="append", default=[], help="field=value, repeatable")
            x.add_argument("--quick", action="append", default=[], help="no_lineage, not_orchestrated, has_gaps, no_ops")
            x.add_argument("--q", default="")
            x.add_argument("--sort", default="name")
            x.add_argument("--desc", action="store_true")
            x.add_argument("--limit", type=int, default=50)
            x.add_argument("--csv", help="write all matching rows to this CSV file")
        if name in ("ask", "runbook"):
            x.add_argument("what")
            x.add_argument("key")
            x.add_argument("--config-key")
    a = p.parse_args(argv)

    if a.cmd == "make-sample":
        from .sample.build_sample import build
        out = build(a.out, a.variant)
        print(f"Sample graph ({a.variant}) written under {out}")
        return 0
    if a.cmd == "serve":
        from .api.app import serve
        ops = a.ops or (Path(a.data_root) / "config" / "ops.yaml")
        systems = a.systems or (Path(a.data_root) / "config" / "source_systems.yaml")
        serve(a.data_root, ops, systems, a.host, a.port)
        return 0
    f = _fabric(a)
    if a.cmd == "ask":
        fn = {"failure": lambda: f.failure(a.key, a.config_key), "stale": lambda: f.stale(a.key),
              "column": lambda: f.column_change(a.key), "flow": lambda: f.flow(a.key),
              "config": lambda: f.config_deps(a.key), "terms": lambda: f.terms(a.key),
              "search": lambda: f.search(a.key), "detail": lambda: f.detail(a.key),
              "lineage": lambda: f.lineage(a.key)}[a.what]
        print(json.dumps(fn(), indent=1, default=str))
    elif a.cmd == "runbook":
        print(f.runbook(a.what, a.key, a.config_key))
    elif a.cmd == "inventory":
        filters = {}
        for item in a.filter:
            k, _, v = item.partition("=")
            filters.setdefault(k, []).append(v)
        kw = dict(filters=filters, q=a.q, quick=a.quick, sort=a.sort, desc=a.desc)
        if a.csv:
            Path(a.csv).write_text(f.inventory_csv(a.kind, **kw), encoding="utf-8")
            print(f"Wrote {a.csv}")
        r = f.inventory(a.kind, limit=a.limit, **kw)
        print(f"{r['label']}: {r['matched']} of {r['total']}")
        for fname, vals in r["facets"].items():
            print(f"  {fname}: " + ", ".join(f"{v['value']} ({v['n']})" for v in vals[:8]))
        print("  quick: " + ", ".join(f"{q['label']} ({q['n']})" for q in r["quick"]))
        cols = [c["id"] for c in r["columns"]]
        print(" | ".join(cols))
        for row in r["rows"]:
            print(" | ".join(str(row.get(c, "")) for c in cols))
    elif a.cmd == "ops-draft":
        print(f.ops_draft())
    elif a.cmd == "ops-validate":
        problems = f.ops.validate(f.g)
        for x in problems:
            print(f"{x['key']}: {x['problem']}")
        print(f"{len(problems)} problem(s)")
        return 1 if problems else 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
