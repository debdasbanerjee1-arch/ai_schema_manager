"""Browser smoke test: every screen loads with no JavaScript errors.

Skipped unless Python Playwright and its Chromium are installed
(pip install playwright; python -m playwright install chromium).
"""

import socket
import threading
import time
import urllib.parse as u

import pytest

pw = pytest.importorskip("playwright.sync_api")
uvicorn = pytest.importorskip("uvicorn")

from kf_ui.api.app import create_app  # noqa: E402
from kf_ui.query import Fabric  # noqa: E402
from kf_ui.sample.build_sample import build  # noqa: E402

R2D = "aws.glue_job.auk-prd-cdp-raw2dis-arc1-hudi-load-batch"
DIS = "glue.auk_prd_cdp_dis_db.arc1_composer_dbo_address"
SCREENS = ["#/", "#/inventory?kind=tables", "#/inventory?kind=glue_jobs", "#/detail?key=" + u.quote(R2D),
           "#/detail?key=" + u.quote(DIS), "#/lineage?key=" + u.quote(DIS), "#/flow?key=" + u.quote(DIS),
           "#/impact?mode=failure&key=" + u.quote(R2D), "#/impact?mode=stale&key=" + u.quote(DIS),
           "#/impact?mode=column&key=" + u.quote(DIS + ".postcode"), "#/discover?tab=config",
           "#/discover?tab=terms&q=contribution", "#/health", "#/search?q=address"]


@pytest.fixture(scope="module")
def base(tmp_path_factory):
    root = build(tmp_path_factory.mktemp("ui"), "full")
    app = create_app(Fabric(root, root / "config" / "ops.yaml"))
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error"))
    t = threading.Thread(target=server.run, daemon=True)
    t.start()
    for _ in range(50):
        if server.started:
            break
        time.sleep(0.1)
    yield f"http://127.0.0.1:{port}/"
    server.should_exit = True


def test_screens_have_no_errors(base):
    with pw.sync_playwright() as p:
        try:
            browser = p.chromium.launch()
        except Exception as exc:  # browser not downloaded
            pytest.skip(f"Chromium not available: {exc}")
        page = browser.new_page()
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
        for h in SCREENS:
            page.goto(base + h)
            page.wait_for_load_state("networkidle")
            assert page.inner_text("main").strip(), f"empty screen {h}"
        browser.close()
    assert errors == []
