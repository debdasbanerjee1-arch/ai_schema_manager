"""API tests: every endpoint on the synthetic graph, read-only behaviour, static files."""

import pytest

pytest.importorskip("fastapi")
from fastapi.testclient import TestClient  # noqa: E402

from kf_ui.api.app import create_app  # noqa: E402
from kf_ui.query import Fabric  # noqa: E402
from kf_ui.sample.build_sample import build  # noqa: E402

R2D = "aws.glue_job.auk-prd-cdp-raw2dis-arc1-hudi-load-batch"
DIS = "glue.auk_prd_cdp_dis_db.arc1_composer_dbo_address"


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    root = build(tmp_path_factory.mktemp("api"), "full")
    return TestClient(create_app(Fabric(root, root / "config" / "ops.yaml", root / "config" / "source_systems.yaml")))


def test_ui_and_static(client):
    r = client.get("/")
    assert r.status_code == 200 and "/static/js/app.js" in r.text
    for path in ("/static/js/app.js", "/static/css/app.css", "/static/vendor/htm-preact-standalone.module.js"):
        assert client.get(path).status_code == 200


def test_read_only(client):
    for method in ("post", "put", "delete", "patch"):
        assert getattr(client, method)("/api/meta").status_code == 405


@pytest.mark.parametrize("path,params", [
    ("/api/meta", {}),
    ("/api/search", {"q": "address"}),
    ("/api/detail", {"key": R2D}),
    ("/api/lineage", {"key": DIS, "depth": 3}),
    ("/api/flow", {"key": DIS}),
    ("/api/impact/failure", {"key": R2D}),
    ("/api/impact/failure", {"key": R2D, "config_key": "arc1_composer_dbo_contribution"}),
    ("/api/impact/stale", {"key": DIS}),
    ("/api/impact/column", {"key": DIS + ".postcode"}),
    ("/api/config/tables", {}),
    ("/api/config", {"table": "auk-prd-cdp-data-mapping-config-table"}),
    ("/api/terms", {"q": "platform charges"}),
    ("/api/health", {}),
    ("/api/inventory/summary", {}),
    ("/api/inventory", {"kind": "tables", "f.layer": "distill", "quick": "has_gaps"}),
])
def test_endpoints(client, path, params):
    r = client.get(path, params=params)
    assert r.status_code == 200, r.text
    assert r.headers["cache-control"] == "no-store"


def test_inventory_filters_through_api(client):
    r = client.get("/api/inventory", params={"kind": "tables", "f.layer": ["distill", "raw"], "limit": 5}).json()
    assert r["matched"] == 12 and len(r["rows"]) == 5
    csv = client.get("/api/inventory.csv", params={"kind": "tables", "f.layer": "distill"})
    assert csv.status_code == 200 and "attachment" in csv.headers["content-disposition"]
    assert len(csv.text.strip().splitlines()) == 7


def test_runbook_download(client):
    r = client.get("/api/runbook", params={"mode": "failure", "key": R2D, "download": "1"})
    assert r.status_code == 200 and r.text.startswith("# Recovery checklist")
    assert "attachment" in r.headers["content-disposition"]


def test_errors(client):
    assert client.get("/api/detail", params={"key": "nope"}).status_code == 404
    assert client.get("/api/impact/failure", params={"key": DIS}).status_code == 400
    assert client.get("/api/inventory", params={"kind": "nope"}).status_code == 400
    assert client.get("/api/nothing-here").status_code == 404
