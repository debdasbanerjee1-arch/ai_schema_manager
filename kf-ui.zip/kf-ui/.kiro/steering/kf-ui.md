---
inclusion: always
---

# kf-ui: Knowledge Fabric analysis UI

This repository is the analysis UI over the Knowledge Fabric graph. The graph itself is built
by the `catalog_lineage` repository; its steering file `knowledge-fabric.md` is the authority
for keys, edge semantics and production rules. This file covers only the UI.

## Hard rules

- **No AWS calls.** Nothing here imports boto3 or botocore (a test enforces it) or uses the AWS MCP.
- **Read-only.** The graph is opened read-only. The API accepts only GET; anything else returns 405.
  No screen offers to start, stop or rerun anything.
- **Deterministic.** Every answer comes from tested code in `kf_ui/query`. No LLM in this service.
- **Honest about gaps.** When something is not harvested or a path breaks at a gap, say so on
  screen. An empty result always explains why.
- **No secrets on screen.** `kf_ui/query/redact.py` hides sensitive-looking attribute values and
  masks AWS account IDs. Do not weaken it.
- **Real names stay inside the client environment.** Runbooks, CSVs and screenshots contain them.

## Stack (do not change without asking)

- Python 3.11+, DuckDB, FastAPI, uvicorn. No other server dependencies without asking.
- Screens: plain HTML, CSS and ES modules, with Preact and htm from
  `kf_ui/static/vendor/htm-preact-standalone.module.js`. **No build step, no Node.js, no CDN.**
- Routing is in the URL hash (`#/screen?params`), so every view has a shareable link.

## Where things go

| Change | File |
| --- | --- |
| A new question or answer | a function in `kf_ui/query/*.py`, then an endpoint in `kf_ui/api/app.py` |
| A screen | `kf_ui/static/js/screens/<screen>.js`, registered in `js/app.js` |
| Shared UI piece | `kf_ui/static/js/lib/ui.js` |
| Colours, fonts, spacing | `kf_ui/static/css/tokens.css` (keep the dark-mode block in step) |
| Layout styles | `kf_ui/static/css/app.css` |
| Where load times are read from | `LOAD_TIME_PATHS` in `kf_ui/query/store.py` |
| Glue job families | `FAMILY_PATTERNS` in `kf_ui/query/inventory.py` |

## How answers are computed (keep these)

- Data paths follow table-level `derives_from` edges, never job to job through reads and
  writes, so a job that loads many tables does not fan out.
- A branch is a `config_key`. A job's state machine comes from the invoking state (climbing
  `contains`) or the edges' `via_state_machine`.
- Hand-offs: Enforced, Event, Schedule only, Not harvested, No trigger found (see `impact.handoff`).
- The runbook export and the screen are built from the same result.

## Templates

- Use `html\`...\``; never build HTML strings or use `dangerouslySetInnerHTML`.
- Every input has a label; buttons are `<button>`; links are `<a href>`.

## Tests

- `python -m pytest -q kf_ui/tests` before every change is handed over. Add a test with every
  query or endpoint change; tests use the synthetic graphs in `kf_ui/sample`, never real data.
- `test_ui_smoke.py` runs only where Playwright and Chromium are installed; it is skipped otherwise.

## How to work

- Show a plan before changing existing code, and wait for approval.
- Keep changes small and show the result: a test run, and for screens a description of what changed.
