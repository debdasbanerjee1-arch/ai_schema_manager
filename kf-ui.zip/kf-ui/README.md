# Knowledge Fabric UI

The analysis screens for the Knowledge Fabric graph: inventory of every component, lineage,
end-to-end flow with hand-offs, impact of a failure with a recovery checklist, stale tables,
column changes, config dependencies, business-term search, component detail and health.

Three parts, in one Python package:

1. **Query library** (`kf_ui/query`): deterministic graph logic, no web code.
2. **Read-only API** (`kf_ui/api`): FastAPI, GET only; it also serves the screens.
3. **Screens** (`kf_ui/static`): plain HTML, CSS and JavaScript modules with Preact and htm.
   There is no build step and no Node.js: edit a file, refresh the browser.

## Run it

```powershell
cd C:\kf-ui
C:\path\to\catalog_lineage\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m kf_ui serve --data-root C:\knowledge-fabric-data --ops C:\path\to\catalog_lineage\config\ops.yaml --systems C:\path\to\catalog_lineage\config\source_systems.yaml
```

Open http://127.0.0.1:8765. The service listens only on this machine. It checks
`CURRENT` every minute and switches to a new graph without a restart; `ops.yaml` edits
show on the next request. API documentation is at http://127.0.0.1:8765/api/docs.

Screens: Home, Inventory, Lineage, Flow, Impact and recovery, Discover, Health, plus a
detail page for every component and a search page. Every screen's address can be pasted
into a ticket or a chat and opens the same view.

**Safety.** It reads only the graph named in `<data root>\graph\CURRENT` (opened
read-only), the gaps files of that snapshot, `ops.yaml` and `source_systems.yaml`. It makes
no AWS calls (a test fails if any module imports an AWS SDK) and writes nothing. Attribute
values whose names look sensitive (host, port, user, pswd, password, secret, token, key
names like `username_key`) are shown as `[hidden]`, and 12-digit AWS account IDs inside any
text are shown as `<account>` (set `KF_UI_SHOW_ACCOUNT_IDS=1` to show them).

It changes nothing in the Knowledge Fabric repository.

## Command line (no browser needed)

```powershell
git clone <your GitHub repo> C:\kf-ui
cd C:\kf-ui
# use the Knowledge Fabric virtual environment, which already has duckdb
C:\path\to\catalog_lineage\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m pytest -q kf_ui\tests
```

## Try it on the real graph

Replace the paths with yours. `--ops` and `--systems` are optional.

```powershell
$KF = "C:\knowledge-fabric-data"
$CFG = "C:\path\to\catalog_lineage\config"

# a job failed: what is affected, and the recovery checklist
python -m kf_ui runbook --data-root $KF --ops $CFG\ops.yaml --systems $CFG\source_systems.yaml failure aws.glue_job.<job name>

# one branch only (one config item)
python -m kf_ui runbook --data-root $KF failure aws.glue_job.<job name> --config-key <config key>

# a table is stale
python -m kf_ui runbook --data-root $KF stale glue.<database>.<table>

# a column is changing
python -m kf_ui runbook --data-root $KF column glue.<database>.<table>.<column>

# inventory: tables, glue_jobs, state_machines, dms_tasks, lambdas, consumers
python -m kf_ui inventory --data-root $KF tables --filter layer=published
python -m kf_ui inventory --data-root $KF glue_jobs --quick not_orchestrated
python -m kf_ui inventory --data-root $KF state_machines --sort tables_written --desc
python -m kf_ui inventory --data-root $KF tables --filter layer=distill --filter distill_kind=domain --csv domain-tables.csv
#   quick filters: no_lineage, not_orchestrated, has_gaps, no_ops (missing from ops.yaml)

# JSON answers: search, detail, lineage, flow, config, terms
python -m kf_ui ask --data-root $KF search adviser_address
python -m kf_ui ask --data-root $KF config auk-prd-cdp-data-mapping-config-table
python -m kf_ui ask --data-root $KF terms "Which table holds contribution details?"
python -m kf_ui ask --data-root $KF flow glue.<database>.<table>

# ops.yaml: draft blank entries (printed, never written), and validate
python -m kf_ui ops-draft --data-root $KF --ops $CFG\ops.yaml > ops-draft.yaml
python -m kf_ui ops-validate --data-root $KF --ops $CFG\ops.yaml
```

The runbook and JSON output contain real names: keep them inside the client environment.

## Try it on the sample graphs

```powershell
python -m kf_ui make-sample --out C:\kf-ui-sample\full --variant full
python -m kf_ui make-sample --out C:\kf-ui-sample\today --variant today
python -m kf_ui runbook --data-root C:\kf-ui-sample\full failure aws.glue_job.auk-prd-cdp-raw2dis-arc1-hudi-load-batch
```

- `today` has what the real graph holds now: Source, Raw, Distill, domain tables labelled
  Distill, orchestration, config keys, column lineage Raw to Distill. No triggers,
  consumers, terms or load times.
- `full` adds what the planned resolver fixes will produce: domain tables in Published,
  Published views, external targets and dashboards as consumers, triggers, load times and
  business terms.

Names follow the real estate's patterns; the data is invented.

## Inventory

One list per kind, with no row cap. Each kind has its own columns and filters; columns
that are empty for every matching row are hidden (so Raw columns appear only for Raw tables).

| Kind | Inventory columns | Graph columns |
| --- | --- | --- |
| tables | layer, system, database, distill kind, raw stage and zone, subsystem, source database, catalogued, product, replication, table type, primary key, source equivalent | columns, inputs, outputs, written by, consumers, last loaded, owner, gaps |
| glue_jobs | command, family (from the name: raw2dis, generic_extract, other), script location | run by, config items, inputs, outputs, owner, criticality, gaps |
| state_machines | type, trigger | states, jobs, started by, starts, tables written, owner, gaps |
| dms_tasks | migration type, status, target engine | system (from its source tables), source tables, Raw locations |
| lambdas | runtime, handler | invoked by, starts, triggered by, outputs |
| consumers | type | uses |

Every filter value comes with its count, computed with the other filters applied. Job
families are set in `FAMILY_PATTERNS` in `kf_ui/query/inventory.py`; align them with
`job_families` in `config/harvest.yaml`.

## How answers are computed

- Data paths follow table-level `derives_from` edges, one input-output pair each, never job
  to job, so a job that loads many tables does not fan out. A job's outputs are its
  `derives_from` edges (`job_key`) plus its `writes`.
- A branch is a `config_key`. Picking a job and a config key limits the answer to that branch.
- A job's state machine comes from the invoking state (climbing `contains`) or the edges'
  `via_state_machine`.
- Hand-offs between state machines: **Enforced** (same state machine, or started by it),
  **Event** (triggered by the data or an event naming the writer), **Schedule only**,
  **Not harvested** (no triggers in the snapshot) or **No trigger found**.
- Load times are read from table attributes, in this order: `last_loaded.at`,
  `dms_last_update_time`, `last_update_time`, `bookmark_timestamp`, `last_job_start_time`
  (`LOAD_TIME_PATHS` in `kf_ui/query/store.py`). Adjust once the resolver stores them.
- Gaps of the snapshot are shown where they break a path. Anything not harvested is said
  plainly rather than shown as nothing.

## Layout

```
kf_ui/
  api/        app.py (read-only FastAPI service; serves static/)
  static/     index.html; css/tokens.css (colours, light and dark), css/app.css;
              js/app.js (shell and routes); js/lib/ (api, router, shared components);
              js/screens/ (one file per screen); vendor/ (Preact + htm, one file, no CDN)
  query/      store.py (load), inventory.py (browse by kind), impact.py (failure, stale, column, hand-offs), explore.py
              (search, detail, lineage, flow, config, terms, health), ops.py, runbook.py,
              redact.py, text.py
  sample/     build_sample.py (synthetic graphs in the real DDL)
  tests/      test_query.py, test_api.py, test_ui_smoke.py (runs only if Playwright is installed)
  __main__.py command line
```

## Editing the screens

- One file per screen in `kf_ui/static/js/screens/`. Shared pieces (search picker, badges,
  checklist, groups) are in `js/lib/ui.js`.
- Templates use htm: `html\`<div class="card">${value}</div>\``. Text is escaped
  automatically. Never use `dangerouslySetInnerHTML`: names come from the estate.
- All colours are tokens in `css/tokens.css`; light and dark follow the system setting.
- The screens call only `/api/...`. Add a new answer by adding a function in `kf_ui/query`,
  an endpoint in `kf_ui/api/app.py` and a test, then the screen.
- Refresh the browser after editing; restart `serve` only after Python changes.
