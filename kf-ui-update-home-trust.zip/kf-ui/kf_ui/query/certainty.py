"""How certain an answer is, in plain words.

Every edge, term and attribute maps to one of five labels:
  harvested   read directly from AWS (catalogue, DMS, config tables, state machine definitions) or from job code
  documented  taken from the data dictionary, Confluence or a declared file kept by people
  inferred    matched by a rule such as a naming convention or a name match; plausible, not proven
  drafted     written by an LLM and not yet reviewed
  gap         could not be resolved; shown, never guessed
Adjust the origin lists here if the resolver adds new origins.
"""

HARVESTED = {"glue_catalog", "dms_mapping", "dynamodb_config", "sfn_definition", "parsed", "parsed_partial",
             "hudi_keys", "connector", "code", "lambda_config", "events", "glue_triggers", "s3_notification"}
DOCUMENTED = {"declared", "dictionary", "dictionary_fk", "confluence", "manual", "ops"}
INFERRED = {"naming_convention", "name_match", "heuristic", "inferred", "derived_name"}
# methods that are evidence-based even when the origin alone would read as inferred
PROVEN_METHODS = {"dms+merge", "dms", "bookmark", "binding"}
DRAFTED = {"llm_draft", "llm"}

LABELS = {"harvested": "Harvested", "documented": "Documented", "inferred": "Inferred", "drafted": "Drafted", "gap": "Gap"}
MEANING = {
    "harvested": "Read directly from AWS or from job code.",
    "documented": "Taken from the data dictionary, Confluence or a file kept by people.",
    "inferred": "Matched by a rule such as a naming convention. Plausible, not proven.",
    "drafted": "Written by an LLM and not yet reviewed.",
    "gap": "Could not be resolved. Shown, never guessed.",
}


def certainty(origin=None, tier=None, method=None):
    o = (origin or "").lower()
    t = (tier or "").lower()
    m = (method or "").lower()
    if m in PROVEN_METHODS:
        cid = "harvested"
        return {"id": cid, "label": LABELS[cid]}
    if o in DRAFTED or (t == "proposed" and o not in HARVESTED | DOCUMENTED):
        cid = "drafted"
    elif m in INFERRED or o in INFERRED or t == "inferred":
        cid = "inferred"
    elif o in DOCUMENTED:
        cid = "documented"
    elif o in HARVESTED or t in ("certified", "observed"):
        cid = "harvested"
    elif o:
        cid = "inferred"
    else:
        cid = "gap"
    return {"id": cid, "label": LABELS[cid]}


def of_edge(e):
    return certainty(e.origin, e.tier, e.attrs.get("method"))


def legend():
    return [{"id": k, "label": LABELS[k], "meaning": MEANING[k]} for k in LABELS]
