import { html, render, useEffect, useState } from "./lib/preact.js";
import { get } from "./lib/api.js";
import { go, href, useRoute } from "./lib/router.js";
import { Picker } from "./lib/ui.js";
import { Home } from "./screens/home.js";
import { Inventory } from "./screens/inventory.js";
import { Detail } from "./screens/detail.js";
import { Lineage } from "./screens/lineage.js";
import { Flow } from "./screens/flow.js";
import { Impact } from "./screens/impact.js";
import { Discover } from "./screens/discover.js";
import { Health } from "./screens/health.js";
import { Search } from "./screens/search.js";

const NAV = [["home", "Home"], ["inventory", "Inventory"], ["lineage", "Lineage"], ["flow", "Flow"],
  ["impact", "Impact and recovery"], ["discover", "Discover"], ["health", "Health"]];
const SCREENS = { home: Home, inventory: Inventory, detail: Detail, lineage: Lineage, flow: Flow, impact: Impact,
  discover: Discover, health: Health, search: Search };

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
// 20261013T105815Z -> 13 Oct 2026
const snapDate = (id) => /^\d{8}T/.test(id) ? `${+id.slice(6, 8)} ${MONTHS[+id.slice(4, 6) - 1]} ${id.slice(0, 4)}` : id;
// Age of the data itself: from the snapshot time, not from when the graph file was written.
const snapAge = (id, built) => {
  const t = /^\d{8}T\d{6}Z$/.test(id) ? Date.UTC(+id.slice(0, 4), +id.slice(4, 6) - 1, +id.slice(6, 8), +id.slice(9, 11), +id.slice(11, 13)) : Date.parse(built);
  return Math.max(0, Math.floor((Date.now() - t) / 864e5));
};
const OLD_DAYS = 7;

const Logo = () => html`<svg width="24" height="24" viewBox="0 0 26 26" aria-hidden="true"><circle cx="6" cy="13" r="3.5" fill="none" stroke="currentColor" stroke-width="2"></circle>
  <circle cx="20" cy="6" r="3.5" fill="none" stroke="currentColor" stroke-width="2"></circle><circle cx="20" cy="20" r="3.5" fill="none" stroke="currentColor" stroke-width="2"></circle>
  <path d="M9.3 11.5 16.7 7.5M9.3 14.5l7.4 4" stroke="currentColor" stroke-width="2"></path></svg>`;

// Shown when a screen was opened from the Ask box, so the reader can see how the question was read.
function Asked({ params }) {
  const asked = params.get("asked");
  if (!asked) return null;
  return html`<div class="asked noprint" role="status">
    <span>You asked <b>“${asked}”</b>. Read as ${params.get("read") || "a search"}.</span>
    <a href=${href("search", { q: asked })}>Not what you meant? Search instead</a>
    <a href=${href("discover", { tab: "terms", q: asked })}>Or search business terms</a>
  </div>`;
}

function Shell() {
  const route = useRoute();
  const [meta, setMeta] = useState(null);
  const [err, setErr] = useState(null);
  useEffect(() => { get("/api/meta").then(setMeta, setErr); }, [route.screen]);
  const Screen = SCREENS[route.screen] || Home;
  const age = meta ? snapAge(meta.snapshot, meta.built_at) : 0;
  return html`
    <header class="top"><div class="top-inner">
      <a class="brand" href=${href("home")} style="color:var(--accent)"><${Logo} /><span style="color:var(--ink)">Knowledge Fabric</span></a>
      <nav class="nav" aria-label="Main">${NAV.map(([k, label]) => html`
        <a href=${href(k)} class=${route.screen === k ? "on" : ""} aria-current=${route.screen === k ? "page" : null}>${label}</a>`)}
      </nav>
      ${meta ? html`<span class="row small muted" style="gap:6px" title=${"Snapshot " + meta.snapshot + ", graph " + meta.graph_file + ", built " + meta.built_at}>
        Data as of ${snapDate(meta.snapshot)}
        <span class=${"snap" + (age > OLD_DAYS ? " old" : "")}>${age === 0 ? "today" : age === 1 ? "1 day old" : `${age} days old`}</span></span>` : null}
      <div class="top-search" onKeyDown=${(e) => { if (e.key === "Enter" && e.target.value && !e.defaultPrevented) go("search", { q: e.target.value }); }}>
        <${Picker} id="global-search" placeholder="Search tables, jobs, columns…" onPick=${(r) => go("detail", { key: r.key })} />
      </div>
    </div></header>
    <main id="main">
      ${err ? html`<p class="err">The service could not be reached: ${String(err.message || err)}</p>` : null}
      <${Asked} params=${route.params} />
      <${Screen} params=${route.params} meta=${meta} key=${route.screen} />
    </main>`;
}

const root = document.getElementById("app");
root.textContent = "";
render(html`<${Shell} />`, root);
