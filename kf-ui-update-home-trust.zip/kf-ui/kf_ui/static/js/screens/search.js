import { html } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { patch } from "../lib/router.js";
import { Empty, ErrorBox, Layer, Loading, NodeLink } from "../lib/ui.js";

export function Search({ params }) {
  const q = params.get("q") || "";
  const type = params.get("type");
  const layer = params.get("layer");
  const system = params.get("system");
  const { data, error } = useApi("/api/search", { q, type, layer, system, limit: 200, one_off: true }, q ? [q, type, layer, system].join("|") : null);
  if (!q) return html`<${Empty}>Type in the search box at the top.</${Empty}>`;
  if (error) return html`<${ErrorBox} error=${error} />`;
  if (!data) return html`<${Loading} />`;
  const labels = {};
  data.results.forEach((r) => { labels[r.label] = (labels[r.label] || 0) + 1; });
  return html`
    <h1>Results for “${q}”</h1>
    ${type || layer || system ? html`<div class="row small"><span class="muted">Filtered to</span>
      ${[["type", type], ["layer", layer], ["system", system]].filter(([, v]) => v).map(([k, v]) => html`
        <button class="chip on" onClick=${() => patch({ [k]: null })} title="Remove this filter">${v} ×</button>`)}</div>` : null}
    ${data.alias_system ? html`<p class="note" style="margin:0">“${q}” is another name for ${data.alias_system}.</p>` : null}
    <div class="rows">${data.results.map((r) => html`<div class="rowi"><span class="nm"><${NodeLink} node=${r} /></span>
      ${r.layer && r.layer !== "none" ? html`<${Layer} layer=${r.layer} />` : null}<span class="small">${r.system || ""}</span></div>`)}</div>
    ${data.total > data.results.length ? html`<p class="muted">Showing ${data.results.length} of ${data.total}. Add more of the name to narrow it down.</p>` : null}
    ${!data.results.length ? html`<${Empty}>Nothing matches “${q}”.</${Empty}>` : null}`;
}
