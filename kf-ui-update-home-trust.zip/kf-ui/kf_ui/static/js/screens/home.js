import { html, useState } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { go, href } from "../lib/router.js";
import { route } from "../lib/ask.js";
import { forget, recent } from "../lib/recent.js";
import { CertLegend, Coverage, Loading, Picker } from "../lib/ui.js";

const toHref = (l) => href(l.screen, l.params);

// Task cards grouped by what the reader is doing. Each asks its question in full and has its own button.
const GROUPS = [
  { title: "Something failed or looks wrong", tone: "amber", items: [
    { id: "fail", ask: "A job failed. What is affected, and how do I recover?", types: ["glue_job", "pipeline", "dms_task", "lambda_function"],
      ph: "e.g. a raw2dis job", go: "Show impact", to: (r) => href("impact", { mode: "failure", key: r.key }) },
    { id: "stale", ask: "A table shows stale data. Who writes it, and who reads it?", types: ["table", "extract"],
      ph: "a table, e.g. adviser_address", go: "Trace it", to: (r) => href("impact", { mode: "stale", key: r.key }) },
  ] },
  { title: "I am changing something", tone: "blue", items: [
    { id: "col", ask: "I am adding or changing a column. What is affected?", types: ["column"],
      ph: "a column, e.g. postcode", go: "Show impact", to: (r) => href("impact", { mode: "column", key: r.key }) },
    { id: "cfg", ask: "Which jobs depend on this DynamoDB config?", config: true, go: "Show dependents" },
  ] },
  { title: "I am looking for data", tone: "purple", items: [
    { id: "feeds", ask: "What feeds this table, and what does it feed?", types: ["table", "extract"],
      ph: "e.g. arc1_composer_dbo_address", go: "Show lineage", to: (r) => href("lineage", { key: r.key }) },
    { id: "flow", ask: "How does data reach this table, step by step?", types: ["table", "extract"],
      ph: "e.g. adviser_address", go: "Show flow", to: (r) => href("flow", { key: r.key }) },
    { id: "term", ask: "Which table holds this business term or measure?", term: true,
      ph: "e.g. contribution details, platform charges", go: "Find it" },
  ] },
];

function Task({ t }) {
  const [picked, setPicked] = useState(null);
  const [text, setText] = useState("");
  const [cfg, setCfg] = useState("");
  const [hint, setHint] = useState("");
  const cfgs = useApi("/api/config/tables", {}, t.config ? "cfg" : null);
  const run = (e) => {
    e && e.preventDefault();
    if (t.term) { if (text.trim()) go("discover", { tab: "terms", q: text.trim() }); else setHint("Type a term first."); return; }
    if (t.config) { if (cfg) go("discover", { tab: "config", table: cfg }); else setHint("Choose a config table first."); return; }
    if (picked) location.hash = t.to(picked); else setHint("Pick a name from the suggestions first.");
  };
  return html`<form class="task stack" style="gap:8px" onSubmit=${run}>
    <label for=${"home-" + t.id}>${t.ask}</label>
    <div class="row" style="flex-wrap:nowrap;align-items:stretch">
      <div class="grow">
        ${t.term ? html`<input id=${"home-" + t.id} class="input" type="search" value=${text} placeholder=${t.ph}
            onInput=${(e) => { setText(e.target.value); setHint(""); }} />`
        : t.config ? html`<select id=${"home-" + t.id} class="select" value=${cfg} onChange=${(e) => { setCfg(e.target.value); setHint(""); }}>
            <option value="">Choose a config table…</option>
            ${(cfgs.data || []).map((c) => html`<option value=${c.name}>${c.name} (${c.items} items)</option>`)}</select>`
        : html`<${Picker} id=${"home-" + t.id} types=${t.types} placeholder=${t.ph} onPick=${(r) => { setPicked(r); setHint(""); }} />`}
      </div>
      <button class="btn" type="submit" style="height:auto;min-height:40px;border-color:var(--accent);color:var(--accent)">${t.go}</button>
    </div>
    ${hint ? html`<span class="small" role="alert" style="color:var(--red-fg)">${hint}</span>` : null}
  </form>`;
}

const EXAMPLES = ["What feeds adviser_address?", "Which table holds contribution details?", "Which jobs depend on generic-extract-mapping-config-table?"];
const TYPES = [["", "Any type"], ["table", "Table"], ["column", "Column"], ["glue_job", "Glue job"], ["pipeline", "State machine"],
  ["dms_task", "DMS task"], ["lambda_function", "Lambda"]];
const LAYERS = [["raw", "Raw"], ["distill", "Distill"], ["published", "Published"]];

function Ask({ meta }) {
  const [q, setQ] = useState("");
  const [sys, setSys] = useState("");
  const [layer, setLayer] = useState("");
  const [type, setType] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const ask = async (text) => {
    if (!text.trim()) return;
    setBusy(true); setErr("");
    try {
      const to = await route(text, { system: sys || undefined, layer: layer || undefined, type: type || undefined });
      if (to) location.hash = to;
    } catch (e) { setErr(String(e.message || e)); } finally { setBusy(false); }
  };
  const systems = meta ? Object.entries(meta.systems).slice(0, 8) : [];
  return html`<section class="hero stack" style="gap:14px" aria-labelledby="h-ask">
    <h1 id="h-ask">What do you need to know?</h1>
    <p class="muted" style="margin:0;max-width:780px;font-size:15px">Ask in plain words, or type the name of a table, column, job, state machine or config table.
      Every answer shows where it came from and how certain it is.</p>
    <form class="row" style="flex-wrap:nowrap" onSubmit=${(e) => { e.preventDefault(); ask(q); }}>
      <label class="sr" for="ask">Ask the Knowledge Fabric</label>
      <input id="ask" class="input big" type="search" autofocus value=${q} onInput=${(e) => setQ(e.target.value)}
        placeholder="e.g. What feeds adviser_address?" />
      <button class="btn primary" type="submit" style="height:46px;padding:0 24px" disabled=${busy}>${busy ? "…" : "Ask"}</button>
    </form>
    ${err ? html`<p class="err" style="margin:0">${err}</p>` : null}
    <div class="row small"><span class="muted">Try</span>${EXAMPLES.map((x) => html`<button class="chip" type="button" onClick=${() => { setQ(x); ask(x); }}>${x}</button>`)}</div>
    <div class="card row" style="gap:18px;align-items:flex-start;padding:14px 16px">
      <div class="stack" style="gap:6px"><span class="small muted">Source system</span>
        <div class="row">${systems.map(([s, n]) => html`<button type="button" class=${"chip" + (sys === s ? " on" : "")} aria-pressed=${sys === s}
          onClick=${() => setSys(sys === s ? "" : s)}>${s} <span class="n">${n}</span></button>`)}</div></div>
      <div class="stack" style="gap:6px"><span class="small muted">Layer</span>
        <div class="row">${LAYERS.map(([v, l]) => html`<button type="button" class=${"chip" + (layer === v ? " on" : "")} aria-pressed=${layer === v}
          onClick=${() => setLayer(layer === v ? "" : v)}>${l}</button>`)}</div></div>
      <div class="stack" style="gap:6px"><label class="small muted" for="ask-type">Type</label>
        <select id="ask-type" class="select" style="width:auto" value=${type} onChange=${(e) => setType(e.target.value)}>
          ${TYPES.map(([v, l]) => html`<option value=${v}>${l}</option>`)}</select></div>
      <span class="small muted" style="align-self:center">Filters apply when you ask for a name.</span>
    </div>
  </section>`;
}

function Recent() {
  const [list, setList] = useState(recent());
  return html`<section class="card stack" style="gap:4px;flex:1 1 380px;min-width:0" aria-labelledby="h-recent">
    <div class="row" style="justify-content:space-between"><h2 id="h-recent">Your recent questions</h2>
      ${list.length ? html`<button class="btn small" onClick=${() => { forget(); setList([]); }}>Clear</button>` : null}</div>
    ${list.length ? list.map((x) => html`<a href=${x.href} style="padding:10px 0;border-top:1px solid var(--border);display:flex;gap:10px;flex-wrap:wrap">
        <span>${x.label}</span><span class="mono muted">${x.sub}</span></a>`)
      : html`<p class="muted" style="margin:0">Questions you ask and components you open appear here, in this browser only.</p>`}
  </section>`;
}

export function Home({ meta }) {
  return html`
    <${Ask} meta=${meta} />
    <section class="stack" style="gap:14px" aria-labelledby="h-start">
      <h2 id="h-start">Start from what you are doing</h2>
      <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(min(100%,360px),1fr));align-items:start">
        ${GROUPS.map((g) => html`<section class="card intent" style=${`--tone-bg:var(--${g.tone}-bg);--tone-fg:var(--${g.tone}-fg)`}>
          <h3>${g.title}</h3>${g.items.map((t) => html`<${Task} t=${t} />`)}</section>`)}
      </div>
    </section>
    <div class="row" style="gap:18px;align-items:flex-start">
      <${Recent} />
      <section class="card stack" style="flex:1 1 380px;min-width:0" aria-labelledby="h-cert"><h2 id="h-cert">How certain is an answer?</h2><${CertLegend} /></section>
    </div>
    ${!meta ? html`<${Loading} />` : html`<div class="row" style="gap:18px;align-items:flex-start">
      <section class="card stack" style="flex:1 1 420px;min-width:0" aria-labelledby="h-knows">
        <div class="row" style="justify-content:space-between"><h2 id="h-knows">What the fabric knows</h2><a href=${href("inventory", { kind: "tables" })}>Browse the inventory</a></div>
        <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(96px,1fr))">${[
          ["tables", "Tables", "tables"], ["columns", "Columns", "tables"], ["glue_jobs", "Glue jobs", "glue_jobs"],
          ["state_machines", "State machines", "state_machines"], ["dms_tasks", "DMS tasks", "dms_tasks"], ["lambdas", "Lambda functions", "lambdas"]]
          .map(([k, l, kind]) => html`<a class="stat" href=${href("inventory", { kind })} style="color:var(--ink)"><b>${meta.counts[k].toLocaleString()}</b><span>${l}</span></a>`)}</div>
        <h3 style="margin-top:6px">How complete the map is</h3>
        <${Coverage} items=${meta.coverage} onGo=${toHref} />
      </section>
      <section class="card stack" style="flex:1 1 380px;min-width:0;gap:4px" aria-labelledby="h-gaps">
        <div class="row" style="justify-content:space-between"><h2 id="h-gaps">Where the map is incomplete</h2><a href=${href("health")}>All gaps</a></div>
        <p class="small muted" style="margin:0 0 8px">Open a row to see the items.</p>
        ${meta.gaps.length ? meta.gaps.map((x) => html`<a href=${href("health", { reason: x.reason, rule: x.rule })}
            style="display:flex;justify-content:space-between;gap:16px;padding:10px 0;border-top:1px solid var(--border);color:var(--ink)">
            <span class="stack" style="gap:2px;min-width:0"><span>${x.label}</span><span class="mono muted small">${x.reason}</span></span>
            <b class="nowrap" style="color:var(--amber-fg)">${x.n.toLocaleString()}</b></a>`)
          : html`<p class="muted" style="margin:0">No gaps in this snapshot.</p>`}
      </section>
    </div>`}`;
}
