import { html, useEffect, useState } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { href, patch } from "../lib/router.js";
import { CertLegend, Coverage, ErrorBox, Loading, NodeLink } from "../lib/ui.js";

const toHref = (l) => href(l.screen, l.params);
const PAGE = 100;

function GapItems({ reason, rule, label }) {
  const [q, setQ] = useState("");
  const [offset, setOffset] = useState(0);
  useEffect(() => setOffset(0), [reason, q]);
  const req = { reason, rule, q, offset, limit: PAGE };
  const { data, error } = useApi("/api/gaps", req, JSON.stringify(req));
  return html`<section class="card stack" aria-labelledby="h-items">
    <div class="row" style="justify-content:space-between">
      <div class="stack" style="gap:2px"><h2 id="h-items">${label || (data && data.label) || reason}</h2>
        <span class="mono small muted">${rule ? rule + " · " : ""}${reason}</span></div>
      <div class="row"><label class="sr" for="gap-q">Filter</label>
        <input id="gap-q" class="input" style="width:260px" type="search" placeholder="Filter by name" value=${q} onInput=${(e) => setQ(e.target.value)} />
        <a class="btn small" href=${href("health")}>Back to all gaps</a></div>
    </div>
    <${ErrorBox} error=${error} />
    ${!data ? html`<${Loading} />` : html`
      <span class="muted small">${data.total.toLocaleString()} item${data.total === 1 ? "" : "s"}</span>
      <div class="tablewrap"><table class="data"><thead><tr><th>Component</th><th>Where</th><th>Detail</th></tr></thead>
        <tbody>${data.rows.map((r) => html`<tr>
          <td class="long">${r.node ? html`<${NodeLink} node=${r.node} />` : html`<span class="mono">${r.object}</span>`}</td>
          <td class="long mono small">${r.location}</td><td class="long small">${r.detail}</td></tr>`)}</tbody></table></div>
      ${data.total > PAGE ? html`<div class="row">
        <button class="btn small" disabled=${offset === 0} onClick=${() => setOffset(Math.max(0, offset - PAGE))}>Previous</button>
        <span class="muted small">${offset + 1}–${Math.min(offset + PAGE, data.total)} of ${data.total.toLocaleString()}</span>
        <button class="btn small" disabled=${offset + PAGE >= data.total} onClick=${() => setOffset(offset + PAGE)}>Next</button></div>` : null}`}
  </section>`;
}

export function Health({ params }) {
  const { data, error } = useApi("/api/health", {}, "health");
  const reason = params.get("reason");
  if (error) return html`<${ErrorBox} error=${error} />`;
  if (!data) return html`<${Loading} />`;
  const total = data.gaps.reduce((a, g) => a + g.n, 0);
  const picked = reason && data.gaps.find((g) => g.reason === reason && (!params.get("rule") || g.rule === params.get("rule")));
  return html`
    <h1>Health</h1>
    <p class="muted" style="margin:0">Snapshot ${data.snapshot}, graph built ${data.built_at}.</p>
    ${reason ? html`<${GapItems} reason=${reason} rule=${params.get("rule")} label=${picked && picked.label} />` : null}
    <div class="split">
      <div class="main stack">
        <section class="card stack"><h2>How complete the map is</h2><${Coverage} items=${data.coverage} onGo=${toHref} /></section>
        <section class="card stack" style="gap:4px"><h2>Where the map is incomplete · ${total.toLocaleString()}</h2>
          <p class="small muted" style="margin:0 0 8px">Open a row to see the items. Each one is shown on screens as a Gap, never guessed.</p>
          ${data.gaps.map((g) => html`<a href=${href("health", { reason: g.reason, rule: g.rule })}
            style=${`display:flex;justify-content:space-between;gap:16px;padding:10px 6px;border-top:1px solid var(--border);color:var(--ink);${g.reason === reason ? "background:var(--accent-soft)" : ""}`}>
            <span class="stack" style="gap:2px;min-width:0"><span>${g.label}</span><span class="mono muted small">${g.rule} · ${g.reason}</span></span>
            <b class="nowrap" style="color:var(--amber-fg)">${g.n.toLocaleString()}</b></a>`)}
          ${!data.gaps.length ? html`<p class="muted" style="margin:0">No gaps in this snapshot.</p>` : null}
        </section>
      </div>
      <aside class="side stack">
        <section class="card stack"><h2>How certain is an answer?</h2><${CertLegend} /></section>
        <section class="card stack"><h2>Quick checks</h2>
          <a href=${href("inventory", { kind: "glue_jobs", quick: "not_orchestrated" })}>Glue jobs no state machine runs</a>
          <a href=${href("inventory", { kind: "tables", "f.layer": "published", quick: "no_lineage" })}>Published tables with no lineage</a>
          <a href=${href("inventory", { kind: "tables", "f.layer": "none" })}>Tables with no layer (${data.tables_without_layer.toLocaleString()})</a>
          <a href=${href("inventory", { kind: "state_machines", quick: "has_gaps" })}>State machines with gaps</a>
          <a href=${href("inventory", { kind: "glue_jobs", quick: "no_ops" })}>Glue jobs missing from ops.yaml</a>
        </section>
        <section class="card stack"><h2>ops.yaml · ${data.ops_problems.length} problem${data.ops_problems.length === 1 ? "" : "s"}</h2>
          ${data.ops_problems.length ? html`<div class="rows">${data.ops_problems.map((p) => html`<div class="rowi">
            <span class="nm mono">${p.key || "(file)"}</span><span class="why">${p.problem}</span></div>`)}</div>`
            : html`<p class="muted" style="margin:0">No problems found.</p>`}
        </section>
      </aside>
    </div>`;
}
