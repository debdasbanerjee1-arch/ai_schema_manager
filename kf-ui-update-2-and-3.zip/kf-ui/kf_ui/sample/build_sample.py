"""Build a synthetic Knowledge Fabric graph in the real DDL.

Two variants:
  today  - what the real graph holds at snapshot 20261013T105815Z: Source, Raw,
           Distill, domain tables labelled Distill, orchestration, config keys,
           column lineage Raw to Distill. No triggers, consumers, terms or load times.
  full   - adds what the planned fixes will produce: domain tables in Published,
           Published views, external targets and dashboards as consumers,
           triggers, load times and business terms.

Names follow the real estate's patterns; the data is invented.

    python -m kf_ui make-sample --out C:\\kf-ui-sample --variant full
"""

import csv
import json
from pathlib import Path

import duckdb

SNAPSHOT = "20990101T000000Z"

DDL = """
CREATE SCHEMA IF NOT EXISTS g.graph;
CREATE TABLE g.graph.node (
  node_key VARCHAR PRIMARY KEY, node_type VARCHAR NOT NULL,
  layer VARCHAR NOT NULL DEFAULT 'none', parent_key VARCHAR, name VARCHAR NOT NULL,
  data_type VARCHAR, attrs JSON NOT NULL DEFAULT '{}', deleted BOOLEAN NOT NULL DEFAULT false,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT current_timestamp);
CREATE SEQUENCE g.graph.edge_seq;
CREATE TABLE g.graph.edge (
  edge_id BIGINT PRIMARY KEY DEFAULT nextval('g.graph.edge_seq'),
  src_key VARCHAR NOT NULL, dst_key VARCHAR NOT NULL, edge_type VARCHAR NOT NULL,
  transform_class VARCHAR, expression VARCHAR, origin VARCHAR NOT NULL, tier VARCHAR NOT NULL,
  job_key VARCHAR, attrs JSON NOT NULL DEFAULT '{}',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT current_timestamp);
"""

DM = "auk-prd-cdp-data-mapping-config-table"
GE = "auk-prd-cdp-generic-extract-mapping-config-table"
SP = "auk-prd-cdp-step-function-parameter-config-table"


class G:
    def __init__(self, variant):
        self.full = variant == "full"
        self.nodes = {}
        self.edges = []

    def node(self, key, ntype, layer, name, parent=None, data_type=None, **attrs):
        attrs.setdefault("rule", "R1")
        attrs.setdefault("snapshot", SNAPSHOT)
        attrs.setdefault("evidence", [f"sample:{key}"])
        self.nodes[key] = (key, ntype, layer, parent, name, data_type, attrs)
        return key

    def edge(self, src, dst, etype, origin, tier="certified", tc=None, expr=None, job=None, **attrs):
        attrs.setdefault("snapshot", SNAPSHOT)
        attrs.setdefault("evidence", [f"sample:{src}->{dst}"])
        self.edges.append((src, dst, etype, tc, expr, origin, tier, job, attrs))

    def columns(self, table_key, cols, pk=()):
        for i, c in enumerate(cols):
            extra = {"is_partition_key": c in ("year", "month", "day")}
            if c in pk:
                extra["pk_ordinal"] = pk.index(c) + 1
            self.node(f"{table_key}.{c}", "column", "none", c, parent=table_key, data_type="string", **extra)


def sfn(g, name, states, trigger=None):
    """states: list of (state_name, state_type, invokes_key or None, starts_key or None)."""
    key = g.node(f"aws.sfn.{name}", "pipeline", "none", name, sfn_type="STANDARD",
                 aws={"name": name, "arn": f"arn:aws:states:eu-west-2:000000000000:stateMachine:{name}"},
                 **({"triggers": trigger} if (trigger is not None and g.full) else {}))
    prev = None
    for sname, stype, invokes, starts in states:
        tk = g.node(f"{key}.{sname}", "pipeline_task", "none", sname, state_path=sname, state_type=stype)
        g.edge(key, tk, "contains", "sfn_definition", rule="R5")
        if prev:
            g.edge(tk, prev, "depends_on", "sfn_definition", relation="runs_after", rule="R5")
        if invokes:
            g.edge(tk, invokes, "depends_on", "sfn_definition", relation="invokes", rule="R5")
        if starts:
            g.edge(tk, starts, "depends_on", "sfn_definition", relation="starts", rule="R5")
        prev = tk
    return key


def build(out_dir, variant="full"):
    out = Path(out_dir)
    g = G(variant)
    F = g.full

    # ---------- Source, DMS, Raw ----------
    arcs = {"ARC1": "PRD", "ARC2": "PRA", "ARC3": "PRW"}
    comp_tables = {
        "address": ["address_id", "line_1", "postcode", "Op"],
        "contribution": ["contribution_id", "member_account_id", "contribution_amount", "contribution_date", "Op"],
        "audit_transaction_details": ["transaction_id", "member_account_id", "charge_type", "charge_amount", "Op"],
    }
    raw, dis = {}, {}
    for arc, env in arcs.items():
        dms = g.node(f"aws.dms_task.{arc.lower()}-composer-cdc", "dms_task", "none", f"{arc.lower()}-composer-cdc",
                     migration_type="full-load-and-cdc", status="running")
        tables = comp_tables if arc == "ARC1" else {"address": comp_tables["address"]}
        for t, cols in tables.items():
            s = g.node(f"src.sqlserver.{env}_AGComposer.dbo.{t}", "table", "source", t,
                       system=arc, system_type="pas", product="Composer", product_table=f"dbo.{t}",
                       environment_code=env, replication_mode="ongoing", task_status=["running"],
                       database=f"{env}_AGComposer", schema="dbo", ingestion="DMS", rule="R3")
            rk = f"glue.auk_prd_cdp_raw_db.{arc.lower()}_dbo_{t}"
            lt = {"last_loaded": {"at": "2099-01-01T05:40:00Z", "source": "dms_table_statistics"}} if F else {}
            g.node(rk, "table", "raw", f"{arc.lower()}_dbo_{t}", system=arc, raw_stage="inbound",
                   aws={"database": "auk_prd_cdp_raw_db", "table": f"{arc.lower()}_dbo_{t}",
                        "location": f"s3://auk-prd-cdp-raw/inbound/{arc.lower()}/dbo/{t}"}, **lt)
            g.columns(rk, cols)
            g.edge(dms, s, "reads", "dms_mapping", rule="R3")
            g.edge(dms, rk, "writes", "dms_mapping", rule="R3")
            g.edge(s, rk, "derives_from", "dms_mapping", tc="identity", job=dms, level="table", rule="R3")
            raw[(arc, t)] = rk

    # ---------- raw2dis per ARC ----------
    r2d_sfn = {}
    for arc in arcs:
        job = g.node(f"aws.glue_job.auk-prd-cdp-raw2dis-{arc.lower()}-hudi-load-batch", "glue_job", "none",
                     f"auk-prd-cdp-raw2dis-{arc.lower()}-hudi-load-batch", command_name="glueetl",
                     aws={"name": f"auk-prd-cdp-raw2dis-{arc.lower()}-hudi-load-batch"})
        sm_name = f"auk-prd-cdp-datapipeline-{arc.lower()}-comp-event-raw2dis-sh5"
        tables = [t for (a, t) in raw if a == arc]
        states = [("Query parameters", "Task", None, None)]
        for i, t in enumerate(tables):
            states.append((f"Check trigger {i}", "Choice", None, None))
            states.append((f"Load {t}", "Task", job, None))
        sm = sfn(g, sm_name, states, trigger=[{"kind": "schedule", "name": f"{arc.lower()}-raw2dis-every-15m",
                                               "expression": "rate(15 minutes)"}])
        r2d_sfn[arc] = sm
        for t in tables:
            cols = comp_tables[t]
            dk = f"glue.auk_prd_cdp_dis_db.{arc.lower()}_composer_dbo_{t}"
            ck = f"{arc.lower()}_composer_dbo_{t}"
            lt = {"last_loaded": {"at": "2099-01-01T05:55:00Z", "source": "bookmark"}} if F else {}
            g.node(dk, "table", "distill", ck, system=arc, distill_kind="replica",
                   source_equivalent=f"src.sqlserver.{arcs[arc]}_AGComposer.dbo.{t}",
                   source_equivalent_method="naming_convention", primary_key=[cols[0]],
                   primary_key_origin="hudi_record_key",
                   aws={"database": "auk_prd_cdp_dis_db", "table": ck,
                        "location": f"s3://auk-prd-cdp-distill/{arc.lower()}/composer/dbo/{t}"}, **lt)
            dcols = [("dms_op" if c == "Op" else c) for c in cols] + ["sourcesystem", "year", "month", "day"]
            g.columns(dk, dcols, pk=(cols[0],))
            rk = raw[(arc, t)]
            common = dict(config_table=DM, config_key=ck, rule="R4")
            g.edge(job, rk, "reads", "dynamodb_config", via_state_machine=sm_name, **common)
            g.edge(job, dk, "writes", "dynamodb_config", via_state_machine=sm_name, **common)
            g.edge(rk, dk, "derives_from", "dynamodb_config", tc="unclassified", job=job, level="table", **common)
            for i, c in enumerate(cols):
                tc = "meaning_preserving" if c == "Op" else "identity"
                g.edge(f"{rk}.{c}", f"{dk}.{'dms_op' if c == 'Op' else c}", "derives_from", "dynamodb_config",
                       tc=tc, expr="one2one", job=job, level="column", mapping_seq_no=i + 1, **common)
            dis[(arc, t)] = dk

    # ---------- domain tables (generic_extract) ----------
    dom_layer = "published" if F else "distill"
    dom_kind = {} if F else {"distill_kind": "domain"}

    def domain(code, table, inputs, sm_name, job_name, trigger, sql, cols, colmap, system="ARC1"):
        job = g.node(f"aws.glue_job.{job_name}", "glue_job", "none", job_name, command_name="glueetl",
                     aws={"name": job_name})
        sm = sfn(g, sm_name, [("Query parameters", "Task", None, None), ("Choice trigger", "Choice", None, None),
                              (f"Extract {table}", "Task", job, None)], trigger=trigger)
        dk = f"glue.dis_domain.{code}_{table}"
        lt = {"last_loaded": {"at": "2099-01-01T02:10:00Z", "source": "glue_job_run"}} if F else {}
        g.node(dk, "table", dom_layer, f"{code}_{table}", system=system, **dom_kind,
               aws={"database": "dis_domain", "table": f"{code}_{table}",
                    "location": f"s3://auk-prd-cdp-distill/domain/{code}/{table}"}, **lt)
        g.columns(dk, cols)
        common = dict(config_table=GE, config_key=f"{code}_{table}", rule="R4", sql_file=sql)
        g.edge(job, dk, "writes", "dynamodb_config", via_state_machine=sm_name, **common)
        for i in inputs:
            g.edge(job, i, "reads", "dynamodb_config", via_state_machine=sm_name, **common)
            g.edge(i, dk, "derives_from", "dynamodb_config", tc="unclassified", job=job, level="table", **common)
        for (src_tab, src_col), dst_col in colmap.items():
            g.edge(f"{src_tab}.{src_col}", f"{dk}.{dst_col}", "derives_from", "parsed", tc="identity",
                   job=job, level="column", **common)
        return dk, sm, job

    sched = lambda h: [{"kind": "schedule", "name": f"daily-{h}", "expression": f"cron(0 {h} * * ? *)"}]
    a1 = dis[("ARC1", "address")]
    adv, adv_sm, adv_job = domain("adviser_domain", "adviser_address", [a1],
                                  "auk-prd-adv-domain-generic-extract-sh1", "auk-prd-adv-dis-generic-extract",
                                  sched(2), "dis/mi_decom/arc1/adviser_domain/adviser_address.sql",
                                  ["address_id", "line_1", "postcode"],
                                  {(a1, "address_id"): "address_id", (a1, "line_1"): "line_1",
                                   (a1, "postcode"): "postcode"})
    cust_inputs = [dis[(a, "address")] for a in arcs]
    cust, cust_sm, cust_job = domain("customer_domain", "customer_address_unified", cust_inputs,
                                     "auk-prd-cust-domain-generic-extract-sh1", "auk-prd-cust-dis-generic-extract",
                                     sched(3), "dis/mi_decom/unified/customer_domain/customer_address_unified.sql",
                                     ["address_id", "postcode", "source_platform"],
                                     {(i, "postcode"): "postcode" for i in cust_inputs}, system="ARC1")
    tx = dis[("ARC1", "audit_transaction_details")]
    aud, aud_sm, aud_job = domain("audit_domain", "arc1_audit_transaction_details", [tx],
                                  "auk-prd-cdp-aud-arc1-audt-txn-dtl-sh1", "auk-prd-cdp-aud-dis-generic-extract",
                                  None, "dis/mi_decom/arc1/audit_domain/arc1_audit_transaction_details.sql",
                                  ["transaction_id", "member_account_id", "charge_type", "charge_amount"],
                                  {(tx, c): c for c in ["transaction_id", "member_account_id", "charge_type",
                                                        "charge_amount"]})
    co = dis[("ARC1", "contribution")]
    event = [{"kind": "event", "rule": "contrib-on-raw2dis-success", "event_source": "aws.states",
              "detail_type": "Step Functions Execution Status Change",
              "matches": [r2d_sfn["ARC1"]], "status": ["SUCCEEDED"]}]
    con, con_sm, con_job = domain("contribution_domain", "member_contributions", [co],
                                  "auk-prd-contrib-domain-generic-extract-sh1", "auk-prd-contrib-dis-generic-extract",
                                  event, "dis/mi_decom/arc1/contribution_domain/member_contributions.sql",
                                  ["member_account_id", "contribution_amount", "contribution_date"],
                                  {(co, c): c for c in ["member_account_id", "contribution_amount",
                                                        "contribution_date"]})
    # parameter items: the state machine reads its branch list from the parameter table
    for sm_key, ck, job in [(adv_sm, "adviser_domain_adviser_address", adv_job),
                            (cust_sm, "customer_domain_customer_address_unified", cust_job)]:
        g.edge(job, adv if ck.startswith("adviser") else cust, "writes", "dynamodb_config",
               config_table=SP, config_key=ck, via_state_machine=sm_key.split("aws.sfn.")[1], rule="R4")

    # a shared generic-extract job run by two state machines; the branch does not name either
    ctxn = g.node("aws.glue_job.auk-prd-cdp-ctxn-dis-generic-extract", "glue_job", "none",
                  "auk-prd-cdp-ctxn-dis-generic-extract", command_name="glueetl")
    for arc in ("arc1", "arc2"):
        sfn(g, f"auk-prd-cdp-ctxn-{arc}-chg-cr-summ-adv-sh1", [("Extract", "Task", ctxn, None)], trigger=sched(4))
    a2 = dis[("ARC2", "address")]
    summ = g.node("glue.dis_domain.arc2_chgtxn_charge_credit_summary_adviser", "table", dom_layer,
                  "arc2_chgtxn_charge_credit_summary_adviser", system="ARC2", **dom_kind)
    g.columns(summ, ["address_id", "postcode"])
    txn = g.node("glue.dis_domain.arc2_chgtxn_charge_credit_txn_adviser", "table", dom_layer,
                 "arc2_chgtxn_charge_credit_txn_adviser", system="ARC2", **dom_kind)
    g.columns(txn, ["address_id", "postcode"])
    for src, dst in ((a2, txn), (txn, summ)):  # a chain inside one state machine
        ck = "dis_hudi_" + g.nodes[dst][4]
        g.edge(ctxn, src, "reads", "dynamodb_config", config_table=GE, config_key=ck, rule="R4")
        g.edge(ctxn, dst, "writes", "dynamodb_config", config_table=GE, config_key=ck, rule="R4")
        g.edge(src, dst, "derives_from", "dynamodb_config", tc="unclassified", job=ctxn, level="table",
               config_table=GE, config_key=ck, rule="R4")

    # ambiguous_job: a state machine that invokes two candidate jobs
    amb_a = g.node("aws.glue_job.auk-prd-pal-generic-extract-a", "glue_job", "none", "auk-prd-pal-generic-extract-a")
    amb_b = g.node("aws.glue_job.auk-prd-pal-generic-extract-b", "glue_job", "none", "auk-prd-pal-generic-extract-b")
    sfn(g, "auk-prd-pal-extract-sh2", [("Run a", "Task", amb_a, None), ("Run b", "Task", amb_b, None)])
    g.nodes["aws.sfn.auk-prd-pal-extract-sh2"][6]["processes_tables"] = ["pal_account_investment"]

    # ATOS file feed: lambda on S3 event starts a state machine
    land = g.node("glue.auk_prd_cdp_raw_db.atos_policy", "table", "raw", "atos_policy", system="ATOS",
                  raw_stage="inbound", aws={"location": "s3://auk-prd-cdp-raw/inbound/atos/policy"})
    lam = g.node("aws.lambda.auk-prd-atos-file-trigger", "lambda_function", "none", "auk-prd-atos-file-trigger",
                 runtime="python3.12")
    atos_job = g.node("aws.glue_job.auk-prd-cdp-raw2dis-atos-hudi-load-batch", "glue_job", "none",
                      "auk-prd-cdp-raw2dis-atos-hudi-load-batch")
    atos_sm = sfn(g, "auk-prd-cdp-datapipeline-atos-raw2dis", [("Load policy", "Task", atos_job, None)])
    g.edge(lam, atos_sm, "depends_on", "sfn_definition", relation="starts", rule="R5")
    if F:
        g.edge(lam, land, "depends_on", "connector", relation="triggered_by", rule="R5")
    datos = g.node("glue.auk_prd_cdp_dis_db.atos_policy", "table", "distill", "atos_policy", system="ATOS",
                   distill_kind="replica")
    g.columns(datos, ["policy_ref", "fund_value", "valuation_date"], pk=("policy_ref",))
    g.edge(atos_job, land, "reads", "dynamodb_config", config_table=DM, config_key="atos_policy", rule="R4")
    g.edge(atos_job, datos, "writes", "dynamodb_config", config_table=DM, config_key="atos_policy", rule="R4")
    g.edge(land, datos, "derives_from", "dynamodb_config", tc="unclassified", job=atos_job, level="table",
           config_table=DM, config_key="atos_policy", rule="R4")

    # ---------- full variant: Published views, consumers, terms ----------
    if F:
        pub = g.node("glue.auk_prd_adx_pub_db.adviser_address", "table", "published", "adviser_address",
                     system="ARC1", table_type="VIRTUAL_VIEW",
                     aws={"database": "auk_prd_adx_pub_db", "table": "adviser_address"})
        g.columns(pub, ["address_id", "line_1", "postcode"])
        g.edge(adv, pub, "derives_from", "parsed", tc="identity", level="table", rule="R6")
        for c in ["address_id", "line_1", "postcode"]:
            g.edge(f"{adv}.{c}", f"{pub}.{c}", "derives_from", "parsed", tc="identity", level="column", rule="R6")
        ext = g.node("ext.postgres.mylo.adviser_address", "extract", "consumer", "mylo.adviser_address",
                     target_engine="postgres")
        g.edge(adv_job, ext, "writes", "dynamodb_config", config_table=GE, config_key="adviser_domain_mylo_feed",
               via_state_machine=adv_sm.split("aws.sfn.")[1], rule="R4")
        g.edge(adv, ext, "derives_from", "dynamodb_config", tc="unclassified", job=adv_job, level="table",
               config_table=GE, config_key="adviser_domain_mylo_feed", rule="R4")
        out_file = g.node("ext.s3.outbound.adviser_addresses_csv", "extract", "consumer",
                          "outbound/adviser_addresses.csv", target_engine="s3_file")
        g.edge(adv, out_file, "derives_from", "dynamodb_config", tc="unclassified", job=adv_job, level="table",
               config_table=GE, config_key="adviser_domain_outbound", rule="R4")
        for k, nm, tables in [("quicksight.dashboard.adv01", "Adviser dashboard", [pub]),
                              ("quicksight.dashboard.chg01", "Charges MI", [aud]),
                              ("aws.api.cust01.GET./customers/address", "Customer address API", [cust]),
                              ("quicksight.dashboard.con01", "Contributions MI", [con])]:
            ntype = "api_endpoint" if k.startswith("aws.api") else "dashboard"
            g.node(k, ntype, "consumer", nm)
            for t in tables:
                g.edge(k, t, "consumes", "connector", rule="R9")
        for term, d, origin, tier, cols in [
            ("platform charge", "Charge deducted by the platform from a wrapper or policy.", "declared", "certified",
             [f"{tx}.charge_type", f"{tx}.charge_amount", f"{aud}.charge_amount"]),
            ("wrapper", "The product wrapper (for example SIPP or ISA) that holds a member account.",
             "llm_draft", "proposed", [f"{tx}.member_account_id"]),
            ("contribution", "A payment into a member account.", "declared", "certified",
             [f"{co}.contribution_amount", f"{co}.contribution_date", f"{con}.contribution_amount"])]:
            tk = g.node(f"term.{term.replace(' ', '_')}.00000000", "glossary_term", "none", term, definition=d,
                        origin=origin, tier=tier, scope="product")
            for c in cols:
                g.edge(c, tk, "means", origin, tier=tier, rule="R10")

    # ---------- write ----------
    gdir = out / "graph"
    gdir.mkdir(parents=True, exist_ok=True)
    gfile = gdir / f"graph.{SNAPSHOT}.duckdb"
    if gfile.exists():
        gfile.unlink()
    con_ = duckdb.connect()
    con_.execute(f"ATTACH '{gfile.as_posix()}' AS g")
    con_.execute(DDL)
    for key, nt, layer, parent, name, dt, attrs in g.nodes.values():
        con_.execute("INSERT INTO g.graph.node (node_key,node_type,layer,parent_key,name,data_type,attrs) "
                     "VALUES (?,?,?,?,?,?,?)", [key, nt, layer, parent, name, dt, json.dumps(attrs)])
    for src, dst, et, tc, expr, origin, tier, job, attrs in g.edges:
        con_.execute("INSERT INTO g.graph.edge (src_key,dst_key,edge_type,transform_class,expression,origin,tier,"
                     "job_key,attrs) VALUES (?,?,?,?,?,?,?,?,?)",
                     [src, dst, et, tc, expr, origin, tier, job, json.dumps(attrs)])
    con_.close()
    (gdir / "CURRENT").write_text(gfile.name, encoding="utf-8")

    gaps = out / "gaps" / SNAPSHOT
    gaps.mkdir(parents=True, exist_ok=True)
    with (gaps / "R4.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["rule", "object", "location", "reason", "detail", "evidence"])
        w.writerow(["R4", "aws.sfn.auk-prd-pal-extract-sh2", "", "ambiguous_job",
                    "state machine invokes 2 candidate jobs", "sample"])
        w.writerow(["R4", "aws.glue_job.auk-prd-cust-dis-generic-extract", "customer_domain_feed",
                    "generic_extract_target_unresolved", "write target not matched", "sample"])
    (out / "inventory" / "snapshots").mkdir(parents=True, exist_ok=True)
    (out / "inventory" / "snapshots" / f"{SNAPSHOT}.json").write_text(json.dumps({"runs": {}}), encoding="utf-8")
    cfg = out / "config"
    cfg.mkdir(exist_ok=True)
    (cfg / "ops.yaml").write_text(
        "aws.glue_job.auk-prd-cdp-raw2dis-arc1-hudi-load-batch:\n"
        "  owner: ODC data engineering\n  criticality: high\n  rerun_safe: yes\n"
        "  rerun_note: bookmark rewinds 15 minutes; Hudi upsert on the record key\n"
        "aws.sfn.auk-prd-adv-domain-generic-extract-sh1:\n"
        "  owner: Adviser domain team\n  criticality: medium\n  rerun_safe: yes\n"
        "  rerun_note: overwrites the target\n"
        "aws.glue_job.does-not-exist:\n  owner: nobody\n", encoding="utf-8")
    (cfg / "source_systems.yaml").write_text(
        "systems:\n  COMPASS:\n    aliases: [TargetPlan, Target Plan]\n  ARC1:\n    aliases: [PRD]\n", encoding="utf-8")
    return out
