import { html, useEffect, useLayoutEffect, useRef, useState } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { patch } from "../lib/router.js";
import { Empty, ErrorBox, Handoff, Loading, NodeLink, Notes, OpsTags, Picker } from "../lib/ui.js";

const KIND = { dms: "DMS replication", state_machine: "State machine", job: "Job (no state machine found)",
  no_job: "View or derivation", unknown_state_machine: "State machine not known" };
const TONE = { enforced: "var(--green-fg)", event: "var(--blue-fg)", schedule_only: "var(--amber-fg)",
  not_harvested: "var(--muted)", no_trigger_found: "var(--red-fg)" };

// Stage = 1 + the latest stage among the steps it waits for, so parallel branches share a stage
// and a step that joins branches sits after all of them. Within a stage, steps are ordered by the
// position of the steps they wait for (and, for the first stage, the steps that wait for them),
// which keeps lines from crossing.
function layout(segments) {
  const by = Object.fromEntries(segments.map((s) => [s.n, s]));
  const stage = {};
  for (const s of segments) stage[s.n] = s.after.length ? 1 + Math.max(...s.after.map((a) => stage[a.step] ?? 0)) : 0;
  const succ = {};
  for (const s of segments) for (const a of s.after) (succ[a.step] = succ[a.step] || []).push(s.n);
  const cols = [];
  for (const s of segments) (cols[stage[s.n]] = cols[stage[s.n]] || []).push(s.n);
  const pos = {};
  const place = (col) => col.forEach((n, i) => { pos[n] = i; });
  cols.forEach(place);
  for (let pass = 0; pass < 2; pass++) {
    for (let c = 1; c < cols.length; c++) {
      const bc = (n) => { const ps = by[n].after.map((a) => pos[a.step]); return ps.length ? ps.reduce((x, y) => x + y, 0) / ps.length : pos[n]; };
      cols[c].sort((a, b) => bc(a) - bc(b)); place(cols[c]);
    }
    if (cols[0]) {
      const bs = (n) => { const ss = (succ[n] || []).map((m) => pos[m]); return ss.length ? ss.reduce((x, y) => x + y, 0) / ss.length : pos[n]; };
      cols[0].sort((a, b) => bs(a) - bs(b)); place(cols[0]);
    }
  }
  return { cols, by, succ };
}

function Lines({ boxRef, segments, selected, tick, consumers }) {
  const [shapes, setShapes] = useState({ paths: [], labels: [] });
  useLayoutEffect(() => {
    const box = boxRef.current;
    if (!box) return;
    const B = box.getBoundingClientRect();
    const at = {};
    box.querySelectorAll("[data-step]").forEach((el) => {
      const r = el.getBoundingClientRect();
      at[el.dataset.step] = { l: r.left - B.left, r: r.right - B.left, y: r.top - B.top + Math.min(r.height / 2, 40) };
    });
    const paths = [], labels = [];
    const link = (from, to, h, title, id) => {
      const a = at[from], b = at[to];
      if (!a || !b) return;
      const dx = Math.max(24, (b.l - a.r) / 2);
      const hl = selected && (String(selected) === String(from) || String(selected) === String(to));
      paths.push({ d: `M${a.r},${a.y} C${a.r + dx},${a.y} ${b.l - dx},${b.y} ${b.l},${b.y}`, hl, color: h ? TONE[h.type] : null, id });
      if (h) labels.push({ x: (a.r + b.l) / 2, y: (a.y + b.y) / 2, h, title, hl, id });
    };
    for (const s of segments) for (const a of s.after) link(a.step, s.n, a.handoff, `${a.handoff ? a.handoff.label + ": " + a.handoff.why + ". " : ""}Reads ${a.table.name}`, `${a.step}>${s.n}`);
    for (const c of consumers) for (const from of c.from) link(from, "c:" + c.key, null, "", `${from}>c:${c.key}`);
    setShapes({ paths, labels });
  }, [segments, selected, tick, consumers.length]);
  return html`
    <svg class="edges" aria-hidden="true">${shapes.paths.map((p) => html`<path d=${p.d} class=${p.hl ? "hl" : ""}
      style=${p.color && !p.hl ? `stroke:${p.color};stroke-opacity:.55` : ""} />`)}</svg>
    ${shapes.labels.map((l) => html`<span class=${"badge flow-label" + (l.hl ? " hl" : "")} title=${l.title}
      style=${`left:${l.x}px;top:${l.y}px;color:${TONE[l.h.type] || "var(--muted)"}`}>${l.h.label}</span>`)}`;
}

function StepCard({ s, table, selected, onSelect }) {
  const writesTable = s.steps.some((st) => st.to.key === table);
  const title = s.orchestrator ? s.orchestrator.name : (s.jobs[0] ? s.jobs[0].name : s.steps[0] && s.steps[0].to.name);
  const outs = [...new Map(s.steps.map((st) => [st.to.key, st.to])).values()];
  return html`<button class=${"node flow-node" + (selected ? " sel" : "") + (writesTable ? " root" : "")} data-step=${s.n}
      style=${`--c:${s.kind === "dms" ? "var(--l-raw)" : s.kind === "unknown_state_machine" ? "var(--red-fg)" : "var(--l-job)"}`}
      onClick=${() => onSelect(s.n)} aria-pressed=${selected}>
    <span class="meta"><span>${s.n}. ${KIND[s.kind] || s.kind}</span></span>
    <span class="nm">${title}</span>
    ${s.kind === "state_machine" && s.jobs.length ? html`<span class="meta">runs ${s.jobs.map((j) => j.name).join(", ")}</span>` : null}
    ${s.kind === "unknown_state_machine" ? html`<span class="meta">one of ${s.candidates.length} state machines</span>` : null}
    <span class="meta">→ ${outs.slice(0, 3).map((t) => t.name).join(", ")}${outs.length > 3 ? ` +${outs.length - 3}` : ""}</span>
    ${writesTable ? html`<span class="meta"><span class="badge accent">builds this table</span></span>` : null}
  </button>`;
}

function Details({ s, data }) {
  if (!s) return null;
  return html`<section class="card stack" aria-label="Selected step">
    <div class="row" style="justify-content:space-between"><h2>${s.n}. ${KIND[s.kind] || s.kind}</h2><${OpsTags} tags=${s.ops_tags} /></div>
    ${s.orchestrator ? html`<div><${NodeLink} node=${s.orchestrator} /></div>` : null}
    ${s.candidates && s.candidates.length ? html`<div class="stack" style="gap:4px">
      <span class="badge red wrap">The branch's config doesn't name its state machine; it is one of these:</span>
      ${s.candidates.map((c) => html`<div><${NodeLink} node=${c} showType=${false} /></div>`)}</div>` : null}
    ${s.jobs.length ? html`<div class="small">runs ${s.jobs.map((j, i) => html`${i ? ", " : ""}<${NodeLink} node=${j} showType=${false} />`)}</div>` : null}
    <div class="stack" style="gap:4px"><h3>What it does</h3>${s.steps.map((st) => html`<div class="small">
      <span class="mono">${st.from.name}</span> → <a class="mono" href=${"#/detail?key=" + encodeURIComponent(st.to.key)}>${st.to.name}</a>
      ${st.config_key && !st.config_key.endsWith(st.to.name) ? html` <span class="muted">(branch ${st.config_key})</span>` : null}
      ${st.to.key === data.table.key ? html` <span class="badge accent">this table</span>` : null}</div>`)}</div>
    <div class="stack" style="gap:4px"><h3>Waits for</h3>
      ${s.after.length ? s.after.map((a) => html`<div class="row small">
        <span>step ${a.step} (<span class="mono">${a.name}</span>)</span>
        ${a.handoff ? html`<${Handoff} h=${a.handoff} /><span class="muted">${a.handoff.why}</span>`
          : s.kind === "unknown_state_machine" ? html`<span class="badge">Hand-off unknown</span>` : null}
        <span class="muted">· reads <span class="mono">${a.table.name}</span></span></div>`)
        : html`<span class="small muted">Nothing upstream in the graph: this is where the data enters.</span>`}
    </div>
  </section>`;
}

export function Flow({ params }) {
  const key = params.get("key");
  const { data, error } = useApi("/api/flow", { key }, key);
  const [sel, setSel] = useState(null);
  const [tick, setTick] = useState(0);
  const boxRef = useRef();
  useEffect(() => {
    const on = () => setTick((t) => t + 1);
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, []);
  useEffect(() => {
    if (!data) return;
    const own = data.segments.find((s) => s.steps.some((st) => st.to.key === data.table.key));
    setSel(own ? own.n : (data.segments[0] && data.segments[0].n));
  }, [data]);

  const picker = html`<div class="card noprint"><${Picker} label="Which table?" types=${["table", "extract"]}
    value=${data ? data.table.name : ""} onPick=${(r) => patch({ key: r.key })} /></div>`;
  const legend = html`<div class="row small muted noprint">
    <span class="badge green">Enforced</span> started by the previous step
    <span class="badge blue">Event</span> started when the data or a completion event arrives
    <span class="badge amber">Schedule only</span> runs on its own clock; nothing makes it wait
    <span class="badge">Not harvested</span> trigger not in this snapshot</div>`;
  if (!key) return html`<h1>End-to-end flow</h1>${picker}<${Empty}>Pick a table to see every step its data passes through: parallel branches side by side, joining where they meet.</${Empty}>`;
  if (error) return html`<h1>End-to-end flow</h1>${picker}<${ErrorBox} error=${error} />`;
  if (!data) return html`<h1>End-to-end flow</h1>${picker}<${Loading} />`;
  if (!data.segments.length) return html`<h1>End-to-end flow</h1>${picker}<${Empty}>No lineage into or out of ${data.table.name} in the graph.</${Empty}>`;

  const { cols, by, succ } = layout(data.segments);
  const ends = data.segments.filter((s) => !(succ[s.n] || []).length).map((s) => s.n);
  const consumers = data.consumers.map((c) => ({ ...c, from: ends }));
  const s = by[sel];
  return html`
    <h1>End-to-end flow</h1>${picker}${legend}
    ${!data.triggers_harvested ? html`<${Notes} notes=${["Triggers are not harvested yet, so hand-offs between state machines show as Not harvested."]} />` : null}
    <div class="lanes-wrap">
      <div class="lanes flow-grid" ref=${boxRef}>
        <${Lines} boxRef=${boxRef} segments=${data.segments} selected=${sel} tick=${tick} consumers=${consumers} />
        ${cols.map((col, i) => html`<div class="lane">
          <div class="lane-h" style="--c:var(--muted)">Stage ${i + 1}</div>
          ${col.map((n) => html`<${StepCard} s=${by[n]} table=${data.table.key} selected=${n === sel} onSelect=${setSel} />`)}
        </div>`)}
        ${consumers.length ? html`<div class="lane"><div class="lane-h" style="--c:var(--l-consumer)">Consumers</div>
          ${consumers.map((c) => html`<a class="node flow-node" data-step=${"c:" + c.key} style="--c:var(--l-consumer)" href=${"#/detail?key=" + encodeURIComponent(c.key)}>
            <span class="nm">${c.name}</span><span class="meta">${c.type}</span></a>`)}</div>` : null}
      </div>
    </div>
    <p class="small muted" style="margin:0">Click a step for details. Lines show which step waits for which; the badge on a line is how the later step is started.</p>
    <${Details} s=${s} data=${data} />`;
}
