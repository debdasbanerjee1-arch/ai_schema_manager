import { html, useEffect, useLayoutEffect, useRef, useState } from "../lib/preact.js";
import { useApi } from "../lib/api.js";
import { href, patch } from "../lib/router.js";
import { Badge, Empty, ErrorBox, LAYERS, LAYER_LABEL, Layer, Loading, NodeLink, Picker, TYPE_LABEL, detailHref, layerVar } from "../lib/ui.js";

// Lanes left to right by layer; inside a lane, upstream first then by name.
function lanesOf(nodes) {
  const by = {};
  for (const n of nodes) (by[n.layer] = by[n.layer] || []).push(n);
  for (const l in by) by[l].sort((a, b) => a.depth - b.depth || a.name.localeCompare(b.name));
  return LAYERS.filter((l) => by[l]).map((l) => [l, by[l]]);
}

function Edges({ boxRef, edges, nodes, selected, tick }) {
  const [paths, setPaths] = useState([]);
  useLayoutEffect(() => {
    const box = boxRef.current;
    if (!box) return;
    const B = box.getBoundingClientRect();
    const pos = {};
    box.querySelectorAll("[data-key]").forEach((el) => {
      const r = el.getBoundingClientRect();
      pos[el.dataset.key] = { l: r.left - B.left, r: r.right - B.left, y: r.top - B.top + r.height / 2 };
    });
    const out = [];
    for (const e of edges) {
      const a = pos[e.src], b = pos[e.dst];
      if (!a || !b) continue;
      let d;
      if (b.l > a.r) {
        const dx = Math.max(30, (b.l - a.r) / 2);
        d = `M${a.r},${a.y} C${a.r + dx},${a.y} ${b.l - dx},${b.y} ${b.l},${b.y}`;
      } else {
        const x = Math.max(a.r, b.r) + 24;
        d = `M${a.r},${a.y} C${x},${a.y} ${x},${b.y} ${b.r},${b.y}`;
      }
      out.push({ d, hl: selected && (e.src === selected || e.dst === selected), id: e.src + ">" + e.dst });
    }
    setPaths(out);
  }, [edges, nodes, selected, tick]);
  return html`<svg class="edges" aria-hidden="true">${paths.map((p) => html`<path d=${p.d} class=${p.hl ? "hl" : ""} />`)}</svg>`;
}

export function Lineage({ params }) {
  const key = params.get("key");
  const direction = params.get("dir") || "both";
  const depth = parseInt(params.get("depth") || "2", 10);
  const lens = params.get("lens") || "orchestration";
  const level = params.get("level") || "table";
  const req = { key, direction, depth, lens, level };
  const { data, error, loading } = useApi("/api/lineage", req, key ? JSON.stringify(req) : null);
  const [sel, setSel] = useState(null);
  const [tick, setTick] = useState(0);
  const boxRef = useRef();
  useEffect(() => setSel(key), [key]);
  useEffect(() => {
    const on = () => setTick((t) => t + 1);
    window.addEventListener("resize", on);
    return () => window.removeEventListener("resize", on);
  }, []);

  const controls = html`<div class="card stack noprint">
    <${Picker} label="Start from a table or column" types=${["table", "extract", "column"]} value=${data ? data.root.name : ""}
      onPick=${(r) => patch({ key: r.key, level: r.type === "column" ? "column" : null })} />
    ${key ? html`<div class="row">
      <div class="seg" role="group" aria-label="Direction">${[["up", "Upstream"], ["both", "Both"], ["down", "Downstream"]].map(([v, l]) => html`
        <button class=${direction === v ? "on" : ""} aria-pressed=${direction === v} onClick=${() => patch({ dir: v })}>${l}</button>`)}</div>
      <label class="row small">Hops <select class="select" style="width:70px" value=${depth} onChange=${(e) => patch({ depth: e.target.value })}>
        ${[1, 2, 3, 4, 5, 6].map((d) => html`<option value=${d}>${d}</option>`)}</select></label>
      <div class="seg" role="group" aria-label="Lens">${[["data", "Data only"], ["orchestration", "With jobs"]].map(([v, l]) => html`
        <button class=${lens === v ? "on" : ""} aria-pressed=${lens === v} onClick=${() => patch({ lens: v })}>${l}</button>`)}</div>
    </div>` : null}
  </div>`;

  if (!key) return html`<h1>Lineage</h1>${controls}<${Empty}>Pick a table to see what feeds it and what it feeds.</${Empty}>`;
  if (error) return html`<h1>Lineage</h1>${controls}<${ErrorBox} error=${error} />`;
  if (!data) return html`<h1>Lineage</h1>${controls}<${Loading} />`;

  const lanes = lanesOf(data.nodes);
  const byKey = Object.fromEntries(data.nodes.map((n) => [n.key, n]));
  const s = byKey[sel] || byKey[key];
  const touching = data.edges.filter((e) => s && (e.src === s.key || e.dst === s.key));

  return html`
    <h1>Lineage</h1>
    ${controls}
    ${data.nodes.length <= 1 ? html`<${Empty}>No ${level === "column" ? "column" : "table-level"} lineage recorded for ${data.root.name}.</${Empty}>` : html`
    <div class="split">
      <div class="main wide lanes-wrap">
        <div class="lanes" ref=${boxRef}>
          <${Edges} boxRef=${boxRef} edges=${data.edges} nodes=${data.nodes} selected=${s && s.key} tick=${tick} />
          ${lanes.map(([layer, nodes]) => html`<div class="lane" style=${`--c:${layerVar(layer)}`}>
            <div class="lane-h">${LAYER_LABEL[layer]} · ${nodes.length}</div>
            ${nodes.map((n) => html`<button class=${"node" + (n.key === key ? " root" : "") + (s && n.key === s.key ? " sel" : "")}
              data-key=${n.key} style=${`--c:${layerVar(layer)}`} onClick=${() => setSel(n.key)} aria-pressed=${s && n.key === s.key}>
              <span class="nm">${n.name}</span>
              <span class="meta">${n.system ? html`<span>${n.system}</span>` : null}
                ${n.depth ? html`<span>${n.depth < 0 ? `${-n.depth} up` : `${n.depth} down`}</span>` : html`<span>start</span>`}
                ${n.consumers && n.consumers.length ? html`<span>${n.consumers.length} consumer${n.consumers.length > 1 ? "s" : ""}</span>` : null}
                ${n.gaps ? html`<${Badge} tone="red">${n.gaps} gap${n.gaps > 1 ? "s" : ""}</${Badge}>` : null}
                ${n.more_up || n.more_down ? html`<span>more ${n.more_up ? "upstream" : "downstream"}</span>` : null}</span>
            </button>`)}
          </div>`)}
        </div>
      </div>
      ${s ? html`<aside class="side narrow card stack" aria-label="Selected">
        <div class="stack" style="gap:4px"><span class="muted small">${TYPE_LABEL[s.type] || s.type}</span>
          <b class="mono">${s.name}</b><div class="row"><${Layer} layer=${s.layer} />${s.system ? html`<span class="small">${s.system}</span>` : null}</div>
          ${s.loaded ? html`<span class="small muted">Last loaded ${s.loaded.at} (as of snapshot)</span>` : null}</div>
        <div class="row">
          <a class="btn small primary" href=${detailHref(s.key)}>Details</a>
          ${s.key !== key ? html`<a class="btn small" href=${href("lineage", { key: s.key, dir: direction, depth, lens, level: level === "column" ? "column" : null })}>Centre here</a>` : null}
          ${s.type !== "column" ? html`<a class="btn small" href=${href("flow", { key: s.key })}>Flow</a>
            <a class="btn small" href=${href("impact", { mode: "stale", key: s.key })}>Stale check</a>` : html`<a class="btn small" href=${href("impact", { mode: "column", key: s.key })}>Column change</a>`}
        </div>
        ${s.consumers && s.consumers.length ? html`<div class="stack" style="gap:4px"><h3>Consumers</h3>${s.consumers.map((c) => html`<${NodeLink} node=${c} />`)}</div>` : null}
        <div class="stack" style="gap:6px"><h3>Links · ${touching.length}</h3>${touching.map((e) => {
          const other = e.src === s.key ? byKey[e.dst] : byKey[e.src];
          return html`<div class="rowi" style="flex-direction:column;gap:2px">
            <span class="small">${e.src === s.key ? "feeds" : "from"} <span class="mono">${other ? other.name : ""}</span></span>
            ${e.job_name ? html`<span class="small muted">job <a class="mono" href=${detailHref(e.job)}>${e.job_name}</a>
              ${e.orchestrator ? html` in <a class="mono" href=${detailHref(e.orchestrator.key)}>${e.orchestrator.name}</a>`
                : e.orchestrator_candidates && e.orchestrator_candidates.length ? html` in one of ${e.orchestrator_candidates.length} state machines (not recorded for this branch)` : null}</span>` : null}
            <span class="small muted">${[e.origin, e.tier, e.transform_class, e.config_key].filter(Boolean).join(" · ")}</span>
          </div>`;
        })}</div>
      </aside>` : null}
    </div>`}
    ${data.nodes.length > 150 ? html`<p class="note">This view has ${data.nodes.length} components. Fewer hops or one direction is easier to read.</p>` : null}`;
}
