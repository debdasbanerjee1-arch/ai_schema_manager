"""Impact, hand-offs and checklists.

Data paths follow table-level derives_from edges (one input-output pair each), never
job to job through reads and writes, so a job that loads many tables does not fan out.
"""

from __future__ import annotations

from collections import deque

from .store import CONSUMER_TYPES, JOB_TYPES, ORCH_TYPES

HANDOFF_LABEL = {"enforced": "Enforced", "event": "Event", "schedule_only": "Schedule only",
                 "not_harvested": "Not harvested", "no_trigger_found": "No trigger found"}
GROUPS = [("raw", "Raw"), ("distill", "Distill"), ("published", "Published"), ("none", "Layer not set")]


# ---------------------------------------------------------------- hand-offs
def _strings(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from _strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from _strings(v)


def _descendants(g, pipeline_key):
    seen, stack = set(), [pipeline_key]
    while stack:
        for c in g.children_of(stack.pop()):
            if c not in seen:
                seen.add(c)
                stack.append(c)
    return seen


def handoff(g, writer_orch, reader_orch, table_key, writer_jobs=()):
    """How the reader is made to run after the writer has written table_key."""
    if not reader_orch:
        return None
    rn = g.nodes.get(reader_orch, {})
    if writer_orch and reader_orch == writer_orch:
        return {"type": "enforced", "label": "Enforced", "why": "same state machine"}
    if writer_orch and reader_orch in _descendants(g, writer_orch):
        return {"type": "enforced", "label": "Enforced", "why": f"started by {g.name(writer_orch)}"}

    t = g.nodes.get(table_key, {})
    loc = (t.get("attrs", {}).get("aws") or {}).get("location") or t.get("attrs", {}).get("location") or ""
    starters = [s for s in g.starters_of(reader_orch) if g.nodes.get(s, {}).get("type") not in ("pipeline_task",)]
    for node in [reader_orch] + starters:
        for e in g.edges_out(node, "depends_on", "triggered_by"):
            dloc = (g.nodes.get(e.dst, {}).get("attrs", {}).get("aws") or {}).get("location") or ""
            if e.dst == table_key or (loc and dloc and (loc.startswith(dloc) or dloc.startswith(loc))):
                via = f" through {g.name(node)}" if node != reader_orch else ""
                return {"type": "event", "label": "Event", "why": f"file arrival in {g.name(e.dst)}{via}"}

    triggers = rn.get("attrs", {}).get("triggers")
    names = {x for x in [writer_orch, g.name(writer_orch) if writer_orch else None, table_key, loc] if x}
    for j in writer_jobs:
        names |= {j, g.name(j)}
    for tr in triggers or []:
        if not isinstance(tr, dict):
            continue
        hit = next((s for s in _strings(tr) if s in names), None)
        if hit:
            kind = tr.get("kind", "event")
            ttype = "enforced" if kind in ("glue_trigger", "conditional") else "event"
            return {"type": ttype, "label": HANDOFF_LABEL[ttype],
                    "why": f"{tr.get('rule') or tr.get('name') or kind} fires on {g.name(hit) if hit in g.nodes else hit}"}
    sched = [tr for tr in triggers or [] if isinstance(tr, dict) and tr.get("kind") == "schedule"]
    if sched:
        expr = ", ".join(str(s.get("expression") or s.get("name")) for s in sched)
        return {"type": "schedule_only", "label": "Schedule only", "why": f"runs on its own schedule ({expr})"}
    if triggers is None and not g.flags.get("triggers_harvested"):
        return {"type": "not_harvested", "label": "Not harvested", "why": "triggers are not in this snapshot"}
    return {"type": "no_trigger_found", "label": "No trigger found",
            "why": "no schedule or event found; it may be started by hand or by something not harvested"}


def handoff_step(g, ops, n, reader_orch, h, rebuilds):
    name = g.name(reader_orch)
    targets = ", ".join(g.name(t) for t in rebuilds[:4]) + (f" and {len(rebuilds) - 4} more" if len(rebuilds) > 4 else "")
    t = h["type"] if h else "no_trigger_found"
    if t == "enforced":
        title, detail = f"{name} runs as part of the restart", f"No extra action. {h['why'].capitalize()}. It rebuilds {targets}."
    elif t == "event":
        title, detail = f"Check {name} ran again", f"Started by an event ({h['why']}), so it should run once the data lands. Confirm it did. It rebuilds {targets}."
    elif t == "schedule_only":
        title, detail = f"Rerun {name} if it already ran", f"{h['why'].capitalize()}. Nothing reruns it automatically. If it ran after the failure, rerun the branch that builds {targets}."
    elif t == "not_harvested":
        title, detail = f"Check how {name} is triggered", f"Its trigger isn't harvested yet, so check by hand whether it needs a rerun. It rebuilds {targets}."
    else:
        title, detail = f"Check {name}", f"{h['why'].capitalize()}. It rebuilds {targets}."
    return {"n": n, "title": title, "detail": detail, "components": [g.ref(reader_orch)],
            "ops": ops.tags(reader_orch), "handoff": h}


# ---------------------------------------------------------------- shared pieces
def _orch(g, job, config_key=None):
    """The one state machine that runs this job (for this branch), or None if it isn't known."""
    return g.orchestrator_choice(job, config_key)[0]


def _orch_names(g, job, config_key=None, limit=4):
    cands = g.orchestrator_choice(job, config_key)[1]
    names = [g.name(c) for c in cands[:limit]]
    return ", ".join(names) + (f" and {len(cands) - limit} more" if len(cands) > limit else ""), cands


def _downstream(g, seeds):
    """BFS along table-level derives_from from seed tables.

    seeds: {table: (writer_job, edge or None)}. Returns ordered list of
    (node, hop, edge_in, writer_job) and the jobs met."""
    dist, info, order = {}, {}, []
    q = deque()
    for t, (job, e) in seeds.items():
        dist[t] = 1
        info[t] = (e, job)
        order.append(t)
        q.append(t)
    while q:
        x = q.popleft()
        nxt = [(e.dst, e, e.job) for e in g.table_lineage_out(x)]
        # jobs that read x but have no derives_from for this output: follow their writes for the same config item
        for r in g.edges_in(x, "reads"):
            ck = r.attrs.get("config_key")
            for out, e in g.job_outputs(r.src, ck):
                nxt.append((out, e, r.src))
        for y, e, job in nxt:
            if y in dist or g.is_column(y):
                continue
            dist[y] = dist[x] + 1
            info[y] = (e, job)
            order.append(y)
            q.append(y)
    return [(t, dist[t], info[t][0], info[t][1]) for t in order], dist


def _consumers(g, tables):
    res = {}
    for t in tables:
        for c in g.consumers_of(t):
            res.setdefault(c, []).append(t)
    return res


def _gaps_on(g, keys):
    seen, out = set(), []
    for k in keys:
        for gp in g.gaps_for(k):
            sig = (gp.get("rule"), gp.get("object"), gp.get("reason"))
            if sig not in seen:
                seen.add(sig)
                out.append({**gp, "at": g.name(k) if k in g.nodes else k})
    # state machines that may also process these tables but could not be bound to one job
    names = {g.name(k) for k in keys} | set(keys)
    for k, n in g.nodes.items():
        pt = n["attrs"].get("processes_tables")
        if n["type"] in ORCH_TYPES and pt and names & set(pt):
            out.append({"rule": "R4", "reason": "ambiguous_job", "object": k, "at": n["name"],
                        "detail": "this state machine processes these tables but runs more than one job, "
                                  "so its lineage edges are missing"})
    return out


def _notes(g, want=("consumers", "triggers")):
    notes = []
    if "consumers" in want and not g.flags.get("consumers_harvested"):
        notes.append("Consumers are not harvested yet (R9), so dashboards, APIs and extracts are not listed.")
    if "triggers" in want and not g.flags.get("triggers_harvested"):
        notes.append("Triggers are not harvested yet, so hand-offs between state machines show as Not harvested.")
    if "load_times" in want and not g.flags.get("load_times_present"):
        notes.append("No load times in this snapshot: check each job's last run in your monitoring tools.")
    return notes


def _group_rows(g, rows):
    groups = []
    by = {}
    for r in rows:
        n = g.get(r["key"]) or {}
        if n.get("type") in CONSUMER_TYPES or n.get("layer") == "consumer":
            continue
        by.setdefault(n.get("layer", "none"), []).append(r)
    for layer, label in GROUPS:
        if by.get(layer):
            groups.append({"name": label, "layer": layer, "size": len(by[layer]), "rows": by[layer]})
    return groups


def _why(g, edge, job):
    if edge is None:
        return f"written by {g.name(job)}" if job else ""
    via = f" by {g.name(job)}" if job else ""
    if edge.type == "derives_from":
        return f"from {g.name(edge.src)}{via}"
    return f"written{via}"


def _consumer_rows(g, consumers, extra_nodes):
    rows = []
    for c, tables in consumers.items():
        rows.append({**g.ref(c), "why": "uses " + ", ".join(g.name(t) for t in tables[:3])})
    for k in extra_nodes:
        if not any(r["key"] == k for r in rows):
            rows.append({**g.ref(k), "why": "written from the affected data"})
    return rows


def _orch_steps(g, ops, affected, seed_orchs, start_n):
    """One step per downstream orchestrator, worded by its hand-off."""
    steps, done = [], set(seed_orchs)
    per = {}
    unknown = {}
    for node, hop, e, job in affected:
        if not job or g.nodes.get(job, {}).get("type") not in JOB_TYPES or e is None:
            continue
        ck = e.attrs.get("config_key")
        reader, cands = g.orchestrator_choice(job, ck)
        if not reader:
            if len(cands) > 1 and not set(cands) <= done:
                u = unknown.setdefault(job, {"hop": hop, "rebuilds": [], "cands": cands, "branches": set()})
                u["rebuilds"].append(node)
                if ck:
                    u["branches"].add(ck)
            continue
        if reader in done:
            continue
        src_table = e.src if e.type == "derives_from" else None
        writer_job = None
        if src_table:
            ins = g.table_lineage_in(src_table)
            writer_job = ins[0].job if ins else None
        writer = _orch(g, writer_job) if writer_job else None
        per.setdefault(reader, {"hop": hop, "rebuilds": [], "h": None})
        per[reader]["rebuilds"].append(node)
        if per[reader]["h"] is None:
            per[reader]["h"] = handoff(g, writer, reader, src_table or node, [writer_job] if writer_job else [])
    for job, u in unknown.items():
        per[("unknown", job)] = {"hop": u["hop"], "unknown": u}
    n = start_n
    for reader, v in sorted(per.items(), key=lambda i: i[1]["hop"]):
        if "unknown" in v:
            u, job = v["unknown"], reader[1]
            names = ", ".join(g.name(c) for c in u["cands"][:4]) + (f" and {len(u['cands']) - 4} more" if len(u["cands"]) > 4 else "")
            targets = ", ".join(g.name(t) for t in u["rebuilds"][:4])
            br = f" ({', '.join(sorted(u['branches']))})" if u["branches"] else ""
            steps.append({"n": n, "title": f"Find which state machine runs {g.name(job)} for this branch",
                          "detail": f"{len(u['cands'])} state machines run it and the graph can't tell which one runs this branch{br}: {names}. "
                                    f"Whichever it is, rerun the branch that builds {targets} if it already ran.",
                          "components": [g.ref(job)] + [g.ref(c) for c in u["cands"][:6]], "ops": ops.tags(job),
                          "handoff": {"type": "no_trigger_found", "label": "State machine unknown",
                                      "why": "the branch's configuration does not name its state machine"}})
        else:
            steps.append(handoff_step(g, ops, n, reader, v["h"], v["rebuilds"]))
        n += 1
    return steps


def _number(steps):
    for i, s in enumerate(steps, 1):
        s["n"] = i
        s.setdefault("components", [])
        s.setdefault("ops", [])
    return steps


# ---------------------------------------------------------------- failure
def failure(g, ops, key, config_key=None):
    n = g.get(key)
    if not n:
        raise KeyError(key)
    t = n["type"]
    if t in ORCH_TYPES:
        failed = [key] + sorted(_descendants(g, key))
        jobs = []
        for p in failed:
            jobs += [j for j in g.jobs_of(p) if j not in jobs]
    elif t in JOB_TYPES:
        jobs = [key]
        chosen, cands = g.orchestrator_choice(key, config_key)
        failed = [chosen] if chosen else cands
    else:
        raise ValueError("Pick a job, state machine, DMS task or Lambda function. For a table, use the stale check.")

    seeds = {}
    for j in jobs:
        for out, e in g.job_outputs(j, config_key):
            if not g.is_column(out):
                seeds.setdefault(out, (j, e))
    affected, _ = _downstream(g, seeds)
    rows = [{**g.ref(k), "why": _why(g, e, job), "hop": hop} for k, hop, e, job in affected]
    groups = _group_rows(g, rows)

    seen_jobs, job_rows = set(jobs), []
    for k, hop, e, job in affected:
        if job and job not in seen_jobs and g.nodes.get(job, {}).get("type") in JOB_TYPES:
            seen_jobs.add(job)
            ck_ = e.attrs.get("config_key") if e else None
            o = _orch(g, job, ck_)
            names, cands = _orch_names(g, job, ck_)
            run_by = f"; run by {g.name(o)}" if o else (f"; run by one of {names}" if len(cands) > 1 else "")
            job_rows.append({**g.ref(job), "why": f"rebuilds {g.name(k)}" + run_by,
                             "hop": hop})
    if job_rows:
        groups.insert(len([x for x in groups if x["layer"] in ("raw", "distill")]),
                      {"name": "Downstream jobs", "layer": "job", "size": len(job_rows), "rows": job_rows})
    tables = [k for k, *_ in affected]
    extra = [k for k in tables if (g.get(k) or {}).get("type") in CONSUMER_TYPES or (g.get(k) or {}).get("layer") == "consumer"]
    consumer_rows = _consumer_rows(g, _consumers(g, tables), extra)
    if consumer_rows:
        groups.append({"name": "Consumers", "layer": "consumer", "size": len(consumer_rows), "rows": consumer_rows})

    # checklist
    steps = []
    inputs = []
    for j in jobs:
        for i, _e in g.job_inputs(j, config_key):
            if i not in inputs:
                inputs.append(i)
    detail = ("New data since the last run in: " + "; ".join(
        g.name(i) + (f" (last loaded {g.load_time(i)['at']}, as of snapshot)" if g.load_time(i) else "")
        for i in inputs[:6]) + (f"; and {len(inputs) - 6} more" if len(inputs) > 6 else "") + ".") if inputs \
        else "No inputs recorded for this component."
    steps.append({"title": "Check the inputs arrived", "detail": detail, "components": [g.ref(i) for i in inputs[:20]]})

    branches = []
    for j in jobs:
        for b in g.bound_instances(j):
            if config_key and b["config_key"] != config_key:
                continue
            if any(e.attrs.get("config_key") == b["config_key"] for _, (_, e) in seeds.items() if e is not None):
                branches.append(b["config_key"])
    if t in ORCH_TYPES:
        steps.append({"title": f"Restart {n['name']}",
                      "detail": "It runs " + ", ".join(g.name(j) for j in jobs[:5]) + (" and more" if len(jobs) > 5 else "") + ".",
                      "components": [g.ref(key)] + [g.ref(j) for j in jobs[:10]], "ops": ops.tags(key)})
    elif len(failed) > 1:
        names = ", ".join(g.name(o) for o in failed[:5]) + (f" and {len(failed) - 5} more" if len(failed) > 5 else "")
        steps.append({"title": "Restart the state machine that ran it",
                      "detail": f"{len(failed)} state machines run {n['name']}: {names}. Restart the one whose run failed"
                                + (", or rerun only the failed branches." if branches else "."),
                      "components": [g.ref(o) for o in failed[:8]] + [g.ref(key)], "ops": ops.tags(key)})
    elif failed:
        o = failed[0]
        b = f": {', '.join(branches[:6])}" + (f" and {len(branches) - 6} more" if len(branches) > 6 else "") if branches else ""
        steps.append({"title": f"Restart {g.name(o)}",
                      "detail": (f"Or rerun {n['name']} only for the failed branches{b}." if branches
                                 else f"It runs {n['name']}; no branch-level config is recorded for it."),
                      "components": [g.ref(o), g.ref(key)], "ops": ops.tags(key)})
    else:
        steps.append({"title": f"Rerun {n['name']}", "detail": "No orchestrator found for it; rerun it once the inputs are confirmed.",
                      "components": [g.ref(key)], "ops": ops.tags(key)})
    steps += _orch_steps(g, ops, affected, failed, len(steps) + 1)
    steps += _tell_owners(g, ops, consumer_rows)
    gaps = _gaps_on(g, [key] + jobs + failed + tables)
    if gaps:
        steps.append(_gap_step(gaps))

    empty = None
    if not affected:
        why = []
        if not seeds:
            why.append("it has no recorded outputs (no lineage edges or writes for it)")
        if not failed and t not in ORCH_TYPES:
            why.append("no state machine runs it")
        if t in ORCH_TYPES and not jobs:
            why.append("it runs no jobs or functions in the graph")
        empty = ("Nothing downstream found in the graph: " + "; ".join(why or ["its outputs have no further lineage"]) + ". "
                 "It may be unused, or its configuration could not be resolved; check the gaps"
                 + (" and whether the name is right" if n["name"].count("auk-") > 1 else "") + ".")

    ctx = n["type"].replace("_", " ")
    if n.get("system"):
        ctx += f" · {n['system']}"
    if failed and t not in ORCH_TYPES:
        ctx += f" · run by {g.name(failed[0])}" if len(failed) == 1 else f" · run by {len(failed)} state machines"
    return {"mode": "failure", "component": g.ref(key), "config_key": config_key, "context": ctx,
            "list_title": "What this failure affects", "plan_title": "Recovery checklist",
            "counts": _counts(groups, [("raw", "Raw not refreshed"), ("distill", "Distill not refreshed"),
                                       ("job", "Downstream jobs"), ("published", "Published tables"),
                                       ("consumer", "Consumers")]),
            "groups": groups, "steps": _number(steps), "gaps": gaps, "notes": _notes(g), "empty": empty,
            "snapshot": g.snapshot_id, "built_at": g.built_at}


def _counts(groups, spec):
    by = {x["layer"]: x["size"] for x in groups}
    return [{"label": label, "n": by.get(layer, 0), "layer": layer} for layer, label in spec]


def _tell_owners(g, ops, consumer_rows):
    if not consumer_rows:
        msg = "No consumers downstream in the graph." if g.flags.get("consumers_harvested") \
            else "Consumers are not harvested yet: tell the usual downstream owners by hand."
        return [{"title": "Tell the consumer owners", "detail": msg}]
    parts = []
    for r in consumer_rows:
        o = ops.get(r["key"])
        parts.append(r["name"] + (f" ({o['owner']})" if o and o.get("owner") else ""))
    return [{"title": "Tell the consumer owners", "detail": "; ".join(parts) + ".",
             "components": [{k: r[k] for k in ("key", "name", "type", "layer", "system")} for r in consumer_rows]}]


def _gap_step(gaps):
    parts = [f"{x.get('reason')} at {x.get('at')}" for x in gaps[:6]]
    more = f"; and {len(gaps) - 6} more" if len(gaps) > 6 else ""
    return {"title": "Check the gaps on this path by hand",
            "detail": "The graph is missing links here, so the lists above may be incomplete: " + "; ".join(parts) + more + "."}


# ---------------------------------------------------------------- stale table
def stale(g, ops, key):
    n = g.get(key)
    if not n or n["type"] not in ("table", "extract"):
        raise ValueError("Pick a table.")
    dist, via, order, q = {key: 0}, {}, [], deque([key])
    while q:
        x = q.popleft()
        for e in g.table_lineage_in(x):
            if e.src not in dist:
                dist[e.src] = dist[x] + 1
                via[e.src] = e
                order.append(e.src)
                q.append(e.src)
    writers, upstream_rows, likely = [], [], []
    for u in order:
        e = via[u]
        lt = g.load_time(u)
        upstream_rows.append({**g.ref(u), "hop": dist[u], "why": f"feeds {g.name(e.dst)}" + (f" by {g.name(e.job)}" if e.job else ""),
                              "loaded": lt})
        if e.job and all(w["key"] != e.job for w in writers):
            o = _orch(g, e.job, e.attrs.get("config_key"))
            names, cands = _orch_names(g, e.job, e.attrs.get("config_key"))
            run_by = f"; run by {g.name(o)}" if o else (f"; run by one of {names} (not recorded for this branch)" if len(cands) > 1 else "")
            writers.append({**g.ref(e.job), "hop": dist[u], "why": f"builds {g.name(e.dst)}" + run_by,
                            "orchestrator": o})
            # how this writer is made to wait for the one that wrote its input
            ins = g.table_lineage_in(u)
            wj = ins[0].job if ins else None
            w_orch = _orch(g, wj) if wj else None
            h = handoff(g, w_orch, o, u, [wj] if wj else []) if o else None
            if h and h["type"] == "schedule_only" and w_orch:
                likely.append(f"{g.name(o)} runs on a schedule, not after {g.name(w_orch)}: if it ran before {g.name(u)} was loaded, it built from old data")

    down, _ = _downstream(g, {key: (None, None)})
    down = [d for d in down if d[0] != key]
    down_rows = [{**g.ref(k), "why": _why(g, e, job), "hop": hop} for k, hop, e, job in down]
    tables = [key] + [k for k, *_ in down]
    extra = [k for k in tables if (g.get(k) or {}).get("layer") == "consumer"]
    consumer_rows = _consumer_rows(g, _consumers(g, tables), extra)

    groups = []
    if writers:
        groups.append({"name": "Writers, nearest first", "layer": "job", "size": len(writers), "rows": writers})
    if upstream_rows:
        groups.append({"name": "Upstream tables, nearest first", "layer": "upstream", "size": len(upstream_rows), "rows": upstream_rows})
    dg = [r for r in down_rows if (g.get(r["key"]) or {}).get("layer") != "consumer"]
    if dg:
        groups.append({"name": "Downstream tables", "layer": "downstream", "size": len(dg), "rows": dg})
    if consumer_rows:
        groups.append({"name": "Consumers affected", "layer": "consumer", "size": len(consumer_rows), "rows": consumer_rows})

    chain = list(reversed(order)) + [key]
    times = [f"{g.name(k)}" + (f" ({g.load_time(k)['at']})" if g.load_time(k) else "") for k in chain]
    detail = "Compare last load times along: " + " → ".join(times) + ". The first hop that is behind is the cause."
    if not g.flags.get("load_times_present"):
        detail += " This snapshot holds no load times, so check each job's last run in your monitoring tools."
    if likely:
        detail += " Likely cause: " + "; ".join(likely) + "."
    steps = [{"title": "Find the first stale hop", "detail": detail, "components": [g.ref(k) for k in chain]}]
    rerun = list(reversed(writers))
    if rerun:
        steps.append({"title": "Rerun from that hop, in this order",
                      "detail": " → ".join(w["name"] + (f" (in {g.name(w['orchestrator'])})" if w.get("orchestrator") else "") for w in rerun) + ".",
                      "components": [{k: w[k] for k in ("key", "name", "type", "layer", "system")} for w in rerun],
                      "ops": ops.tags(rerun[-1]["key"])})
    own = [w["orchestrator"] for w in writers[:1] if w.get("orchestrator")]
    steps += _orch_steps(g, ops, down, own, len(steps) + 1)
    steps += _tell_owners(g, ops, consumer_rows)
    gaps = _gaps_on(g, chain + [w["key"] for w in writers] + [w["orchestrator"] for w in writers if w.get("orchestrator")])
    if gaps:
        steps.append(_gap_step(gaps))
    empty = None if order else ("No lineage into this table in the graph, so its writers are unknown. "
                                "It may be loaded by something not yet harvested; check the gaps.")
    return {"mode": "stale", "component": g.ref(key), "empty": empty, "context": f"{n['type']} · {n.get('layer')}" + (f" · {n['system']}" if n.get("system") else ""),
            "list_title": "Who populates it, and who uses it", "plan_title": "Recovery checklist",
            "counts": [{"label": "Data hops upstream", "n": len(order), "layer": "upstream"},
                       {"label": "Writers upstream", "n": len(writers), "layer": "job"},
                       {"label": "Downstream tables", "n": len(dg), "layer": "downstream"},
                       {"label": "Consumers affected", "n": len(consumer_rows), "layer": "consumer"}],
            "groups": groups, "steps": _number(steps), "gaps": gaps, "notes": _notes(g, ("consumers", "triggers", "load_times")),
            "snapshot": g.snapshot_id, "built_at": g.built_at}


# ---------------------------------------------------------------- column change
def column_change(g, ops, col_key):
    c = g.columns.get(col_key)
    if not c:
        raise KeyError(col_key)
    T = c["table"]
    tnode = g.nodes.get(T, {})
    incoming = g.column_lineage_in(col_key)
    seen, q, down = {col_key}, deque([col_key]), []
    while q:
        x = q.popleft()
        for e in g.column_lineage_out(x):
            if e.dst not in seen:
                seen.add(e.dst)
                down.append(e)
                q.append(e.dst)
    edges = incoming + down
    cfg, code, jobs = {}, {}, []
    for e in edges:
        ck = e.attrs.get("config_key")
        if ck:
            k = (e.attrs.get("config_table"), ck)
            cfg.setdefault(k, set())
            if e.attrs.get("mapping_seq_no") is not None:
                cfg[k].add(e.attrs["mapping_seq_no"])
        sql = e.attrs.get("sql_file") or e.attrs.get("code_ref")
        if sql:
            code.setdefault(sql, set()).add(e.job)
        if e.job and e.job not in jobs:
            jobs.append(e.job)
    d_tables = []
    for e in down:
        t = g.columns[e.dst]["table"] if e.dst in g.columns else None
        if t and t not in d_tables:
            d_tables.append(t)
    covered = {T, *d_tables}
    table_only = []
    for t in [T] + d_tables:
        for e in g.table_lineage_out(t):
            if e.dst not in covered and e.dst not in table_only:
                table_only.append(e.dst)
    sibs = []
    se = tnode.get("attrs", {}).get("source_equivalent")
    pt = g.nodes.get(se, {}).get("attrs", {}).get("product_table") if se else None
    if pt:
        same_src = {k for k, n in g.nodes.items() if n["attrs"].get("product_table") == pt and k != se}
        for k, n in g.nodes.items():
            if k != T and n["attrs"].get("source_equivalent") in same_src:
                ck = f"{k}.{c['name']}"
                if ck in g.columns:
                    sibs.append(ck)
    consumers = _consumers(g, [T] + d_tables)
    extra = [t for t in d_tables if (g.get(t) or {}).get("layer") == "consumer"]
    consumer_rows = _consumer_rows(g, consumers, extra)

    groups = []
    if cfg:
        groups.append({"name": "Configuration", "layer": "config", "size": len(cfg), "rows": [
            {"key": f"{t}/{k}", "name": f"{k}", "type": "config_item", "layer": "none", "system": None,
             "why": f"{t}" + (f", mapping_seq_no {', '.join(str(x) for x in sorted(s))}" if s else "")}
            for (t, k), s in sorted(cfg.items(), key=lambda i: (i[0][0] or "", i[0][1]))]})
    if code:
        groups.append({"name": "Code", "layer": "code", "size": len(code), "rows": [
            {"key": f, "name": f, "type": "sql_file", "layer": "none", "system": None,
             "why": "used by " + ", ".join(g.name(j) for j in js if j)} for f, js in code.items()]})
    if incoming:
        groups.append({"name": "Feeds this column", "layer": "upstream", "size": len(incoming), "rows": [
            {**g.ref(e.src), "why": (e.expr or e.tc or "") + (f" by {g.name(e.job)}" if e.job else "")} for e in incoming]})
    if down:
        groups.append({"name": "Downstream columns", "layer": "downstream", "size": len(down), "rows": [
            {**g.ref(e.dst), "why": f"from {g.name(e.src)}" + (f" via {e.attrs.get('sql_file')}" if e.attrs.get("sql_file") else "")
             + (f" by {g.name(e.job)}" if e.job else "")} for e in down]})
    if table_only:
        groups.append({"name": "Table-level links only (column use unknown)", "layer": "table_only", "size": len(table_only),
                       "rows": [{**g.ref(t), "why": "downstream of an affected table; no column lineage to check"} for t in table_only]})
    if sibs:
        groups.append({"name": "Same table in other instances", "layer": "siblings", "size": len(sibs), "rows": [
            {**g.ref(s), "why": f"{g.get(s).get('system')}: same {pt}, likely needs the same change"} for s in sibs]})
    if consumer_rows:
        groups.append({"name": "Consumers", "layer": "consumer", "size": len(consumer_rows), "rows": consumer_rows})

    steps = []
    if cfg:
        steps.append({"title": "Update the configuration items",
                      "detail": "; ".join(f"{k} in {t}" for (t, k) in cfg) + (", and the same for " + ", ".join(sorted({g.get(s)['system'] or '' for s in sibs})) if sibs else "") + "."})
    if code:
        steps.append({"title": "Update the code", "detail": "; ".join(code) + "."})
    if d_tables:
        steps.append({"title": "Check the downstream tables", "detail": ", ".join(g.name(t) for t in d_tables) + ": schema, Hudi record key and partitions.",
                      "components": [g.ref(t) for t in d_tables]})
    if table_only:
        steps.append({"title": "Check the table-level links by hand", "detail": ", ".join(g.name(t) for t in table_only[:8]) + " may use the column; the graph has no column lineage there."})
    steps += _tell_owners(g, ops, consumer_rows)
    gaps = _gaps_on(g, [T] + d_tables + jobs)
    if gaps:
        steps.append(_gap_step(gaps))
    notes = _notes(g, ("consumers",))
    if not g.flags.get("column_lineage_beyond_distill"):
        notes.append("Column lineage is only Raw to Distill in this snapshot (from data mapping items); SQL is not parsed yet.")
    empty = None if (incoming or down or sibs or consumer_rows or table_only) else (
        "No lineage for this column in the graph. Column lineage exists only where data mapping items "
        "or parsed SQL cover it.")
    return {"mode": "column", "component": g.ref(col_key), "empty": empty, "context": f"column of {g.name(T)} · {tnode.get('layer')}" + (f" · {tnode.get('system')}" if tnode.get("system") else ""),
            "list_title": "Components that use this column", "plan_title": "Change checklist",
            "counts": [{"label": "Config items", "n": len(cfg), "layer": "config"},
                       {"label": "Code files", "n": len(code), "layer": "code"},
                       {"label": "Downstream columns", "n": len(down), "layer": "downstream"},
                       {"label": "Consumers", "n": len(consumer_rows), "layer": "consumer"}],
            "groups": groups, "steps": _number(steps), "gaps": gaps, "notes": notes,
            "snapshot": g.snapshot_id, "built_at": g.built_at}
